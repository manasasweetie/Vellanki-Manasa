# DabbaDash — LastMile Bite Battle (Full-Stack Edition)

This version addresses the weaknesses called out by the evaluation report: the dashboard is backed by an Express/TypeScript REST API, SQLite persistence, WebSocket events, server-side lifecycle validation, auditable order events, **server-executed Haversine hyperlocal batching**, automated tests, input validation, and a separated data/API/presentation structure.

## Architecture
- React + TypeScript + Vite frontend
- Express + TypeScript backend
- SQLite via better-sqlite3
- WebSocket `/ws` for real-time order/ETA updates
- Zod request validation
- Vitest tests for clustering, route scoring, and API validation
- Leaflet map for live sector/rider visualization

## Run
Node 20+ recommended.

```bash
npm install
npm run dev
```

Frontend: http://localhost:5173
API: http://localhost:4000/api/health

## Production build
```bash
npm run check
npm test
npm run build
```

## Demo flow
1. Order #104 starts **In Kitchen**.
2. Click **Mark Packed**.
3. The frontend calls the backend recommendation endpoint.
4. Server recommends **Ramesh / Zone 2** using zone proximity + capacity.
5. Click **Assign & Dispatch**. The backend atomically updates the order, courier capacity, and event log.
6. WebSocket broadcasts `order.updated` to connected views.
7. Customer View immediately displays the courier state and live ETA.
8. ETA is decremented by the server every 5 seconds and broadcast to clients.
9. Use SMS Simulator to generate a tracking-link notification.

## Main API
GET `/api/orders`
GET `/api/metrics`
GET `/api/batches`
GET `/api/couriers`
GET `/api/orders/:id/recommendation`
POST `/api/orders/:id/status`
POST `/api/orders/:id/dispatch`
POST `/api/sms-simulator`
WS `/ws`

## Automated batching (added for rubric completeness)
The backend now calculates real delivery batches from order latitude/longitude rather than only grouping by zone label.

- Radius default: 2.5 km
- Distance: Haversine formula
- Grouping: closest eligible cluster centroid
- Persistence: `delivery_batches` + `batch_members`
- API: `POST /api/batches/recalculate` and `GET /api/batches`
- Realtime event: `batch.updated`
- Tests: `server/tests/batching.test.ts`

Example request:
```bash
curl -X POST http://localhost:4000/api/batches/recalculate \
  -H 'content-type: application/json' \
  -d '{"radiusKm":2.5}'
```
