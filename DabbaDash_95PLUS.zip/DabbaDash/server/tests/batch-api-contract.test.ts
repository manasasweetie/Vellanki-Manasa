import { describe, it, expect } from 'vitest';

describe('batch API contract', () => {
  it('uses the hackathon default radius', () => {
    const defaultRadiusKm = 2.5;
    expect(defaultRadiusKm).toBe(2.5);
    expect(defaultRadiusKm).toBeLessThanOrEqual(10);
  });
  it('requires multi-order batches to be explicitly represented by orderIds', () => {
    const batch = { id:'B-2-1', zoneId:'z2', orderIds:['104','111'], orderCount:2, radiusKm:1.2 };
    expect(batch.orderCount).toBe(batch.orderIds.length);
    expect(batch.radiusKm).toBeLessThanOrEqual(2.5);
  });
});
