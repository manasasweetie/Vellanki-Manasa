import {describe,it,expect} from 'vitest';
import {courierScore} from '../src/routing.js';

describe('distance-aware courier scoring',()=>{
  it('prefers a same-zone courier when load and distance are comparable',()=>{
    const order={lat:17.4,lng:78.5,zoneId:'z2'};
    const same={lat:17.401,lng:78.501,zoneId:'z2',activeOrders:0,capacity:3};
    const other={lat:17.401,lng:78.501,zoneId:'z1',activeOrders:0,capacity:3};
    expect(courierScore(order,same)).toBeLessThan(courierScore(order,other));
  });
  it('penalizes overloaded riders',()=>{
    const order={lat:17.4,lng:78.5,zoneId:'z2'};
    const free={lat:17.41,lng:78.51,zoneId:'z2',activeOrders:0,capacity:3};
    const busy={lat:17.401,lng:78.501,zoneId:'z2',activeOrders:2,capacity:3};
    expect(courierScore(order,free)).toBeLessThan(courierScore(order,busy));
  });
});
