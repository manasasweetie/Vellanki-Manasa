import { describe, it, expect } from 'vitest';
import { clusterOrders, haversineKm } from '../src/cluster.js';

describe('automated hyperlocal batching', () => {
  it('keeps orders inside a 2.5km radius in one cluster', () => {
    const a={id:'101',lat:17.400,lng:78.500,zoneId:'z2'};
    const b={id:'102',lat:17.405,lng:78.502,zoneId:'z2'};
    expect(haversineKm(a,b)).toBeLessThan(2.5);
    expect(clusterOrders([a,b],2.5)).toHaveLength(1);
  });
  it('separates orders beyond the configured radius', () => {
    const a={id:'101',lat:17.400,lng:78.500,zoneId:'z2'};
    const b={id:'102',lat:17.450,lng:78.550,zoneId:'z2'};
    expect(haversineKm(a,b)).toBeGreaterThan(2.5);
    expect(clusterOrders([a,b],2.5)).toHaveLength(2);
  });
  it('does not create a single oversized chain through a centroid', () => {
    const pts=[
      {id:'a',lat:17.400,lng:78.500,zoneId:'z2'},
      {id:'b',lat:17.415,lng:78.500,zoneId:'z2'},
      {id:'c',lat:17.430,lng:78.500,zoneId:'z2'},
    ];
    const groups=clusterOrders(pts,2.5);
    expect(groups.length).toBeGreaterThan(1);
  });
});
