import { db } from './db.js';
import { clusterOrders, centroid, maxRadiusKm, type Point } from './cluster.js';

export interface BatchPreview {
  id: string;
  zoneId: string;
  orderIds: string[];
  orderCount: number;
  radiusKm: number;
  center: { lat: number; lng: number };
}

/** Pure service used by the API and tests. It intentionally has no HTTP concerns. */
export function calculateDispatchBatches(radiusKm = 2.5): BatchPreview[] {
  const points = db.prepare(`SELECT id, zoneId, latitude lat, longitude lng FROM orders WHERE status IN ('PACKED','OUT_FOR_DELIVERY') AND latitude IS NOT NULL AND longitude IS NOT NULL ORDER BY zoneId,id`).all() as Point[];
  const grouped = new Map<string, Point[]>();
  for (const p of points) (grouped.get(p.zoneId) ?? (grouped.set(p.zoneId, []), grouped.get(p.zoneId)!)).push(p);
  const result: BatchPreview[] = [];
  for (const [zoneId, zonePoints] of grouped) {
    clusterOrders(zonePoints, radiusKm).forEach((group, i) => result.push({
      id: `B-${zoneId.replace('z','')}-${i + 1}`,
      zoneId,
      orderIds: group.map(p => p.id),
      orderCount: group.length,
      radiusKm: Number(maxRadiusKm(group).toFixed(3)),
      center: centroid(group),
    }));
  }
  return result;
}
