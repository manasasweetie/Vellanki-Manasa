import Database from 'better-sqlite3';
import { randomUUID } from 'node:crypto';
import type { Brand,Courier,Order,Zone,Status } from './types.js';
import { clusterOrders, centroid, maxRadiusKm, haversineKm, type DeliveryBatch, type Point } from './cluster.js';
import { courierScore } from './routing.js';

export const db=new Database(process.env.DB_FILE ?? 'dabbadash.sqlite');
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
export function migrate(){db.exec(`
CREATE TABLE IF NOT EXISTS brands(id TEXT PRIMARY KEY,name TEXT NOT NULL,icon TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS zones(id TEXT PRIMARY KEY,name TEXT NOT NULL,lat REAL NOT NULL,lng REAL NOT NULL,radiusKm REAL NOT NULL DEFAULT 2.5);
CREATE TABLE IF NOT EXISTS couriers(id TEXT PRIMARY KEY,name TEXT NOT NULL,zoneId TEXT NOT NULL,vehicle TEXT NOT NULL,capacity INTEGER NOT NULL,activeOrders INTEGER NOT NULL DEFAULT 0,available INTEGER NOT NULL DEFAULT 1,latitude REAL,longitude REAL,FOREIGN KEY(zoneId) REFERENCES zones(id));
CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,customer TEXT NOT NULL,brandId TEXT NOT NULL,amount REAL NOT NULL,zoneId TEXT NOT NULL,status TEXT NOT NULL,prepMinutes INTEGER NOT NULL,etaMinutes INTEGER NOT NULL DEFAULT 0,courierId TEXT,createdAt TEXT NOT NULL,updatedAt TEXT NOT NULL,FOREIGN KEY(brandId) REFERENCES brands(id),FOREIGN KEY(zoneId) REFERENCES zones(id),FOREIGN KEY(courierId) REFERENCES couriers(id));
CREATE TABLE IF NOT EXISTS order_items(id TEXT PRIMARY KEY,orderId TEXT NOT NULL,name TEXT NOT NULL,quantity INTEGER NOT NULL,FOREIGN KEY(orderId) REFERENCES orders(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS order_events(id TEXT PRIMARY KEY,orderId TEXT NOT NULL,status TEXT NOT NULL,actor TEXT NOT NULL,createdAt TEXT NOT NULL,FOREIGN KEY(orderId) REFERENCES orders(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);CREATE INDEX IF NOT EXISTS idx_orders_zone ON orders(zoneId);CREATE INDEX IF NOT EXISTS idx_orders_brand ON orders(brandId);
CREATE TABLE IF NOT EXISTS delivery_batches(id TEXT PRIMARY KEY,zoneId TEXT NOT NULL,centerLat REAL NOT NULL,centerLng REAL NOT NULL,radiusKm REAL NOT NULL,orderCount INTEGER NOT NULL,createdAt TEXT NOT NULL,updatedAt TEXT NOT NULL,FOREIGN KEY(zoneId) REFERENCES zones(id));
CREATE TABLE IF NOT EXISTS batch_members(batchId TEXT NOT NULL,orderId TEXT NOT NULL,PRIMARY KEY(batchId,orderId),FOREIGN KEY(batchId) REFERENCES delivery_batches(id) ON DELETE CASCADE,FOREIGN KEY(orderId) REFERENCES orders(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_batch_members_order ON batch_members(orderId);
`);
for (const sql of ["ALTER TABLE orders ADD COLUMN latitude REAL", "ALTER TABLE orders ADD COLUMN longitude REAL", "ALTER TABLE couriers ADD COLUMN latitude REAL", "ALTER TABLE couriers ADD COLUMN longitude REAL"]) { try { db.exec(sql); } catch {} }
}
export function seed(){const count=(db.prepare('SELECT COUNT(*) c FROM orders').get() as {c:number}).c;if(count) return;
const brands=[['b1','Biryani Box','🍛'],['b2','Burger Den','🍔'],['b3','Chai Point','☕']];const zones=[['z1','Zone 1',17.385,78.486,2.5],['z2','Zone 2',17.400,78.500,2.5],['z3','Zone 3',17.375,78.505,2.5],['z4','Zone 4',17.405,78.475,2.5]];const couriers=[['r1','Ramesh','z2','Bike',3,0,1,17.400,78.500],['r2','Suresh','z1','Scooter',2,1,1,17.385,78.486],['r3','Arjun','z3','Bike',3,1,1,17.375,78.505],['r4','Priya','z4','Scooter',2,0,1,17.405,78.475],['r5','Kiran','z2','Bike',3,2,1,17.398,78.497],['r6','Rahul','z1','Bike',3,0,1,17.388,78.482]];
const tx=db.transaction(()=>{for(const x of brands)db.prepare('INSERT INTO brands VALUES(?,?,?)').run(...x);for(const x of zones)db.prepare('INSERT INTO zones VALUES(?,?,?,?,?)').run(...x);for(const x of couriers)db.prepare('INSERT INTO couriers VALUES(?,?,?,?,?,?,?,?,?)').run(...x);
const data=[['104','Aarav','b2',320,'z2','IN_KITCHEN',23,14,null],['101','Diya','b1',410,'z1','RECEIVED',4,18,null],['105','Rohan','b3',180,'z3','RECEIVED',8,12,null],['108','Meera','b1',360,'z4','IN_KITCHEN',18,16,null],['109','Ishaan','b2',290,'z1','IN_KITCHEN',11,15,null],['111','Ananya','b3',260,'z2','PACKED',16,13,null],['112','Kabir','b2',340,'z2','PACKED',14,11,null],['102','Sara','b1',300,'z3','OUT_FOR_DELIVERY',13,9,'r3'],['103','Vikram','b2',275,'z4','OUT_FOR_DELIVERY',12,7,'r4'],['99','Nisha','b3',150,'z1','DELIVERED',10,0,'r2'],['106','Aditya','b1',390,'z4','RECEIVED',3,19,null],['107','Tara','b3',190,'z2','IN_KITCHEN',21,17,null],['110','Neil','b2',240,'z3','PACKED',15,10,null],['113','Maya','b1',250,'z1','IN_KITCHEN',22,15,null],['114','Arjun','b3',160,'z4','RECEIVED',6,18,null]];
for(const o of data){const now=new Date(Date.now()-o[6] as number*60000).toISOString();const zoneCenter = zones.find(z => z[0] === o[4])!; const offset = Number(o[0]) % 4; const lat = Number(zoneCenter[2]) + ((offset - 1.5) * 0.0025); const lng = Number(zoneCenter[3]) + (((Number(o[0]) % 3) - 1) * 0.0025); db.prepare('INSERT INTO orders(id,customer,brandId,amount,zoneId,status,prepMinutes,etaMinutes,courierId,createdAt,updatedAt,latitude,longitude) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)').run(o[0],o[1],o[2],o[3],o[4],o[5],o[6],o[7],o[8],now,new Date().toISOString(),lat,lng);const items=o[0]==='104'?[['2 Burgers',2],['Fries',1]]:o[2]==='b1'?[['Biryani',1],['Raita',1]]:o[2]==='b2'?[['Burger',1],['Fries',1]]:[['Masala Chai',1],['Samosa',1]];for(const [name,q] of items)db.prepare('INSERT INTO order_items VALUES(?,?,?,?)').run(randomUUID(),o[0],name,q);db.prepare('INSERT INTO order_events VALUES(?,?,?,?,?)').run(randomUUID(),o[0],o[5],'seed',now);}
});tx();}
export function mapOrder(row:any):Order&{brand:string;brandIcon:string;zone:string;items:string[]}{const brand=db.prepare('SELECT name,icon FROM brands WHERE id=?').get(row.brandId) as any;const zone=db.prepare('SELECT name FROM zones WHERE id=?').get(row.zoneId) as any;const items=(db.prepare('SELECT name,quantity FROM order_items WHERE orderId=?').all(row.id) as any[]).map(x=>x.quantity>1?`${x.quantity} ${x.name}`:x.name);return {...row,amount:Number(row.amount),brand:brand.name,brandIcon:brand.icon,zone:zone.name,items};}
export function allOrders(){return (db.prepare('SELECT * FROM orders ORDER BY CASE status WHEN "IN_KITCHEN" THEN 1 WHEN "PACKED" THEN 2 WHEN "OUT_FOR_DELIVERY" THEN 3 WHEN "RECEIVED" THEN 4 ELSE 5 END, updatedAt DESC').all() as any[]).map(mapOrder);}
export function order(id:string){const r=db.prepare('SELECT * FROM orders WHERE id=?').get(id);return r?mapOrder(r):null;}
export function brands():Brand[]{return db.prepare('SELECT * FROM brands').all() as Brand[];}
export function zones():Zone[]{return db.prepare('SELECT * FROM zones').all() as Zone[];}
export function couriers():Courier[]{return (db.prepare('SELECT c.*,z.name zone FROM couriers c JOIN zones z ON z.id=c.zoneId ORDER BY c.name').all() as Courier[]).map(c=>({...c,latitude:Number(c.latitude),longitude:Number(c.longitude)}));}
export function setStatus(id:string,status:Status){const current=order(id);if(!current)throw new Error('ORDER_NOT_FOUND');const valid=({RECEIVED:['IN_KITCHEN'],IN_KITCHEN:['PACKED'],PACKED:[],OUT_FOR_DELIVERY:['DELIVERED'],DELIVERED:[]} as Record<Status,Status[]>)[current.status];if(!valid.includes(status))throw new Error(`INVALID_TRANSITION:${current.status}->${status}`);const eta=status==='OUT_FOR_DELIVERY'?15:status==='DELIVERED'?0:current.etaMinutes;db.transaction(()=>{const now=new Date().toISOString();db.prepare('UPDATE orders SET status=?,etaMinutes=?,updatedAt=? WHERE id=?').run(status,eta,now,id);db.prepare('INSERT INTO order_events VALUES(?,?,?,?,?)').run(randomUUID(),id,status,'manager',now);if(status==='DELIVERED'&&current.courierId)db.prepare('UPDATE couriers SET activeOrders=MAX(0,activeOrders-1),available=1 WHERE id=?').run(current.courierId);})();recalculateBatches();return order(id);}
export function dispatch(id:string,courierId:string){const o=order(id);const c=db.prepare('SELECT * FROM couriers WHERE id=?').get(courierId) as any;if(!o||!c)throw new Error('NOT_FOUND');if(o.status!=='PACKED')throw new Error('ORDER_NOT_PACKED');if(!c.available||c.activeOrders>=c.capacity)throw new Error('COURIER_CAPACITY_REACHED');if(o.courierId)throw new Error('ORDER_ALREADY_DISPATCHED');db.transaction(()=>{db.prepare('UPDATE orders SET status="OUT_FOR_DELIVERY",courierId=?,etaMinutes=15,updatedAt=? WHERE id=?').run(courierId,new Date().toISOString(),id);db.prepare('UPDATE couriers SET activeOrders=activeOrders+1 WHERE id=?').run(courierId);db.prepare('INSERT INTO order_events VALUES(?,?,?,?,?)').run(randomUUID(),id,'OUT_FOR_DELIVERY','dispatcher',new Date().toISOString());})();recalculateBatches();return order(id);}
export function recommend(orderId:string){
  const o=order(orderId);
  if(!o)return null;
  const orderRow=db.prepare('SELECT latitude,longitude,zoneId FROM orders WHERE id=?').get(orderId) as any;
  const candidates=(db.prepare(`SELECT c.*,z.name zone FROM couriers c JOIN zones z ON z.id=c.zoneId WHERE c.available=1 AND c.activeOrders<c.capacity`).all() as any[]);
  if(!candidates.length)return null;
  candidates.sort((a,b)=>courierScore(orderRow,a)-courierScore(orderRow,b));
  const c=candidates[0];
  return {...c,distanceKm:Number(haversineKm({id:'o',lat:orderRow.latitude,lng:orderRow.longitude,zoneId:orderRow.zoneId},{id:c.id,lat:c.latitude,lng:c.longitude,zoneId:c.zoneId}).toFixed(2))};
}
export function metrics(){const active=(db.prepare(`SELECT COUNT(*) c FROM orders WHERE status!='DELIVERED'`).get() as any).c;const kitchen=(db.prepare(`SELECT COUNT(*) c FROM orders WHERE status='IN_KITCHEN'`).get() as any).c;const packed=(db.prepare(`SELECT COUNT(*) c FROM orders WHERE status='PACKED'`).get() as any).c;const avg=(db.prepare(`SELECT ROUND(AVG(prepMinutes),1) v FROM orders WHERE status!='RECEIVED'`).get() as any).v;return {activeOrders:active,activeKitchenOrders:kitchen,pendingDispatches:packed,avgPrepMinutes:avg??0,delivered:(db.prepare(`SELECT COUNT(*) c FROM orders WHERE status='DELIVERED'`).get() as any).c};}
export function recalculateBatches(radiusKm = 2.5): DeliveryBatch[] {
  const candidates = db.prepare(`SELECT id, zoneId, latitude lat, longitude lng FROM orders WHERE status IN ('PACKED','OUT_FOR_DELIVERY') AND latitude IS NOT NULL AND longitude IS NOT NULL ORDER BY zoneId, id`).all() as Point[];
  const now = new Date().toISOString();
  const batchesOut: DeliveryBatch[] = [];
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM batch_members').run();
    db.prepare('DELETE FROM delivery_batches').run();
    const byZone = new Map<string, Point[]>();
    for (const p of candidates) (byZone.get(p.zoneId) ?? (byZone.set(p.zoneId, []), byZone.get(p.zoneId)!)).push(p);
    for (const [zoneId, points] of byZone) {
      const groups = clusterOrders(points, radiusKm);
      groups.forEach((group, idx) => {
        const c = centroid(group);
        const batchId = `B-${zoneId.replace('z','')}-${idx + 1}`;
        const radius = Number(maxRadiusKm(group).toFixed(3));
        db.prepare('INSERT INTO delivery_batches(id,zoneId,centerLat,centerLng,radiusKm,orderCount,createdAt,updatedAt) VALUES(?,?,?,?,?,?,?,?)')
          .run(batchId, zoneId, c.lat, c.lng, radius, group.length, now, now);
        const memberStmt = db.prepare('INSERT INTO batch_members(batchId,orderId) VALUES(?,?)');
        for (const p of group) memberStmt.run(batchId, p.id);
        batchesOut.push({ id: batchId, zoneId, orderIds: group.map(p => p.id), center: c, radiusKm, distanceSpanKm: radius });
      });
    }
  });
  tx();
  return batchesOut;
}

export function batches() {
  const rows = db.prepare(`SELECT b.*, z.name zoneName FROM delivery_batches b JOIN zones z ON z.id=b.zoneId ORDER BY b.zoneId,b.id`).all() as any[];
  return rows.map(b => ({
    id: b.id, zoneId: b.zoneId, zone: b.zoneName, center: { lat: b.centerLat, lng: b.centerLng },
    radiusKm: b.radiusKm, orderCount: b.orderCount,
    orders: (db.prepare(`SELECT o.* FROM orders o JOIN batch_members m ON m.orderId=o.id WHERE m.batchId=? ORDER BY o.id`).all(b.id) as any[]).map(mapOrder),
  }));
}

export function batchById(id: string) { return batches().find(b => b.id === id) ?? null; }
export function events(id:string){return db.prepare('SELECT * FROM order_events WHERE orderId=? ORDER BY createdAt').all(id);}
export function tickEta(){const active=db.prepare(`SELECT id,etaMinutes FROM orders WHERE status='OUT_FOR_DELIVERY' AND etaMinutes>0`).all() as any[];for(const o of active)db.prepare('UPDATE orders SET etaMinutes=?,updatedAt=? WHERE id=?').run(Math.max(0,o.etaMinutes-1),new Date().toISOString(),o.id);return active.length;}
