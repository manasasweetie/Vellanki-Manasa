export type Status = 'RECEIVED'|'IN_KITCHEN'|'PACKED'|'OUT_FOR_DELIVERY'|'DELIVERED';
export interface Brand { id:string; name:string; icon:string; }
export interface Zone { id:string; name:string; lat:number; lng:number; radiusKm:number; }
export interface Courier { id:string; name:string; zoneId:string; zone:string; vehicle:string; capacity:number; activeOrders:number; available:number; latitude:number; longitude:number; distanceKm?:number; }
export interface Order { id:string; customer:string; brandId:string; amount:number; zoneId:string; status:Status; prepMinutes:number; etaMinutes:number; courierId:string|null; createdAt:string; }
export const STATUSES: Status[]=['RECEIVED','IN_KITCHEN','PACKED','OUT_FOR_DELIVERY','DELIVERED'];
