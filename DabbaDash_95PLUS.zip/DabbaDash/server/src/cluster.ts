export interface Point { id: string; lat: number; lng: number; zoneId: string }

export function haversineKm(a: Point, b: Point) {
  const R = 6371;
  const rad = (n: number) => n * Math.PI / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}

export interface DeliveryBatch {
  id: string;
  zoneId: string;
  orderIds: string[];
  center: { lat: number; lng: number };
  radiusKm: number;
  distanceSpanKm: number;
}

/**
 * Greedy radius clustering for hyperlocal dispatch.
 * An order joins the closest existing batch only when it remains within
 * the configured radius of that batch's current centroid. This prevents
 * a long chain of individually-nearby orders from becoming one oversized route.
 */
export function clusterOrders(points: Point[], radiusKm = 2.5): Point[][] {
  const groups: Point[][] = [];
  for (const p of points) {
    let bestIndex = -1;
    let bestDistance = Number.POSITIVE_INFINITY;
    for (let i = 0; i < groups.length; i++) {
      const center = centroid(groups[i]);
      const distance = haversineKm(p, center);
      if (distance <= radiusKm && distance < bestDistance) {
        bestIndex = i;
        bestDistance = distance;
      }
    }
    if (bestIndex === -1) groups.push([p]);
    else groups[bestIndex].push(p);
  }
  return groups;
}

export function centroid(points: Point[]) {
  return {
    lat: points.reduce((s, p) => s + p.lat, 0) / points.length,
    lng: points.reduce((s, p) => s + p.lng, 0) / points.length,
  };
}

export function maxRadiusKm(points: Point[]) {
  if (points.length < 2) return 0;
  const c = centroid(points);
  return Math.max(...points.map(p => haversineKm(p, { ...c, id: 'centroid', zoneId: p.zoneId })));
}

export function routeScore(orderZone: string, courierZone: string, activeOrders: number, capacity: number) {
  return (orderZone === courierZone ? 0 : 100) + activeOrders * 10 + (capacity - activeOrders === 1 ? 5 : 0);
}
