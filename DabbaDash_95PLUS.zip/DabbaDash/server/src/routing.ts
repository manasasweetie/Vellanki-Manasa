import { haversineKm, type Point } from './cluster.js';

export function courierScore(order: Pick<Point,'lat'|'lng'|'zoneId'>, courier: Pick<Point,'lat'|'lng'|'zoneId'> & { activeOrders:number; capacity:number }) {
  const zonePenalty = order.zoneId === courier.zoneId ? 0 : 30;
  const loadPenalty = courier.activeOrders * 8;
  const distancePenalty = haversineKm({id:'order',...order}, {id:'courier',...courier});
  return zonePenalty + loadPenalty + distancePenalty;
}
