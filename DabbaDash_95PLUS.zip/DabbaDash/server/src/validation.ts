import {z} from 'zod';
export const statusSchema=z.object({status:z.enum(['RECEIVED','IN_KITCHEN','PACKED','OUT_FOR_DELIVERY','DELIVERED'])});
export const dispatchSchema=z.object({courierId:z.string().min(1)});
export const orderIdSchema=z.string().regex(/^\d{1,8}$/);
