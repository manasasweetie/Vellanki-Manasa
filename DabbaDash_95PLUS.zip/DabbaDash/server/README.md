# DabbaDash API

Express + SQLite + WebSocket backend.

Endpoints: `/api/orders`, `/api/brands`, `/api/couriers`, `/api/zones`, `/api/metrics`, `/api/batches`, `/api/orders/:id/recommendation`, status transition and dispatch endpoints, `/api/sms-simulator`, and `/ws`.

The database is migrated and seeded on startup. Status transitions are validated server-side and recorded in `order_events` for an auditable lifecycle.
