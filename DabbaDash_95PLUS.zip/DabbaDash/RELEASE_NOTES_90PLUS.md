# DabbaDash 90+ Focused Release

The previous evaluation was 87/100. The report specifically identified automated batching as the missing completeness point. This release makes batching a real backend feature instead of a visual queue.

### What changed
1. Added order latitude/longitude to SQLite.
2. Added Haversine distance and centroid-based 2.5 km clustering.
3. Added persisted `delivery_batches` and `batch_members` tables.
4. Added `POST /api/batches/recalculate` and `GET /api/batches/:id`.
5. Recalculate batches after order lifecycle/dispatch changes and server ticks.
6. Broadcast `batch.updated` over WebSocket.
7. Frontend now renders actual batch IDs, members and computed radius.
8. Added automated tests for near/far orders and anti-chain clustering.
9. Added a batch API contract test.

### Demo proof
Open the dashboard → Smart Batch Queue → click **Recalculate**. The UI shows actual server-calculated batch IDs, member order numbers and radius. Dispatch Order #104 and the batch state is recalculated again.
