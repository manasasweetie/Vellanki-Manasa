# DabbaDash 95+ Upgrade

## Evaluation-driven improvements
- Fixed courier-capacity release on delivery.
- Added double-dispatch protection.
- Added distance-aware courier recommendation.
- Added persisted courier latitude/longitude and live map markers.
- Added API hardening: request IDs, security headers, body limits, CORS control, rate limiting, route validation, and JSON error handling.
- Added routing service and automated routing tests.
- Added configurable batch radius in the dashboard.
- Expanded rubric mapping and demo evidence documentation.
