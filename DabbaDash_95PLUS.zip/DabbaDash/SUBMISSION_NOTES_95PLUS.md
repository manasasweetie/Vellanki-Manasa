# Submission Notes — DabbaDash 95+ Target

## Recommended demo order

1. Start the project with `npm install` then `npm run dev`.
2. Open the kitchen dashboard.
3. Show the five lifecycle columns and the three virtual brands.
4. Move Order #104 from In Kitchen to Packed.
5. Use **Assign Courier** and show the server recommendation, including distance and capacity.
6. Dispatch it and switch to Customer View to show the lifecycle/tracking experience.
7. Use **Recalculate** in Automated Hyperlocal Batches. Change the radius from 2.5 km to demonstrate that clustering is configurable.
8. Point out the computed batch radius, centroid and order membership.
9. Show the live map with persisted courier coordinates.
10. Show the kitchen bottleneck alert and SMS simulator.

## Verification commands

```bash
npm run check
npm test
npm run build
```

The submission intentionally does not include `node_modules` or the generated SQLite database. This keeps the archive portable and avoids machine-specific native binaries.
