# 🍱 DabbaDash — LastMile Bite Battle

A hyperlocal delivery management and order-tracking dashboard for cloud kitchens that run
multiple virtual restaurant brands out of a single commissary.

Built for the **LastMile Bite Battle** hackathon.

---

## The problem

Cloud kitchens run several virtual brands (Biryani Box, Burger Den, Chai Point) from one
kitchen. During lunch and dinner surges the dispatch workflow falls apart: riders crowd the
counter, tickets get handed to the wrong rider, and nobody has a single live view of what is
cooking, what is packed, and what is still waiting for a courier. Food arrives cold and every
extra trip adds cost.

DabbaDash puts every brand's orders on one board, tracks each ticket through five preparation
stages, recommends the right rider by sector and capacity, batches nearby drops into one trip,
and gives the customer a live tracking page.

---

## Quick start

```bash
npm install          # install dependencies
npm run dev          # API on :4000 + Vite dev server on :5173
```

Open **http://localhost:5173**.

The SQLite database is created and seeded automatically on first boot — 3 brands, 20 menu
items, 4 delivery sectors, 6 couriers and 15 live orders. No manual setup step.

### Production build

```bash
npm run build        # bundles the client into dist/
npm start            # serves API + built client from :4000
```

Then open **http://localhost:4000**.

### Useful scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | API + Vite dev server with hot reload |
| `npm run build` | Production client bundle |
| `npm start` | Serve API and built client on :4000 |
| `npm run seed` | Seed the database if it is empty |
| `npm run reset` | Wipe and re-seed the demo data |
| `npm run typecheck` | TypeScript check for server and client |

You can also reset the demo data at any time from the UI, or with:

```bash
curl -X POST http://localhost:4000/api/reset
```

**Requirements:** Node.js 18+ (tested on Node 20). `better-sqlite3` compiles a native module
on install; on Debian/Ubuntu you may need `build-essential` and `python3` if no prebuilt
binary is available for your platform.

---

## The demo flow

This is the sequence to run in front of judges.

1. Open the **Dispatch Board**. Order **#104** (Burger Den — 2 Classic Cheeseburgers, 1 Peri
   Peri Fries) sits in the **In Kitchen** column.
2. Click **Mark Packed**. The ticket moves to **Packed** and the assignment dialog opens with a
   recommended courier, showing the full scoring breakdown (sector match, proximity, capacity,
   rating, current load).
3. Accept the recommendation — or pick any other available rider. The order moves to **Out for
   Delivery** and the rider is marked on-trip.
4. Open the customer view at **`/track/104`** (the ↗ button on the card). It shows the live
   five-step stepper, the rider's name, an animated scooter moving along the route and a
   countdown ETA.
5. Advance the order to **Delivered** from the board — the customer page updates within
   seconds, the rider is released back to *Available* and their trip count increments.

Everything is pushed over Server-Sent Events, so the kitchen board and the customer page stay
in sync without a refresh.

---

## Features

### Core

- **Multi-brand order aggregation** — one board for every virtual brand, colour-coded and
  filterable by brand, sector and free-text search.
- **Five-stage preparation lifecycle** — Received → In Kitchen → Packed → Out for Delivery →
  Delivered, advanced with one click and timestamped at every transition.
- **Rider dispatch console** — every available courier scored for the order; the best match is
  recommended with a readable reason and a points breakdown. Manual override always available.
- **Hyperlocal radius batcher** — packed orders grouped by sector and merged while within
  2.5 km of the cluster anchor, then dispatched to one rider as a single multi-drop trip.
- **Customer tracking page** — animated stepper, moving scooter, live ETA countdown, rider card
  with call button, itemised bill and delivery address.
- **Live KPI bar** — active orders, orders in kitchen, average prep time, pending dispatches,
  bottleneck count and revenue today.

### Stretch

- **Interactive sector map** — Leaflet map with the commissary, sector radius circles, active
  drop pins, live courier positions and dashed route lines to each rider's assigned drops.
- **Kitchen bottleneck alerts** — any order sitting in the kitchen longer than 20 minutes
  flashes red on the board and is listed on the analytics page.
- **Rider payout calculator** — base ₹25 per drop + ₹8 per km + zone surge multiplier + ₹15
  batch bonus, with a per-courier breakdown.
- **SMS tracking simulator** — generates the tracking message and link for an order and logs
  it; the log is visible on the analytics page.

---

## Architecture

```
dabbadash/
├── server/
│   ├── index.ts      Express app — REST endpoints + SSE broadcast
│   ├── db.ts         SQLite connection, schema, event log helper
│   ├── seed.ts       Demo dataset (brands, menu, zones, couriers, orders)
│   └── logic.ts      Haversine clustering, courier scoring, payout, KPIs
├── client/
│   ├── index.html
│   └── src/
│       ├── App.tsx           Shell, routing, navigation
│       ├── store.tsx         Global store + SSE subscription
│       ├── api.ts            Typed fetch client
│       ├── types.ts          Shared domain types
│       ├── components/       Icons, badges, KPI bar, assign modal
│       ├── pages/            DispatchBoard, Couriers, Batching, LiveMap,
│       │                     CustomerTrack, Analytics
│       └── lib/              Formatting helpers, ticker hooks
├── data/             SQLite file (created at runtime, git-ignored)
└── dist/             Production client bundle (created by npm run build)
```

**Stack:** TypeScript · React 18 · Tailwind CSS · Vite · Node.js + Express · SQLite
(`better-sqlite3`) · Leaflet / react-leaflet · Server-Sent Events.

### Real-time sync

Every mutation (`advance`, `assign`, `unassign`, batch dispatch, SMS, courier status) writes to
SQLite, appends an event-log row, then broadcasts a `change` frame on `/api/stream`. Clients
hold one `EventSource` connection and refetch on each frame. A 15-second polling fallback keeps
the UI correct if a proxy blocks SSE.

### Data model

`brands` → `menu_items`; `zones` → `couriers`; `orders` → `order_items`, with `orders` also
referencing `brands`, `zones` and `couriers`. `events` and `sms_log` are append-only audit
trails. Every order and menu item carries a `brandId`, so all brands route into one central
kitchen ticket queue.

---

## Algorithms

### Hyperlocal sector clustering

Packed, un-batched orders are grouped by delivery sector. The first order in a sector becomes
the cluster anchor; each later order joins the first cluster whose anchor lies within
**2.5 km** (great-circle distance via the haversine formula). Clusters are returned largest
first so the highest-leverage batching opportunity is at the top.

### Courier dispatch scoring

Each available courier is scored for the target order or cluster:

| Signal | Points |
| --- | --- |
| Same sector as the delivery | +40 |
| Proximity to the commissary | up to +30 (30 − 4 × km) |
| Capacity fits the whole batch | +15 (or −10 if it does not) |
| Rating | +2 × rating |
| Load balance | −3 per trip already completed today |

The highest score wins and its breakdown is shown in the assignment dialog, so the dispatcher
can see *why* a rider was suggested rather than trusting a black box.

### Rider payout

`base (₹25 × drops) + distance (₹8 × km) + surge ((base + distance) × (multiplier − 1)) +
batch bonus (₹15 when carrying 2+ orders)`.

---

## API reference

| Method | Endpoint | Purpose |
| --- | --- | --- |
| GET | `/api/health` | Liveness + connected SSE clients |
| GET | `/api/bootstrap` | Brands, menu, zones, couriers, all orders |
| GET | `/api/orders` | Orders, filterable by `status`, `brandId`, `zoneId` |
| GET | `/api/orders/:id` | One order (accepts id or `#code`) |
| GET | `/api/kpis` | Operational metrics + per-brand rollup |
| GET | `/api/batches` | Current zone clusters with courier suggestions |
| GET | `/api/couriers` | Roster with active load and payout |
| GET | `/api/couriers/:id/payout` | Payout breakdown for one rider |
| GET | `/api/recommend/:orderId` | Courier recommendation with score breakdown |
| GET | `/api/events` | Dispatch event log |
| GET | `/api/sms` | SMS tracking log |
| GET | `/api/stream` | SSE stream of `change` frames |
| POST | `/api/orders/:id/advance` | Move to the next lifecycle stage |
| POST | `/api/orders/:id/assign` | Assign a courier and dispatch |
| POST | `/api/orders/:id/unassign` | Return an order to the packed queue |
| POST | `/api/batches/:zoneId/dispatch` | Dispatch a whole cluster to one rider |
| POST | `/api/orders/:id/sms` | Generate and log a tracking SMS |
| POST | `/api/couriers/:id/status` | Set a courier available / on-trip / offline |
| POST | `/api/reset` | Wipe and re-seed demo data |

---

## Notes and limitations

- The SMS feature **simulates** delivery: it composes the message and link and records it in
  the log. No real SMS gateway is wired up — plugging in Twilio or MSG91 would mean replacing
  the insert in `POST /api/orders/:id/sms` with an API call.
- Courier positions are seeded coordinates, not live GPS. The customer page derives transit
  progress from `dispatchedAt` and the order's ETA, which is what the brief asked for in the
  absence of mobile hardware.
- Payments, authentication and multi-tenant kitchens are out of scope for this prototype.
- The map uses OpenStreetMap tiles, so it needs internet access to render.

---

## License

MIT — built as a hackathon submission.
