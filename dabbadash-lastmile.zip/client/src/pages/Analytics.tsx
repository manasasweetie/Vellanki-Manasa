import { useMemo } from 'react';
import { useStore } from '../store';
import { STATUS_FLOW, STATUS_META } from '../types';
import { IconAlert, IconBowl, IconChart, IconClock, IconSms } from '../components/Icons';
import { inr, timeAgo } from '../lib/format';

function Bar({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const pct = max > 0 ? (value / max) * 100 : 0;
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between text-[10px]">
        <span className="text-slate-400">{label}</span>
        <span className="font-mono font-semibold text-slate-200">{value}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, backgroundColor: color }}
        />
      </div>
    </div>
  );
}

export default function Analytics() {
  const { data, kpis, events, sms, loading } = useStore();

  const statusCounts = useMemo(() => {
    const map = new Map(STATUS_FLOW.map((s) => [s, 0]));
    for (const o of data?.orders ?? []) map.set(o.status, (map.get(o.status) ?? 0) + 1);
    return map;
  }, [data]);

  const maxStatus = Math.max(1, ...Array.from(statusCounts.values()));

  const zoneStats = useMemo(() => {
    const map = new Map<string, { name: string; sector: string; orders: number; revenue: number }>();
    for (const o of data?.orders ?? []) {
      const cur = map.get(o.zoneId) ?? { name: o.zone.name, sector: o.zone.sector, orders: 0, revenue: 0 };
      cur.orders += 1;
      cur.revenue += o.total;
      map.set(o.zoneId, cur);
    }
    return Array.from(map.values()).sort((a, b) => b.orders - a.orders);
  }, [data]);

  const maxZone = Math.max(1, ...zoneStats.map((z) => z.orders));

  const bottlenecks = data?.orders.filter((o) => o.bottleneck) ?? [];

  if (loading && !data) return <div className="panel h-64 animate-pulse bg-white/[0.02]" />;

  return (
    <div className="space-y-3">
      <div>
        <h1 className="text-lg font-extrabold tracking-tight text-white">Kitchen Performance</h1>
        <p className="text-[11px] text-slate-500">
          Operational KPIs, brand mix, sector load and the live dispatch event log.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-2.5 lg:grid-cols-3">
        {/* status distribution */}
        <div className="panel p-3.5">
          <div className="mb-2.5 flex items-center gap-1.5">
            <IconChart size={13} className="text-ember-400" />
            <h2 className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-300">Order pipeline</h2>
          </div>
          <div className="space-y-2">
            {STATUS_FLOW.map((s) => (
              <Bar
                key={s}
                label={STATUS_META[s].label}
                value={statusCounts.get(s) ?? 0}
                max={maxStatus}
                color={
                  s === 'RECEIVED'
                    ? '#0ea5e9'
                    : s === 'IN_KITCHEN'
                      ? '#f59e0b'
                      : s === 'PACKED'
                        ? '#8b5cf6'
                        : s === 'OUT_FOR_DELIVERY'
                          ? '#10b981'
                          : '#64748b'
                }
              />
            ))}
          </div>
        </div>

        {/* brand mix */}
        <div className="panel p-3.5">
          <div className="mb-2.5 flex items-center gap-1.5">
            <IconBowl size={13} className="text-ember-400" />
            <h2 className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-300">Brand mix</h2>
          </div>
          <div className="space-y-2">
            {kpis?.byBrand.map((b) => (
              <div key={b.id}>
                <div className="mb-1 flex items-baseline justify-between text-[10px]">
                  <span className="font-semibold" style={{ color: b.color }}>
                    {b.name}
                  </span>
                  <span className="font-mono text-slate-300">
                    {b.orders} · {inr(b.revenue)}
                  </span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${(b.orders / Math.max(1, ...(kpis?.byBrand.map((x) => x.orders) ?? [1]))) * 100}%`,
                      backgroundColor: b.color,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 border-t border-white/[0.06] pt-2.5">
            <div>
              <div className="label !text-[9px]">Avg prep</div>
              <div className="font-mono text-base font-bold text-emerald-400">{kpis?.avgPrepMinutes ?? 0}<span className="text-[9px] text-slate-500">min</span></div>
            </div>
            <div>
              <div className="label !text-[9px]">Revenue</div>
              <div className="font-mono text-base font-bold text-ember-400">{inr(kpis?.revenueToday ?? 0)}</div>
            </div>
          </div>
        </div>

        {/* sector load */}
        <div className="panel p-3.5">
          <div className="mb-2.5 flex items-center gap-1.5">
            <IconClock size={13} className="text-ember-400" />
            <h2 className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-300">Sector load</h2>
          </div>
          <div className="space-y-2">
            {zoneStats.map((z) => (
              <Bar key={z.sector} label={`${z.sector} — ${z.name}`} value={z.orders} max={maxZone} color="#6366f1" />
            ))}
          </div>
          <div className="mt-3 border-t border-white/[0.06] pt-2.5">
            <div className="label !text-[9px]">Revenue by sector</div>
            <div className="mt-1 space-y-0.5">
              {zoneStats.map((z) => (
                <div key={z.sector} className="flex justify-between text-[10px]">
                  <span className="text-slate-500">{z.sector}</span>
                  <span className="font-mono text-slate-300">{inr(z.revenue)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* bottlenecks */}
      <div className="panel overflow-hidden">
        <div className="panel-head !py-2">
          <div className="flex items-center gap-1.5">
            <IconAlert size={13} className={bottlenecks.length ? 'text-red-400' : 'text-slate-500'} />
            <h2 className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-300">
              Kitchen bottlenecks
            </h2>
            <span className="rounded bg-white/[0.07] px-1.5 py-0.5 font-mono text-[9px] font-bold text-slate-400">
              {bottlenecks.length}
            </span>
          </div>
          <span className="text-[9px] text-slate-600">&gt;20 min in kitchen</span>
        </div>
        {bottlenecks.length === 0 ? (
          <div className="px-3.5 py-4 text-center text-[11px] text-slate-600">
            No orders have been stuck in the kitchen for more than 20 minutes. 🎉
          </div>
        ) : (
          <div className="divide-y divide-white/[0.05]">
            {bottlenecks.map((o) => (
              <div key={o.id} className="flex items-center gap-2 px-3.5 py-2">
                <span className="h-1.5 w-1.5 shrink-0 animate-pulse rounded-full bg-red-500" />
                <span className="font-mono text-[11px] font-bold text-white">{o.code}</span>
                <span className="text-[10px] font-semibold" style={{ color: o.brand.color }}>
                  {o.brand.name}
                </span>
                <span className="truncate text-[10px] text-slate-500">{o.customerName}</span>
                <span className="ml-auto shrink-0 rounded bg-red-500/15 px-1.5 py-0.5 font-mono text-[10px] font-bold text-red-300">
                  {o.minutesInStage}m
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 gap-2.5 lg:grid-cols-2">
        {/* event log */}
        <div className="panel overflow-hidden">
          <div className="panel-head !py-2">
            <h2 className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-300">Dispatch event log</h2>
            <span className="font-mono text-[9px] text-slate-600">{events.length} events</span>
          </div>
          <div className="max-h-72 divide-y divide-white/[0.04] overflow-y-auto scroll-thin">
            {events.map((e) => (
              <div key={e.id} className="flex items-start gap-2 px-3.5 py-1.5">
                <span
                  className={`mt-1 h-1.5 w-1.5 shrink-0 rounded-full ${
                    e.type === 'STATUS'
                      ? 'bg-sky-400'
                      : e.type === 'DISPATCH'
                        ? 'bg-emerald-400'
                        : e.type === 'BATCH'
                          ? 'bg-violet-400'
                          : e.type === 'SMS'
                            ? 'bg-amber-400'
                            : 'bg-slate-500'
                  }`}
                />
                <span className="min-w-0 flex-1 text-[10px] leading-relaxed text-slate-400">{e.message}</span>
                <span className="shrink-0 font-mono text-[9px] text-slate-600">{timeAgo(e.createdAt)}</span>
              </div>
            ))}
            {events.length === 0 && (
              <div className="px-3.5 py-6 text-center text-[11px] text-slate-600">No events yet.</div>
            )}
          </div>
        </div>

        {/* sms log */}
        <div className="panel overflow-hidden">
          <div className="panel-head !py-2">
            <div className="flex items-center gap-1.5">
              <IconSms size={13} className="text-amber-400" />
              <h2 className="text-[11px] font-bold uppercase tracking-[0.1em] text-slate-300">SMS tracking log</h2>
            </div>
            <span className="font-mono text-[9px] text-slate-600">{sms.length} sent</span>
          </div>
          <div className="max-h-72 divide-y divide-white/[0.04] overflow-y-auto scroll-thin">
            {sms.map((s) => (
              <div key={s.id} className="px-3.5 py-2">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[10px] font-semibold text-slate-300">{s.phone}</span>
                  <span className="ml-auto font-mono text-[9px] text-slate-600">{timeAgo(s.createdAt)}</span>
                </div>
                <div className="mt-0.5 text-[10px] leading-relaxed text-slate-500">{s.message}</div>
              </div>
            ))}
            {sms.length === 0 && (
              <div className="px-3.5 py-6 text-center text-[11px] text-slate-600">
                No SMS sent yet — hit the ✉ button on any order card.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
