import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { api } from '../api';
import { STATUS_FLOW, STATUS_META, type Order, type Status } from '../types';
import { BrandTag, BottleneckBadge, StatusChip } from '../components/Badges';
import { KpiBar, BrandStrip } from '../components/KpiBar';
import { IconArrow, IconBowl, IconCheck, IconClock, IconPin, IconSms, IconX } from '../components/Icons';
import { clockTime, inr, timeAgo } from '../lib/format';
import { useTicker } from '../lib/hooks';
import AssignModal from '../components/AssignModal';

const COLUMNS: { status: Status; title: string; hint: string }[] = [
  { status: 'RECEIVED', title: 'Received', hint: 'New tickets from all brands' },
  { status: 'IN_KITCHEN', title: 'In Kitchen', hint: 'Being prepared' },
  { status: 'PACKED', title: 'Packed', hint: 'Awaiting courier' },
  { status: 'OUT_FOR_DELIVERY', title: 'Out for Delivery', hint: 'On the road' },
  { status: 'DELIVERED', title: 'Delivered', hint: 'Completed today' },
];

function OrderCard({ order, onAssign }: { order: Order; onAssign: (o: Order) => void }) {
  useTicker(15_000);
  const [busy, setBusy] = useState(false);
  const [smsSent, setSmsSent] = useState(false);
  const { refresh } = useStore();

  const nextStatus = STATUS_FLOW[STATUS_FLOW.indexOf(order.status) + 1];
  const isLast = order.status === 'DELIVERED';

  async function advance() {
    setBusy(true);
    try {
      const res = await api.advance(order.id);
      await refresh();
      if (res.recommendation) onAssign(res.order);
    } finally {
      setBusy(false);
    }
  }

  async function sendSms() {
    setBusy(true);
    try {
      await api.sendSms(order.id);
      setSmsSent(true);
      await refresh();
      setTimeout(() => setSmsSent(false), 2500);
    } finally {
      setBusy(false);
    }
  }

  const itemCount = order.items.reduce((s, i) => s + i.qty, 0);

  return (
    <div
      className={`group animate-slideIn rounded-xl border bg-ink-850/80 p-2.5 transition-all hover:border-white/20 hover:bg-ink-800/90 ${
        order.bottleneck ? 'border-red-500/60 animate-pulseRed' : 'border-white/[0.07]'
      }`}
    >
      {/* header */}
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="font-mono text-[13px] font-bold text-white">{order.code}</span>
            {order.bottleneck && <BottleneckBadge minutes={order.minutesInStage} />}
          </div>
          <div className="mt-1">
            <BrandTag name={order.brand.name} color={order.brand.color} accent={order.brand.accent} />
          </div>
        </div>
        <div className="shrink-0 text-right">
          <div className="font-mono text-[11px] font-semibold text-slate-300">{inr(order.total)}</div>
          <div className="mt-0.5 text-[9px] text-slate-500">{clockTime(order.createdAt)}</div>
        </div>
      </div>

      {/* items */}
      <ul className="mt-2 space-y-0.5 border-t border-white/[0.05] pt-2">
        {order.items.slice(0, 3).map((it) => (
          <li key={it.id} className="flex items-baseline justify-between gap-2 text-[11px]">
            <span className="truncate text-slate-300">
              <span className="font-mono text-[10px] text-ember-400">{it.qty}×</span> {it.name}
            </span>
          </li>
        ))}
        {order.items.length > 3 && (
          <li className="text-[10px] text-slate-500">+{order.items.length - 3} more item(s)</li>
        )}
      </ul>

      {/* customer + zone */}
      <div className="mt-2 space-y-1 border-t border-white/[0.05] pt-2">
        <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
          <IconPin size={11} className="shrink-0 text-slate-500" />
          <span className="truncate">{order.customerName}</span>
          <span className="ml-auto shrink-0 rounded bg-white/[0.06] px-1 py-0.5 font-mono text-[9px] text-slate-400">
            {order.zone.sector}
          </span>
        </div>
        {order.notes && (
          <div className="rounded-md border border-amber-500/20 bg-amber-500/[0.07] px-1.5 py-1 text-[10px] italic text-amber-300/90">
            “{order.notes}”
          </div>
        )}
        {order.courier && (
          <div className="flex items-center gap-1.5 rounded-md bg-emerald-500/[0.08] px-1.5 py-1 text-[10px] text-emerald-300">
            <IconBowl size={10} />
            <span className="font-semibold">{order.courier.name}</span>
            <span className="text-emerald-400/60">· {order.courier.vehicle}</span>
          </div>
        )}
      </div>

      {/* actions */}
      <div className="mt-2 flex items-center gap-1.5">
        {!isLast && (
          <button
            onClick={() => void advance()}
            disabled={busy}
            className="btn-primary flex-1 !py-1 !text-[10px]"
            title={`Move to ${STATUS_META[nextStatus].label}`}
          >
            {busy ? '…' : order.status === 'PACKED' ? 'Assign Rider' : `Mark ${STATUS_META[nextStatus].short}`}
            <IconArrow size={11} />
          </button>
        )}
        {order.status === 'PACKED' && (
          <button onClick={() => onAssign(order)} className="btn-ghost !px-2 !py-1" title="Choose courier">
            <IconBowl size={12} />
          </button>
        )}
        {isLast && (
          <span className="flex flex-1 items-center justify-center gap-1 rounded-lg bg-emerald-500/10 py-1 text-[10px] font-semibold text-emerald-400">
            <IconCheck size={11} /> Completed
          </span>
        )}
        <button
          onClick={() => void sendSms()}
          disabled={busy}
          className={`btn-ghost !px-2 !py-1 ${smsSent ? '!border-emerald-500/40 !text-emerald-400' : ''}`}
          title="Send tracking SMS"
        >
          {smsSent ? <IconCheck size={12} /> : <IconSms size={12} />}
        </button>
        <Link
          to={`/track/${order.code.replace('#', '')}`}
          className="btn-ghost !px-2 !py-1"
          title="Open customer tracking view"
        >
          <IconArrow size={12} />
        </Link>
      </div>

      <div className="mt-1.5 flex items-center justify-between text-[9px] text-slate-600">
        <span className="inline-flex items-center gap-1">
          <IconClock size={9} />
          {order.minutesInStage}m in stage
        </span>
        <span>{itemCount} item{itemCount === 1 ? '' : 's'}</span>
      </div>
    </div>
  );
}

export default function DispatchBoard() {
  const { data, loading } = useStore();
  const [assignOrder, setAssignOrder] = useState<Order | null>(null);
  const [brandFilter, setBrandFilter] = useState<string>('all');
  const [zoneFilter, setZoneFilter] = useState<string>('all');
  const [query, setQuery] = useState('');

  const orders = useMemo(() => {
    if (!data) return [];
    return data.orders.filter((o) => {
      if (brandFilter !== 'all' && o.brandId !== brandFilter) return false;
      if (zoneFilter !== 'all' && o.zoneId !== zoneFilter) return false;
      if (query) {
        const q = query.toLowerCase();
        return (
          o.code.toLowerCase().includes(q) ||
          o.customerName.toLowerCase().includes(q) ||
          o.items.some((i) => i.name.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [data, brandFilter, zoneFilter, query]);

  const byStatus = useMemo(() => {
    const map = new Map<Status, Order[]>();
    for (const s of STATUS_FLOW) map.set(s, []);
    for (const o of orders) map.get(o.status)?.push(o);
    // Oldest first inside each column — the most urgent ticket is on top.
    for (const [, list] of map) list.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    return map;
  }, [orders]);

  if (loading && !data) {
    return (
      <div className="space-y-4">
        <KpiBar />
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3 xl:grid-cols-5">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="panel h-96 animate-pulse bg-white/[0.02]" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <KpiBar />

      <div className="panel flex flex-wrap items-center gap-2 px-3 py-2">
        <BrandStrip />
      </div>

      {/* filters */}
      <div className="flex flex-wrap items-center gap-2">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search order #, customer or item…"
          className="w-56 rounded-lg border border-white/10 bg-ink-900/80 px-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-600 focus:border-ember-500/50 focus:outline-none"
        />
        <select
          value={brandFilter}
          onChange={(e) => setBrandFilter(e.target.value)}
          className="rounded-lg border border-white/10 bg-ink-900/80 px-2.5 py-1.5 text-xs text-slate-300 focus:border-ember-500/50 focus:outline-none"
        >
          <option value="all">All brands</option>
          {data?.brands.map((b) => (
            <option key={b.id} value={b.id}>
              {b.name}
            </option>
          ))}
        </select>
        <select
          value={zoneFilter}
          onChange={(e) => setZoneFilter(e.target.value)}
          className="rounded-lg border border-white/10 bg-ink-900/80 px-2.5 py-1.5 text-xs text-slate-300 focus:border-ember-500/50 focus:outline-none"
        >
          <option value="all">All zones</option>
          {data?.zones.map((z) => (
            <option key={z.id} value={z.id}>
              {z.sector} — {z.name}
            </option>
          ))}
        </select>
        {(brandFilter !== 'all' || zoneFilter !== 'all' || query) && (
          <button
            onClick={() => {
              setBrandFilter('all');
              setZoneFilter('all');
              setQuery('');
            }}
            className="btn-ghost !py-1.5"
          >
            <IconX size={11} /> Clear
          </button>
        )}
        <span className="ml-auto font-mono text-[10px] text-slate-500">
          {orders.length} of {data?.orders.length ?? 0} orders
        </span>
      </div>

      {/* kanban */}
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-5">
        {COLUMNS.map((col) => {
          const list = byStatus.get(col.status) ?? [];
          const meta = STATUS_META[col.status];
          return (
            <section key={col.status} className="panel flex min-h-[420px] flex-col overflow-hidden">
              <div className="panel-head !py-2.5">
                <div className="flex items-center gap-2">
                  <span className={`h-2 w-2 rounded-full ${meta.color}`} />
                  <h2 className="text-[12px] font-bold text-white">{col.title}</h2>
                  <span className="rounded-md bg-white/[0.07] px-1.5 py-0.5 font-mono text-[10px] font-bold text-slate-300">
                    {list.length}
                  </span>
                </div>
              </div>
              <div className="flex-1 space-y-2 overflow-y-auto p-2 scroll-thin" style={{ maxHeight: 'calc(100vh - 300px)' }}>
                {list.length === 0 ? (
                  <div className="grid place-items-center py-10 text-center">
                    <div className="text-[10px] text-slate-600">{col.hint}</div>
                  </div>
                ) : (
                  list.map((o) => <OrderCard key={o.id} order={o} onAssign={setAssignOrder} />)
                )}
              </div>
            </section>
          );
        })}
      </div>

      {assignOrder && <AssignModal order={assignOrder} onClose={() => setAssignOrder(null)} />}
    </div>
  );
}
