import { useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { useStore } from '../store';
import { IconBike, IconBowl, IconPin } from '../components/Icons';
import { inr } from '../lib/format';

const KITCHEN: [number, number] = [12.9716, 77.6412];

function divIcon(html: string, size = 30) {
  return L.divIcon({
    html,
    className: 'dabbadash-marker',
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -size / 2],
  });
}

const kitchenIcon = divIcon(
  `<div style="display:grid;place-items:center;width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,#fbbf24,#d97706);box-shadow:0 4px 16px -2px rgba(245,158,11,.7);border:2px solid #080b12;font-size:16px">🍱</div>`,
  34,
);

const courierIcon = (color: string, onTrip: boolean) =>
  divIcon(
    `<div style="display:grid;place-items:center;width:28px;height:28px;border-radius:50%;background:${color};border:2px solid #080b12;box-shadow:0 2px 10px -1px ${color}aa;font-size:13px;${onTrip ? 'animation:pulse 1.6s infinite' : ''}">🛵</div>`,
    28,
  );

const zoneIcon = (color: string) =>
  divIcon(
    `<div style="display:grid;place-items:center;width:22px;height:22px;border-radius:50%;background:${color}33;border:2px solid ${color};font-size:9px;color:${color};font-weight:700">●</div>`,
    22,
  );

export default function LiveMap() {
  const { data, couriers, loading } = useStore();

  const activeOrders = useMemo(
    () => data?.orders.filter((o) => o.status !== 'DELIVERED') ?? [],
    [data],
  );

  const zoneColors: Record<string, string> = {
    'zn-a': '#f59e0b',
    'zn-b': '#10b981',
    'zn-c': '#6366f1',
    'zn-d': '#ec4899',
  };

  if (loading && !data) return <div className="panel h-[70vh] animate-pulse bg-white/[0.02]" />;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-lg font-extrabold tracking-tight text-white">Interactive Sector Map</h1>
          <p className="text-[11px] text-slate-500">
            Commissary, delivery sectors, live courier positions and active drop pins.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {data?.zones.map((z) => (
            <span
              key={z.id}
              className="inline-flex items-center gap-1.5 rounded-lg border px-2 py-1 text-[10px] font-semibold"
              style={{
                borderColor: `${zoneColors[z.id]}44`,
                backgroundColor: `${zoneColors[z.id]}12`,
                color: zoneColors[z.id],
              }}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: zoneColors[z.id] }} />
              {z.sector} · {z.name}
            </span>
          ))}
        </div>
      </div>

      <div className="panel overflow-hidden">
        <div className="h-[calc(100vh-230px)] min-h-[480px] w-full">
          <MapContainer center={KITCHEN} zoom={13} scrollWheelZoom className="h-full w-full">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            {/* delivery sector radii */}
            {data?.zones.map((z) => (
              <Circle
                key={z.id}
                center={[z.lat, z.lng]}
                radius={z.radiusKm * 1000}
                pathOptions={{
                  color: zoneColors[z.id],
                  fillColor: zoneColors[z.id],
                  fillOpacity: 0.07,
                  weight: 1.5,
                  dashArray: '5 6',
                }}
              />
            ))}

            {/* kitchen */}
            <Marker position={KITCHEN} icon={kitchenIcon}>
              <Popup>
                <strong>DabbaDash Commissary</strong>
                <br />
                Indiranagar · 3 virtual brands
                <br />
                <span style={{ color: '#94a3b8' }}>All orders originate here</span>
              </Popup>
            </Marker>

            {/* zone anchors */}
            {data?.zones.map((z) => (
              <Marker key={`z-${z.id}`} position={[z.lat, z.lng]} icon={zoneIcon(zoneColors[z.id])}>
                <Popup>
                  <strong>
                    {z.sector} — {z.name}
                  </strong>
                  <br />
                  Radius {z.radiusKm} km · surge ×{z.surgeMultiplier.toFixed(2)}
                </Popup>
              </Marker>
            ))}

            {/* active order drop pins */}
            {activeOrders.map((o) => (
              <Marker key={o.id} position={[o.zone.lat, o.zone.lng]} icon={zoneIcon(o.brand.color)}>
                <Popup>
                  <strong>
                    {o.code} · {o.brand.name}
                  </strong>
                  <br />
                  {o.customerName}
                  <br />
                  <span style={{ color: '#94a3b8' }}>{o.address}</span>
                  <br />
                  {inr(o.total)} · {o.status.replace(/_/g, ' ').toLowerCase()}
                </Popup>
              </Marker>
            ))}

            {/* couriers + their route lines */}
            {couriers
              .filter((c) => c.lat != null && c.lng != null)
              .map((c) => {
                const pos: [number, number] = [c.lat!, c.lng!];
                const color = c.status === 'AVAILABLE' ? '#10b981' : c.status === 'ON_TRIP' ? '#f59e0b' : '#64748b';
                const assigned = data?.orders.filter((o) => o.courierId === c.id && o.status !== 'DELIVERED') ?? [];
                return (
                  <div key={c.id}>
                    {assigned.map((o) => (
                      <Polyline
                        key={`${c.id}-${o.id}`}
                        positions={[pos, [o.zone.lat, o.zone.lng]]}
                        pathOptions={{ color, weight: 2, opacity: 0.5, dashArray: '4 6' }}
                      />
                    ))}
                    <Marker position={pos} icon={courierIcon(color, c.status === 'ON_TRIP')}>
                      <Popup>
                        <strong>{c.name}</strong> · {c.vehicle}
                        <br />
                        {c.status.replace('_', ' ')} · ★{c.rating.toFixed(1)}
                        <br />
                        {assigned.length} active order(s) · {c.tripsToday} trips today
                      </Popup>
                    </Marker>
                  </div>
                );
              })}
          </MapContainer>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-4">
        <div className="panel flex items-center gap-2 px-3 py-2">
          <IconBowl size={14} className="text-ember-400" />
          <div>
            <div className="label !text-[9px]">Commissary</div>
            <div className="text-[11px] font-semibold text-white">Indiranagar</div>
          </div>
        </div>
        <div className="panel flex items-center gap-2 px-3 py-2">
          <IconPin size={14} className="text-sky-400" />
          <div>
            <div className="label !text-[9px]">Active drops</div>
            <div className="font-mono text-[11px] font-semibold text-white">{activeOrders.length}</div>
          </div>
        </div>
        <div className="panel flex items-center gap-2 px-3 py-2">
          <IconBike size={14} className="text-emerald-400" />
          <div>
            <div className="label !text-[9px]">Couriers on map</div>
            <div className="font-mono text-[11px] font-semibold text-white">
              {couriers.filter((c) => c.lat != null).length}
            </div>
          </div>
        </div>
        <div className="panel flex items-center gap-2 px-3 py-2">
          <IconPin size={14} className="text-violet-400" />
          <div>
            <div className="label !text-[9px]">Sectors</div>
            <div className="font-mono text-[11px] font-semibold text-white">{data?.zones.length ?? 0}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
