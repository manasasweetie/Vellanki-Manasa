import { useState } from 'react';
import { useStore } from '../store';
import { api } from '../api';
import { BrandTag } from '../components/Badges';
import { IconBike, IconCheck, IconLayers, IconPin, IconSpark } from '../components/Icons';
import { avatarColor, initials, inr } from '../lib/format';
import type { Cluster } from '../types';

function ClusterCard({ cluster }: { cluster: Cluster }) {
  const { couriers, refresh } = useStore();
  const [courierId, setCourierId] = useState(cluster.suggestedCourierId ?? '');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);

  const available = couriers.filter((c) => c.status === 'AVAILABLE');
  const totalItems = cluster.orders.reduce((s, o) => s + o.items.reduce((a, i) => a + i.qty, 0), 0);

  async function dispatch() {
    if (!courierId) return;
    setBusy(true);
    try {
      const res = await api.dispatchBatch(cluster.zoneId, courierId, cluster.orders.map((o) => o.id));
      setDone(`${res.dispatched} order(s) → ${res.courier}`);
      await refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="panel overflow-hidden">
      <div className="flex items-start justify-between gap-3 border-b border-white/[0.06] px-3.5 py-2.5">
        <div>
          <div className="flex items-center gap-2">
            <span className="grid h-6 w-6 place-items-center rounded-md bg-ember-500/15 text-[10px] font-bold text-ember-400">
              {cluster.sector.replace('Sector ', '')}
            </span>
            <h3 className="text-[13px] font-bold text-white">{cluster.zoneName}</h3>
            <span className="rounded bg-white/[0.07] px-1.5 py-0.5 font-mono text-[9px] font-bold text-slate-300">
              {cluster.orders.length} order{cluster.orders.length === 1 ? '' : 's'}
            </span>
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[10px] text-slate-500">
            <span className="inline-flex items-center gap-1">
              <IconPin size={9} /> within {cluster.radiusKm} km
            </span>
            <span>spread {cluster.maxSpreadKm.toFixed(2)} km</span>
            <span className="text-ember-400">×{cluster.surgeMultiplier.toFixed(2)} surge</span>
          </div>
        </div>
        <div className="shrink-0 text-right">
          <div className="font-mono text-[13px] font-bold text-white">{inr(cluster.totalValue)}</div>
          <div className="text-[9px] text-slate-500">{totalItems} items</div>
        </div>
      </div>

      <div className="space-y-1 px-3.5 py-2">
        {cluster.orders.map((o) => (
          <div key={o.id} className="flex items-center gap-2 text-[11px]">
            <span className="font-mono font-semibold text-slate-200">{o.code}</span>
            <BrandTag name={o.brand.name} color={o.brand.color} accent={o.brand.accent} />
            <span className="truncate text-slate-500">{o.customerName}</span>
            <span className="ml-auto shrink-0 font-mono text-[10px] text-slate-400">{inr(o.total)}</span>
          </div>
        ))}
      </div>

      {cluster.suggestedCourierName && (
        <div className="mx-3.5 mb-2 flex items-center gap-1.5 rounded-lg border border-ember-500/25 bg-ember-500/[0.07] px-2 py-1.5 text-[10px]">
          <IconSpark size={11} className="shrink-0 text-ember-400" />
          <span className="text-slate-400">Suggested:</span>
          <span className="font-semibold text-ember-300">{cluster.suggestedCourierName}</span>
          <span className="text-slate-500">— same sector, capacity fits</span>
        </div>
      )}

      <div className="flex items-center gap-1.5 border-t border-white/[0.06] px-3.5 py-2">
        <select
          value={courierId}
          onChange={(e) => setCourierId(e.target.value)}
          className="min-w-0 flex-1 rounded-lg border border-white/10 bg-ink-850 px-2 py-1.5 text-[11px] text-slate-200 focus:border-ember-500/50 focus:outline-none"
        >
          <option value="">Choose a courier…</option>
          {available.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name} · {c.vehicle} · cap {c.capacity}
            </option>
          ))}
        </select>
        <button onClick={() => void dispatch()} disabled={!courierId || busy} className="btn-primary !py-1.5 !text-[10px]">
          {busy ? '…' : (
            <>
              <IconBike size={11} /> Batch dispatch
            </>
          )}
        </button>
      </div>

      {done && (
        <div className="flex items-center gap-1.5 border-t border-emerald-500/20 bg-emerald-500/[0.08] px-3.5 py-1.5 text-[10px] text-emerald-300">
          <IconCheck size={11} /> {done}
        </div>
      )}
    </div>
  );
}

export default function Batching() {
  const { batches, data, loading } = useStore();

  const packed = data?.orders.filter((o) => o.status === 'PACKED') ?? [];
  const batched = batches.reduce((s, c) => s + c.orders.length, 0);
  const savedTrips = Math.max(0, batched - batches.length);

  if (loading && !data) return <div className="panel h-64 animate-pulse bg-white/[0.02]" />;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-lg font-extrabold tracking-tight text-white">Hyperlocal Zone Batcher</h1>
          <p className="text-[11px] text-slate-500">
            Packed orders grouped by sector and 2.5 km radius — one rider, multiple drops, one trip.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="panel flex items-center gap-2 px-3 py-1.5">
            <IconLayers size={13} className="text-violet-400" />
            <span className="font-mono text-sm font-bold text-white">{batches.length}</span>
            <span className="text-[10px] text-slate-500">clusters</span>
          </div>
          <div className="panel flex items-center gap-2 px-3 py-1.5">
            <span className="font-mono text-sm font-bold text-white">{batched}</span>
            <span className="text-[10px] text-slate-500">of {packed.length} packed</span>
          </div>
          <div className="panel flex items-center gap-2 px-3 py-1.5">
            <IconBike size={13} className="text-emerald-400" />
            <span className="font-mono text-sm font-bold text-emerald-400">{savedTrips}</span>
            <span className="text-[10px] text-slate-500">trips saved</span>
          </div>
        </div>
      </div>

      <div className="panel px-3.5 py-2.5">
        <div className="flex items-start gap-2 text-[10px] leading-relaxed text-slate-400">
          <IconSpark size={12} className="mt-0.5 shrink-0 text-ember-400" />
          <p>
            <strong className="text-slate-300">Clustering heuristic:</strong> packed orders are grouped by delivery
            sector, then greedily merged while their destination lies within{' '}
            <span className="font-mono text-ember-400">2.5 km</span> of the cluster anchor. Each cluster is scored
            against available couriers on sector match, proximity to the commissary, capacity headroom, rating and
            current load.
          </p>
        </div>
      </div>

      {batches.length === 0 ? (
        <div className="panel grid place-items-center py-16 text-center">
          <div>
            <IconLayers size={28} className="mx-auto text-slate-700" />
            <p className="mt-2 text-sm font-semibold text-slate-400">No batchable orders right now</p>
            <p className="mt-1 text-[11px] text-slate-600">
              Orders appear here once they reach the <span className="text-violet-400">Packed</span> stage.
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-2.5 md:grid-cols-2 xl:grid-cols-3">
          {batches.map((c) => (
            <ClusterCard key={c.id} cluster={c} />
          ))}
        </div>
      )}
    </div>
  );
}
