import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useStore } from '../store';
import { STATUS_FLOW, STATUS_META, type Status } from '../types';
import { IconBike, IconBowl, IconCheck, IconClock, IconPhone, IconPin, IconSms } from '../components/Icons';
import { clockTime, inr } from '../lib/format';
import { useTicker } from '../lib/hooks';

const STEPS: { status: Status; label: string; sub: string }[] = [
  { status: 'RECEIVED', label: 'Order Placed', sub: 'We have your order' },
  { status: 'IN_KITCHEN', label: 'In the Kitchen', sub: 'Chef is cooking' },
  { status: 'PACKED', label: 'Packed', sub: 'Sealed & ready' },
  { status: 'OUT_FOR_DELIVERY', label: 'On the Way', sub: 'Rider is riding' },
  { status: 'DELIVERED', label: 'Delivered', sub: 'Enjoy your meal' },
];

/** Progress 0..1 of the delivery leg, derived from dispatchedAt + etaMinutes. */
function useTransitProgress(order: { dispatchedAt: string | null; etaMinutes: number; status: Status } | null) {
  useTicker(1000);
  return useMemo(() => {
    if (!order || !order.dispatchedAt) return 0;
    if (order.status === 'DELIVERED') return 1;
    const elapsed = (Date.now() - new Date(order.dispatchedAt).getTime()) / 60_000;
    return Math.min(1, Math.max(0, elapsed / order.etaMinutes));
  }, [order, order?.dispatchedAt, order?.status, order?.etaMinutes]);
}

export default function CustomerTrack() {
  const { code } = useParams<{ code: string }>();
  const { data, loading, refresh } = useStore();
  const [smsSent, setSmsSent] = useState(false);

  const order = useMemo(() => {
    if (!data || !code) return null;
    return (
      data.orders.find(
        (o) => o.code.replace('#', '') === code || o.code === code || o.id === code,
      ) ?? null
    );
  }, [data, code]);

  const progress = useTransitProgress(order);
  useTicker(1000);

  const remaining = useMemo(() => {
    if (!order) return 0;
    if (order.status === 'DELIVERED') return 0;
    if (!order.dispatchedAt) return order.etaMinutes;
    const elapsed = (Date.now() - new Date(order.dispatchedAt).getTime()) / 60_000;
    return Math.max(0, Math.ceil(order.etaMinutes - elapsed));
  }, [order, order?.dispatchedAt, order?.status, order?.etaMinutes]);

  const stepIndex = order ? STATUS_FLOW.indexOf(order.status) : 0;

  useEffect(() => {
    if (!order) return;
    const id = setInterval(() => void refresh(), 5000);
    return () => clearInterval(id);
  }, [order, refresh]);

  if (loading && !data) {
    return (
      <div className="grid min-h-screen place-items-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-ember-500 border-t-transparent" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="grid min-h-screen place-items-center px-4">
        <div className="panel max-w-sm p-8 text-center">
          <IconBowl size={32} className="mx-auto text-slate-700" />
          <h1 className="mt-3 text-base font-bold text-white">Order not found</h1>
          <p className="mt-1 text-[11px] text-slate-500">
            We couldn't find order <span className="font-mono text-slate-400">{code}</span>. Check the link in your SMS.
          </p>
          <Link to="/" className="btn-primary mt-4">
            Back to dashboard
          </Link>
        </div>
      </div>
    );
  }

  const meta = STATUS_META[order.status];
  const isDelivered = order.status === 'DELIVERED';

  return (
    <div className="min-h-screen px-4 py-6">
      <div className="mx-auto max-w-md space-y-3">
        {/* brand header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div
              className="grid h-9 w-9 place-items-center rounded-xl text-[15px]"
              style={{ backgroundColor: `${order.brand.color}22`, border: `1px solid ${order.brand.color}44` }}
            >
              🍱
            </div>
            <div>
              <div className="text-[13px] font-extrabold text-white">{order.brand.name}</div>
              <div className="text-[9px] uppercase tracking-[0.14em] text-slate-500">via DabbaDash</div>
            </div>
          </div>
          <div className="text-right">
            <div className="font-mono text-[13px] font-bold text-white">{order.code}</div>
            <div className="text-[9px] text-slate-500">{clockTime(order.createdAt)}</div>
          </div>
        </div>

        {/* status hero */}
        <div className="panel overflow-hidden">
          <div
            className="px-4 py-4"
            style={{
              background: isDelivered
                ? 'linear-gradient(135deg, rgba(16,185,129,0.16), transparent)'
                : 'linear-gradient(135deg, rgba(245,158,11,0.14), transparent)',
            }}
          >
            <div className="flex items-center gap-2">
              <span className={`h-2 w-2 rounded-full ${meta.color} ${!isDelivered ? 'animate-pulse' : ''}`} />
              <span className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">
                {isDelivered ? 'Completed' : 'Live status'}
              </span>
            </div>
            <h1 className="mt-1.5 text-xl font-extrabold tracking-tight text-white">
              {isDelivered
                ? 'Delivered — enjoy your meal!'
                : order.status === 'OUT_FOR_DELIVERY'
                  ? `${order.courier?.name ?? 'Your rider'} is on the way!`
                  : order.status === 'PACKED'
                    ? 'Packed and waiting for a rider'
                    : order.status === 'IN_KITCHEN'
                      ? 'Your food is being prepared'
                      : 'Order received by the kitchen'}
            </h1>
            <p className="mt-1 text-[11px] text-slate-400">
              {isDelivered
                ? `Delivered at ${order.deliveredAt ? clockTime(order.deliveredAt) : '—'}`
                : order.status === 'OUT_FOR_DELIVERY'
                  ? `${order.courier?.name} is picking up your food and heading to ${order.zone.name}.`
                  : `Estimated ${order.etaMinutes} min from dispatch · ${order.zone.sector}, ${order.zone.name}`}
            </p>

            {!isDelivered && (
              <div className="mt-3 flex items-end gap-2">
                <div className="font-mono text-4xl font-extrabold leading-none text-ember-400">
                  {String(remaining).padStart(2, '0')}
                </div>
                <div className="pb-1">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">min</div>
                  <div className="text-[9px] text-slate-600">estimated</div>
                </div>
                <div className="ml-auto text-right">
                  <div className="text-[9px] uppercase tracking-wider text-slate-500">Total</div>
                  <div className="font-mono text-sm font-bold text-white">{inr(order.total)}</div>
                </div>
              </div>
            )}
          </div>

          {/* animated transit track */}
          {order.status === 'OUT_FOR_DELIVERY' && (
            <div className="border-t border-white/[0.06] px-4 py-3">
              <div className="relative h-9">
                <div className="absolute left-0 right-0 top-1/2 h-1 -translate-y-1/2 rounded-full bg-white/[0.08]" />
                <div
                  className="absolute left-0 top-1/2 h-1 -translate-y-1/2 rounded-full bg-gradient-to-r from-ember-500 to-emerald-400 transition-all duration-1000 ease-linear"
                  style={{ width: `${progress * 100}%` }}
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 transition-all duration-1000 ease-linear"
                  style={{ left: `calc(${progress * 100}% - 14px)` }}
                >
                  <div className="grid h-7 w-7 place-items-center rounded-full border-2 border-ink-950 bg-ember-500 text-[13px] shadow-[0_0_16px_rgba(245,158,11,0.7)]">
                    🛵
                  </div>
                </div>
                <div className="absolute right-0 top-1/2 -translate-y-1/2 text-[13px]">🏠</div>
              </div>
              <div className="mt-1 flex justify-between text-[9px] text-slate-500">
                <span>Commissary</span>
                <span className="font-mono text-ember-400">{Math.round(progress * 100)}% of route</span>
                <span>{order.zone.name}</span>
              </div>
            </div>
          )}

          {/* stepper */}
          <div className="border-t border-white/[0.06] px-4 py-3">
            <div className="space-y-0">
              {STEPS.map((step, i) => {
                const done = i < stepIndex;
                const active = i === stepIndex;
                return (
                  <div key={step.status} className="flex gap-2.5">
                    <div className="flex flex-col items-center">
                      <div
                        className={`grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 text-[9px] font-bold transition-all ${
                          done
                            ? 'border-emerald-500 bg-emerald-500 text-ink-950'
                            : active
                              ? 'border-ember-500 bg-ember-500/20 text-ember-400'
                              : 'border-white/15 bg-transparent text-slate-600'
                        }`}
                      >
                        {done ? <IconCheck size={10} /> : i + 1}
                      </div>
                      {i < STEPS.length - 1 && (
                        <div className={`h-6 w-0.5 ${done ? 'bg-emerald-500/60' : 'bg-white/10'}`} />
                      )}
                    </div>
                    <div className="pb-1">
                      <div
                        className={`text-[11px] font-semibold leading-tight ${
                          active ? 'text-white' : done ? 'text-slate-300' : 'text-slate-600'
                        }`}
                      >
                        {step.label}
                        {active && !isDelivered && (
                          <span className="ml-1.5 rounded bg-ember-500/20 px-1 py-0.5 text-[8px] font-bold uppercase tracking-wider text-ember-400">
                            now
                          </span>
                        )}
                      </div>
                      <div className="text-[9px] text-slate-600">{step.sub}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* rider card */}
        {order.courier && (
          <div className="panel flex items-center gap-3 p-3">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-emerald-500/15 text-[15px]">
              🛵
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[12px] font-bold text-white">{order.courier.name}</div>
              <div className="text-[10px] text-slate-500">
                {order.courier.vehicle} · ★{order.courier.rating.toFixed(1)} · {order.courier.tripsToday} trips today
              </div>
            </div>
            <a href={`tel:${order.courier.phone.replace(/\s/g, '')}`} className="btn-ghost !px-2 !py-1.5">
              <IconPhone size={13} />
            </a>
          </div>
        )}

        {/* order summary */}
        <div className="panel overflow-hidden">
          <div className="panel-head !py-2">
            <span className="text-[11px] font-bold text-white">Your order</span>
            <span className="font-mono text-[10px] text-slate-500">{order.items.length} items</span>
          </div>
          <div className="space-y-1 px-3.5 py-2.5">
            {order.items.map((it) => (
              <div key={it.id} className="flex items-baseline justify-between gap-2 text-[11px]">
                <span className="text-slate-300">
                  <span className="font-mono text-[10px] text-ember-400">{it.qty}×</span> {it.name}
                </span>
                <span className="font-mono text-slate-400">{inr(it.price * it.qty)}</span>
              </div>
            ))}
            <div className="mt-1.5 space-y-0.5 border-t border-white/[0.06] pt-1.5 text-[10px]">
              <div className="flex justify-between text-slate-500">
                <span>Subtotal</span>
                <span className="font-mono">{inr(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Delivery fee</span>
                <span className="font-mono">{inr(order.deliveryFee)}</span>
              </div>
              <div className="flex justify-between pt-1 text-[11px] font-bold text-white">
                <span>Total</span>
                <span className="font-mono text-ember-400">{inr(order.total)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* delivery address */}
        <div className="panel flex items-start gap-2.5 p-3">
          <IconPin size={14} className="mt-0.5 shrink-0 text-slate-500" />
          <div className="min-w-0">
            <div className="text-[11px] font-semibold text-white">{order.customerName}</div>
            <div className="text-[10px] leading-relaxed text-slate-500">{order.address}</div>
            <div className="mt-0.5 text-[9px] text-slate-600">
              {order.zone.sector} · {order.zone.name}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between px-1 text-[9px] text-slate-600">
          <span className="inline-flex items-center gap-1">
            <IconClock size={9} /> Auto-refreshing every 5s
          </span>
          <Link to="/" className="hover:text-slate-400">
            Kitchen dashboard →
          </Link>
        </div>
      </div>
    </div>
  );
}
