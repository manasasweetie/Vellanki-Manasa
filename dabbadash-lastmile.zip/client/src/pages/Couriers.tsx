import { useState } from 'react';
import { useStore } from '../store';
import { api } from '../api';
import { IconBike, IconCheck, IconPin, IconRupee, IconUsers } from '../components/Icons';
import { avatarColor, initials, inr2 } from '../lib/format';
import type { Courier } from '../types';

const STATUS_STYLE: Record<string, string> = {
  AVAILABLE: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300',
  ON_TRIP: 'border-amber-500/40 bg-amber-500/10 text-amber-300',
  OFFLINE: 'border-slate-600/40 bg-slate-600/10 text-slate-400',
};

function CourierCard({ courier }: { courier: Courier }) {
  const { refresh, data } = useStore();
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);

  const assigned = data?.orders.filter((o) => o.courierId === courier.id && o.status !== 'DELIVERED') ?? [];
  const payout = courier.payout;

  async function setStatus(status: string) {
    setBusy(true);
    try {
      await api.setCourierStatus(courier.id, status);
      await refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="panel overflow-hidden">
      <div className="flex items-start gap-3 p-3.5">
        <div
          className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-[13px] font-bold text-ink-950"
          style={{ backgroundColor: avatarColor(courier.name) }}
        >
          {initials(courier.name)}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h3 className="text-[14px] font-bold text-white">{courier.name}</h3>
            <span
              className={`chip border ${STATUS_STYLE[courier.status]}`}
            >
              {courier.status.replace('_', ' ')}
            </span>
          </div>
          <div className="mt-0.5 flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[10px] text-slate-500">
            <span className="inline-flex items-center gap-1">
              <IconBike size={10} /> {courier.vehicle}
            </span>
            <span>cap {courier.capacity}</span>
            <span className="text-amber-400">★ {courier.rating.toFixed(1)}</span>
            <span>{courier.tripsToday} trips today</span>
          </div>
          <div className="mt-1 font-mono text-[10px] text-slate-600">{courier.phone}</div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-px border-y border-white/[0.06] bg-white/[0.03]">
        <div className="bg-ink-900/60 px-2 py-2 text-center">
          <div className="label !text-[9px]">Active</div>
          <div className="font-mono text-sm font-bold text-white">{assigned.length}</div>
        </div>
        <div className="bg-ink-900/60 px-2 py-2 text-center">
          <div className="label !text-[9px]">Distance</div>
          <div className="font-mono text-sm font-bold text-white">{payout?.distanceKm.toFixed(1) ?? '0.0'}<span className="text-[9px] text-slate-500">km</span></div>
        </div>
        <div className="bg-ink-900/60 px-2 py-2 text-center">
          <div className="label !text-[9px]">Payout</div>
          <div className="font-mono text-sm font-bold text-ember-400">{inr2(payout?.total ?? 0)}</div>
        </div>
      </div>

      {assigned.length > 0 && (
        <div className="space-y-1 px-3 py-2">
          {assigned.map((o) => (
            <div key={o.id} className="flex items-center gap-1.5 text-[10px]">
              <span className="font-mono font-semibold text-slate-300">{o.code}</span>
              <span className="truncate text-slate-500">{o.customerName}</span>
              <span className="ml-auto shrink-0 rounded bg-white/[0.06] px-1 py-0.5 font-mono text-[9px] text-slate-400">
                {o.zone.sector}
              </span>
            </div>
          ))}
        </div>
      )}

      {open && payout && (
        <div className="border-t border-white/[0.06] bg-black/20 px-3 py-2.5">
          <div className="label mb-1.5 flex items-center gap-1">
            <IconRupee size={10} /> Payout breakdown
          </div>
          {payout.breakdown.map((b) => (
            <div key={b.label} className="flex items-center justify-between py-0.5 text-[10px]">
              <span className="text-slate-400">{b.label}</span>
              <span className="font-mono text-slate-200">{inr2(b.amount)}</span>
            </div>
          ))}
          <div className="mt-1.5 flex items-center justify-between border-t border-white/10 pt-1.5 text-[11px] font-bold">
            <span className="text-slate-300">Total</span>
            <span className="font-mono text-ember-400">{inr2(payout.total)}</span>
          </div>
        </div>
      )}

      <div className="flex items-center gap-1.5 border-t border-white/[0.06] px-3 py-2">
        <button onClick={() => setOpen((v) => !v)} className="btn-ghost flex-1 !py-1 !text-[10px]">
          {open ? 'Hide' : 'Payout'} breakdown
        </button>
        {courier.status !== 'AVAILABLE' && (
          <button onClick={() => void setStatus('AVAILABLE')} disabled={busy} className="btn-ghost !py-1 !text-[10px]">
            <IconCheck size={10} /> Available
          </button>
        )}
        {courier.status !== 'OFFLINE' && (
          <button onClick={() => void setStatus('OFFLINE')} disabled={busy} className="btn-ghost !py-1 !text-[10px]">
            Offline
          </button>
        )}
      </div>
    </div>
  );
}

export default function Couriers() {
  const { couriers, loading } = useStore();

  const available = couriers.filter((c) => c.status === 'AVAILABLE');
  const onTrip = couriers.filter((c) => c.status === 'ON_TRIP');
  const offline = couriers.filter((c) => c.status === 'OFFLINE');

  const totalPayout = couriers.reduce((s, c) => s + (c.payout?.total ?? 0), 0);

  if (loading && couriers.length === 0) {
    return <div className="panel h-64 animate-pulse bg-white/[0.02]" />;
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-lg font-extrabold tracking-tight text-white">Rider Dispatch Console</h1>
          <p className="text-[11px] text-slate-500">
            Live courier roster, active loads and distance-based payout for the current shift.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="panel flex items-center gap-2 px-3 py-1.5">
            <IconUsers size={13} className="text-emerald-400" />
            <span className="font-mono text-sm font-bold text-white">{available.length}</span>
            <span className="text-[10px] text-slate-500">available</span>
          </div>
          <div className="panel flex items-center gap-2 px-3 py-1.5">
            <IconBike size={13} className="text-amber-400" />
            <span className="font-mono text-sm font-bold text-white">{onTrip.length}</span>
            <span className="text-[10px] text-slate-500">on trip</span>
          </div>
          <div className="panel flex items-center gap-2 px-3 py-1.5">
            <IconRupee size={13} className="text-ember-400" />
            <span className="font-mono text-sm font-bold text-ember-400">{inr2(totalPayout)}</span>
            <span className="text-[10px] text-slate-500">shift payout</span>
          </div>
        </div>
      </div>

      {[
        { title: 'Available', list: available, hint: 'Ready to be assigned' },
        { title: 'On Trip', list: onTrip, hint: 'Currently delivering' },
        { title: 'Offline', list: offline, hint: 'Not on shift' },
      ].map((group) =>
        group.list.length === 0 ? null : (
          <section key={group.title}>
            <div className="mb-1.5 flex items-center gap-2">
              <h2 className="text-[11px] font-bold uppercase tracking-[0.12em] text-slate-400">{group.title}</h2>
              <span className="rounded bg-white/[0.07] px-1.5 py-0.5 font-mono text-[9px] font-bold text-slate-400">
                {group.list.length}
              </span>
              <span className="text-[10px] text-slate-600">{group.hint}</span>
            </div>
            <div className="grid grid-cols-1 gap-2.5 md:grid-cols-2 xl:grid-cols-3">
              {group.list.map((c) => (
                <CourierCard key={c.id} courier={c} />
              ))}
            </div>
          </section>
        ),
      )}
    </div>
  );
}
