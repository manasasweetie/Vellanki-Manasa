import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { api, subscribe } from './api';
import type { Bootstrap, Cluster, Courier, EventRow, Kpis, Order, SmsRow } from './types';

type Store = {
  data: Bootstrap | null;
  kpis: Kpis | null;
  batches: Cluster[];
  couriers: Courier[];
  events: EventRow[];
  sms: SmsRow[];
  loading: boolean;
  error: string | null;
  live: boolean;
  lastSync: Date | null;
  refresh: () => Promise<void>;
  reset: () => Promise<void>;
};

const Ctx = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<Bootstrap | null>(null);
  const [kpis, setKpis] = useState<Kpis | null>(null);
  const [batches, setBatches] = useState<Cluster[]>([]);
  const [couriers, setCouriers] = useState<Courier[]>([]);
  const [events, setEvents] = useState<EventRow[]>([]);
  const [sms, setSms] = useState<SmsRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [live, setLive] = useState(false);
  const [lastSync, setLastSync] = useState<Date | null>(null);

  const inFlight = useRef(false);
  const queued = useRef(false);

  const refresh = useCallback(async () => {
    if (inFlight.current) {
      queued.current = true;
      return;
    }
    inFlight.current = true;
    try {
      const [b, k, bt, c, e, s] = await Promise.all([
        api.bootstrap(),
        api.kpis(),
        api.batches(),
        api.couriers(),
        api.events(),
        api.sms(),
      ]);
      setData(b);
      setKpis(k);
      setBatches(bt);
      setCouriers(c);
      setEvents(e);
      setSms(s);
      setError(null);
      setLastSync(new Date());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reach the DabbaDash API');
    } finally {
      setLoading(false);
      inFlight.current = false;
      if (queued.current) {
        queued.current = false;
        void refresh();
      }
    }
  }, []);

  useEffect(() => {
    void refresh();
    const unsub = subscribe(() => void refresh());
    setLive(true);
    // Safety net: poll every 15s in case SSE is blocked by a proxy.
    const poll = setInterval(() => void refresh(), 15_000);
    return () => {
      unsub();
      clearInterval(poll);
      setLive(false);
    };
  }, [refresh]);

  const reset = useCallback(async () => {
    await api.reset();
    await refresh();
  }, [refresh]);

  const value = useMemo<Store>(
    () => ({ data, kpis, batches, couriers, events, sms, loading, error, live, lastSync, refresh, reset }),
    [data, kpis, batches, couriers, events, sms, loading, error, live, lastSync, refresh, reset],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore(): Store {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useStore must be used inside <StoreProvider>');
  return ctx;
}

export function useOrder(id: string | undefined): Order | null {
  const { data } = useStore();
  if (!id || !data) return null;
  return data.orders.find((o) => o.id === id || o.code === id || o.code.replace('#', '') === id) ?? null;
}
