import { NavLink, Route, Routes, useLocation } from 'react-router-dom';
import { StoreProvider, useStore } from './store';
import { LiveDot } from './components/Badges';
import { IconBike, IconBowl, IconChart, IconGrid, IconLayers, IconMap, IconPhone, IconRefresh } from './components/Icons';
import DispatchBoard from './pages/DispatchBoard';
import Couriers from './pages/Couriers';
import Batching from './pages/Batching';
import LiveMap from './pages/LiveMap';
import CustomerTrack from './pages/CustomerTrack';
import Analytics from './pages/Analytics';

const NAV = [
  { to: '/', label: 'Dispatch Board', icon: IconGrid, end: true },
  { to: '/couriers', label: 'Couriers', icon: IconBike },
  { to: '/batching', label: 'Zone Batching', icon: IconLayers },
  { to: '/map', label: 'Live Map', icon: IconMap },
  { to: '/analytics', label: 'Analytics', icon: IconChart },
];

function Shell() {
  const { live, lastSync, refresh, loading, error } = useStore();
  const location = useLocation();
  const isCustomer = location.pathname.startsWith('/track');

  if (isCustomer) {
    return (
      <Routes>
        <Route path="/track/:code" element={<CustomerTrack />} />
      </Routes>
    );
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-white/[0.07] bg-ink-950/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1800px] items-center gap-4 px-4 py-2.5">
          <div className="flex items-center gap-2.5">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-ember-400 to-ember-600 text-ink-950 shadow-[0_4px_16px_-4px_rgba(245,158,11,0.6)]">
              <IconBowl size={19} />
            </div>
            <div className="leading-tight">
              <div className="text-[15px] font-extrabold tracking-tight text-white">
                Dabba<span className="text-ember-400">Dash</span>
              </div>
              <div className="text-[9px] font-semibold uppercase tracking-[0.16em] text-slate-500">
                LastMile Dispatch
              </div>
            </div>
          </div>

          <nav className="ml-2 hidden items-center gap-0.5 lg:flex">
            {NAV.map(({ to, label, icon: Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  `flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-semibold transition-colors ${
                    isActive
                      ? 'bg-white/[0.08] text-white'
                      : 'text-slate-400 hover:bg-white/[0.04] hover:text-slate-200'
                  }`
                }
              >
                <Icon size={14} />
                {label}
              </NavLink>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-3">
            <LiveDot live={live} />
            <span className="hidden font-mono text-[10px] text-slate-600 sm:block">
              {lastSync ? lastSync.toLocaleTimeString('en-IN', { hour12: false }) : '—'}
            </span>
            <button onClick={() => void refresh()} className="btn-ghost !px-2 !py-1.5" title="Refresh now">
              <IconRefresh size={13} className={loading ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>

        {/* Mobile nav */}
        <nav className="flex items-center gap-1 overflow-x-auto border-t border-white/[0.05] px-3 py-1.5 lg:hidden scroll-thin">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px] font-semibold ${
                  isActive ? 'bg-white/[0.08] text-white' : 'text-slate-400'
                }`
              }
            >
              <Icon size={13} />
              {label}
            </NavLink>
          ))}
        </nav>
      </header>

      {error && (
        <div className="mx-auto mt-3 max-w-[1800px] px-4">
          <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-2.5 text-xs text-red-300">
            <strong>API unreachable:</strong> {error} — make sure the server is running on port 4000.
          </div>
        </div>
      )}

      <main className="mx-auto max-w-[1800px] px-4 py-4">
        <Routes>
          <Route path="/" element={<DispatchBoard />} />
          <Route path="/couriers" element={<Couriers />} />
          <Route path="/batching" element={<Batching />} />
          <Route path="/map" element={<LiveMap />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/track/:code" element={<CustomerTrack />} />
          <Route
            path="*"
            element={
              <div className="grid place-items-center py-24 text-center">
                <div>
                  <div className="font-mono text-5xl font-bold text-slate-700">404</div>
                  <p className="mt-2 text-sm text-slate-500">That page isn't on the dispatch board.</p>
                  <NavLink to="/" className="btn-primary mt-4">
                    Back to Dispatch Board
                  </NavLink>
                </div>
              </div>
            }
          />
        </Routes>
      </main>

      <footer className="mx-auto max-w-[1800px] px-4 pb-6 pt-2">
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.05] pt-3 text-[10px] text-slate-600">
          <span>
            DabbaDash · LastMile Bite Battle · hyperlocal dispatch for cloud kitchens
          </span>
          <span className="inline-flex items-center gap-1.5">
            <IconPhone size={11} />
            Customer tracking: <code className="font-mono text-slate-500">/track/104</code>
          </span>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
