import { STATUS_META, type Status } from '../types';

export function StatusChip({ status, size = 'sm' }: { status: Status; size?: 'sm' | 'xs' }) {
  const m = STATUS_META[status];
  return (
    <span
      className={`chip ${m.text} ${size === 'xs' ? 'text-[9px]' : ''}`}
      style={{ backgroundColor: 'rgba(255,255,255,0.05)' }}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${m.color}`} />
      {m.short}
    </span>
  );
}

export function BrandTag({ name, color, accent }: { name: string; color: string; accent: string }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-md px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider"
      style={{ backgroundColor: `${color}1f`, color: accent, border: `1px solid ${color}33` }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: color }} />
      {name}
    </span>
  );
}

export function BottleneckBadge({ minutes }: { minutes: number }) {
  return (
    <span className="chip animate-pulseRed rounded-md border border-red-500/60 bg-red-500/15 text-red-300">
      ⚠ {minutes}m in kitchen
    </span>
  );
}

export function LiveDot({ live }: { live: boolean }) {
  return (
    <span className="inline-flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider">
      <span className="relative flex h-2 w-2">
        {live && <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-70" />}
        <span className={`relative inline-flex h-2 w-2 rounded-full ${live ? 'bg-emerald-400' : 'bg-slate-500'}`} />
      </span>
      <span className={live ? 'text-emerald-400' : 'text-slate-500'}>{live ? 'Live' : 'Offline'}</span>
    </span>
  );
}
