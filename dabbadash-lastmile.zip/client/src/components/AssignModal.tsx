import { useEffect, useState } from 'react';
import { api } from '../api';
import { useStore } from '../store';
import type { CourierPick, Order } from '../types';
import { BrandTag } from './Badges';
import { IconBowl, IconCheck, IconPin, IconSpark, IconX } from './Icons';
import { avatarColor, initials, inr } from '../lib/format';

export default function AssignModal({ order, onClose }: { order: Order; onClose: () => void }) {
  const { couriers, refresh } = useStore();
  const [pick, setPick] = useState<CourierPick | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/recommend/${order.id}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((p: CourierPick | null) => {
        if (cancelled) return;
        setPick(p);
        setSelected(p?.courier.id ?? null);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [order.id]);

  async function confirm() {
    if (!selected) return;
    setBusy(true);
    setError(null);
    try {
      await api.assign(order.id, selected);
      await refresh();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Assignment failed');
    } finally {
      setBusy(false);
    }
  }

  const available = couriers.filter((c) => c.status === 'AVAILABLE');
  const others = couriers.filter((c) => c.status !== 'AVAILABLE');

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-lg animate-slideIn overflow-hidden rounded-2xl border border-white/10 bg-ink-900 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-white/[0.07] px-4 py-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-sm font-bold text-white">{order.code}</span>
              <BrandTag name={order.brand.name} color={order.brand.color} accent={order.brand.accent} />
            </div>
            <div className="mt-1 flex items-center gap-1.5 text-[11px] text-slate-400">
              <IconPin size={11} />
              {order.zone.sector} — {order.zone.name}
              <span className="text-slate-600">·</span>
              <span className="font-mono">{inr(order.total)}</span>
            </div>
          </div>
          <button onClick={onClose} className="btn-ghost !px-1.5 !py-1">
            <IconX size={14} />
          </button>
        </div>

        <div className="max-h-[60vh] overflow-y-auto p-4 scroll-thin">
          {pick && (
            <div className="mb-3 rounded-xl border border-ember-500/30 bg-ember-500/[0.07] p-3">
              <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-ember-400">
                <IconSpark size={12} /> Recommended courier
              </div>
              <div className="mt-2 flex items-center gap-2.5">
                <div
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[11px] font-bold text-ink-950"
                  style={{ backgroundColor: avatarColor(pick.courier.name) }}
                >
                  {initials(pick.courier.name)}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-[13px] font-bold text-white">
                    {pick.courier.name}
                    <span className="ml-1.5 font-mono text-[10px] font-medium text-slate-400">
                      {pick.courier.vehicle}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400">{pick.reason}</div>
                </div>
                <div className="shrink-0 text-right">
                  <div className="font-mono text-lg font-bold leading-none text-ember-400">{pick.score}</div>
                  <div className="text-[9px] uppercase tracking-wider text-slate-500">score</div>
                </div>
              </div>
              <div className="mt-2.5 space-y-1 border-t border-ember-500/20 pt-2">
                {pick.breakdown.map((b) => (
                  <div key={b.label} className="flex items-center justify-between text-[10px]">
                    <span className="text-slate-400">{b.label}</span>
                    <span className={`font-mono font-semibold ${b.points >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {b.points >= 0 ? '+' : ''}
                      {b.points}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="label mb-1.5">Available couriers ({available.length})</div>
          <div className="space-y-1.5">
            {available.map((c) => {
              const isSel = selected === c.id;
              const isRec = pick?.courier.id === c.id;
              return (
                <button
                  key={c.id}
                  onClick={() => setSelected(c.id)}
                  className={`flex w-full items-center gap-2.5 rounded-lg border px-2.5 py-2 text-left transition-all ${
                    isSel
                      ? 'border-ember-500/60 bg-ember-500/10'
                      : 'border-white/[0.07] bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.05]'
                  }`}
                >
                  <div
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-[10px] font-bold text-ink-950"
                    style={{ backgroundColor: avatarColor(c.name) }}
                  >
                    {initials(c.name)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 text-[12px] font-semibold text-white">
                      {c.name}
                      {isRec && (
                        <span className="rounded bg-ember-500/20 px-1 py-0.5 text-[8px] font-bold uppercase tracking-wider text-ember-400">
                          Best
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-500">
                      {c.vehicle} · cap {c.capacity} · ★{c.rating.toFixed(1)} · {c.tripsToday} trips
                    </div>
                  </div>
                  {isSel && <IconCheck size={15} className="shrink-0 text-ember-400" />}
                </button>
              );
            })}
            {available.length === 0 && (
              <div className="rounded-lg border border-white/[0.07] bg-white/[0.02] px-3 py-4 text-center text-[11px] text-slate-500">
                No couriers are available right now.
              </div>
            )}
          </div>

          {others.length > 0 && (
            <>
              <div className="label mb-1.5 mt-3">Unavailable ({others.length})</div>
              <div className="space-y-1">
                {others.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center gap-2 rounded-lg border border-white/[0.04] bg-white/[0.01] px-2.5 py-1.5 opacity-50"
                  >
                    <div className="grid h-6 w-6 place-items-center rounded-full bg-white/10 text-[9px] font-bold text-slate-400">
                      {initials(c.name)}
                    </div>
                    <span className="text-[11px] text-slate-400">{c.name}</span>
                    <span className="ml-auto text-[9px] uppercase tracking-wider text-slate-600">
                      {c.status.replace('_', ' ')}
                    </span>
                  </div>
                ))}
              </div>
            </>
          )}

          {error && (
            <div className="mt-3 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-[11px] text-red-300">
              {error}
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 border-t border-white/[0.07] px-4 py-3">
          <button onClick={onClose} className="btn-ghost flex-1">
            Cancel
          </button>
          <button onClick={() => void confirm()} disabled={!selected || busy} className="btn-primary flex-1">
            {busy ? 'Dispatching…' : (
              <>
                <IconBowl size={13} /> Dispatch order
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
