import { useStore } from '../store';
import { IconAlert, IconBike, IconBox, IconClock, IconRupee, IconUsers } from './Icons';

function Kpi({
  label,
  value,
  sub,
  icon,
  tone = 'default',
  pulse = false,
}: {
  label: string;
  value: string | number;
  sub?: string;
  icon: React.ReactNode;
  tone?: 'default' | 'warn' | 'good' | 'ember';
  pulse?: boolean;
}) {
  const tones = {
    default: 'text-slate-200',
    warn: 'text-red-400',
    good: 'text-emerald-400',
    ember: 'text-ember-400',
  } as const;
  const rings = {
    default: 'bg-white/[0.04] text-slate-400',
    warn: 'bg-red-500/10 text-red-400',
    good: 'bg-emerald-500/10 text-emerald-400',
    ember: 'bg-ember-500/10 text-ember-400',
  } as const;

  return (
    <div
      className={`panel flex items-center gap-3 px-3.5 py-3 ${
        pulse ? 'border-red-500/40 animate-pulseRed' : ''
      }`}
    >
      <div className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${rings[tone]}`}>{icon}</div>
      <div className="min-w-0">
        <div className="label truncate">{label}</div>
        <div className={`mt-0.5 flex items-baseline gap-1.5 font-mono text-xl font-bold leading-none ${tones[tone]}`}>
          {value}
          {sub && <span className="text-[10px] font-medium text-slate-500">{sub}</span>}
        </div>
      </div>
    </div>
  );
}

export function KpiBar() {
  const { kpis } = useStore();
  if (!kpis) {
    return (
      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-3 xl:grid-cols-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="panel h-[68px] animate-pulse bg-white/[0.02]" />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-2.5 md:grid-cols-3 xl:grid-cols-6">
      <Kpi label="Active Orders" value={kpis.activeOrders} sub="live" icon={<IconBox size={17} />} tone="ember" />
      <Kpi label="In Kitchen" value={kpis.inKitchen} sub="cooking" icon={<IconClock size={17} />} />
      <Kpi label="Avg Prep Time" value={kpis.avgPrepMinutes} sub="min" icon={<IconClock size={17} />} tone="good" />
      <Kpi label="Pending Dispatch" value={kpis.pendingDispatch} sub="packed" icon={<IconBike size={17} />} />
      <Kpi
        label="Bottlenecks"
        value={kpis.bottlenecks}
        sub=">20m"
        icon={<IconAlert size={17} />}
        tone={kpis.bottlenecks > 0 ? 'warn' : 'default'}
        pulse={kpis.bottlenecks > 0}
      />
      <Kpi label="Revenue Today" value={`₹${Math.round(kpis.revenueToday).toLocaleString('en-IN')}`} icon={<IconRupee size={17} />} />
    </div>
  );
}

export function BrandStrip() {
  const { kpis } = useStore();
  if (!kpis) return null;
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="label mr-1">Brands</span>
      {kpis.byBrand.map((b) => (
        <span
          key={b.id}
          className="inline-flex items-center gap-1.5 rounded-lg border px-2 py-1 text-[11px] font-semibold"
          style={{ borderColor: `${b.color}33`, backgroundColor: `${b.color}12`, color: b.color }}
        >
          <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: b.color }} />
          {b.name}
          <span className="font-mono text-[10px] opacity-70">{b.orders}</span>
        </span>
      ))}
      <span className="ml-auto inline-flex items-center gap-1.5 text-[11px] text-slate-500">
        <IconUsers size={13} />
        {kpis.couriersAvailable} couriers available
      </span>
    </div>
  );
}
