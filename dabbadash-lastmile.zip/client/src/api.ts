import type { Bootstrap, Cluster, Courier, CourierPick, EventRow, Kpis, Order, Payout, SmsRow } from './types';

const BASE = '/api';

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...init,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error((body as { error?: string }).error ?? `Request failed: ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export const api = {
  bootstrap: () => req<Bootstrap>('/bootstrap'),
  kpis: () => req<Kpis>('/kpis'),
  orders: () => req<Order[]>('/orders'),
  order: (id: string) => req<Order>(`/orders/${id}`),
  batches: () => req<Cluster[]>('/batches'),
  couriers: () => req<Courier[]>('/couriers'),
  events: () => req<EventRow[]>('/events?limit=50'),
  sms: () => req<SmsRow[]>('/sms'),

  advance: (id: string) =>
    req<{ order: Order; recommendation: CourierPick | null }>(`/orders/${id}/advance`, { method: 'POST' }),
  assign: (id: string, courierId: string) =>
    req<{ order: Order }>(`/orders/${id}/assign`, { method: 'POST', body: JSON.stringify({ courierId }) }),
  unassign: (id: string) => req<{ order: Order }>(`/orders/${id}/unassign`, { method: 'POST' }),
  dispatchBatch: (zoneId: string, courierId: string, orderIds: string[]) =>
    req<{ batchId: string; dispatched: number; courier: string }>(`/batches/${zoneId}/dispatch`, {
      method: 'POST',
      body: JSON.stringify({ courierId, orderIds }),
    }),
  sendSms: (id: string) =>
    req<{ sent: boolean; to: string; message: string; link: string }>(`/orders/${id}/sms`, { method: 'POST' }),
  setCourierStatus: (id: string, status: string) =>
    req<{ ok: boolean }>(`/couriers/${id}/status`, { method: 'POST', body: JSON.stringify({ status }) }),
  payout: (id: string) => req<Payout>(`/couriers/${id}/payout`),
  reset: () => req<{ ok: boolean }>('/reset', { method: 'POST' }),
};

/** Subscribe to the server's SSE stream. Returns an unsubscribe function. */
export function subscribe(onChange: () => void): () => void {
  const es = new EventSource(`${BASE}/stream`);
  es.addEventListener('change', () => onChange());
  es.onerror = () => {
    /* EventSource auto-reconnects */
  };
  return () => es.close();
}
