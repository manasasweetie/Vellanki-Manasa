export type Status = 'RECEIVED' | 'IN_KITCHEN' | 'PACKED' | 'OUT_FOR_DELIVERY' | 'DELIVERED';

export const STATUS_FLOW: Status[] = ['RECEIVED', 'IN_KITCHEN', 'PACKED', 'OUT_FOR_DELIVERY', 'DELIVERED'];

export const STATUS_META: Record<Status, { label: string; short: string; color: string; ring: string; text: string }> = {
  RECEIVED: { label: 'Received', short: 'Received', color: 'bg-sky-500', ring: 'ring-sky-500/30', text: 'text-sky-300' },
  IN_KITCHEN: { label: 'In Kitchen', short: 'Cooking', color: 'bg-amber-500', ring: 'ring-amber-500/30', text: 'text-amber-300' },
  PACKED: { label: 'Packed', short: 'Packed', color: 'bg-violet-500', ring: 'ring-violet-500/30', text: 'text-violet-300' },
  OUT_FOR_DELIVERY: { label: 'Out for Delivery', short: 'Dispatched', color: 'bg-emerald-500', ring: 'ring-emerald-500/30', text: 'text-emerald-300' },
  DELIVERED: { label: 'Delivered', short: 'Delivered', color: 'bg-slate-500', ring: 'ring-slate-500/30', text: 'text-slate-400' },
};

export type Brand = {
  id: string;
  name: string;
  slug: string;
  cuisine: string;
  color: string;
  accent: string;
  prepBaseMinutes: number;
};

export type MenuItem = {
  id: string;
  brandId: string;
  name: string;
  category: string;
  price: number;
  prepMinutes: number;
};

export type Zone = {
  id: string;
  name: string;
  sector: string;
  lat: number;
  lng: number;
  radiusKm: number;
  surgeMultiplier: number;
};

export type Courier = {
  id: string;
  name: string;
  phone: string;
  vehicle: string;
  capacity: number;
  zoneId: string | null;
  status: 'AVAILABLE' | 'ON_TRIP' | 'OFFLINE';
  lat: number | null;
  lng: number | null;
  rating: number;
  tripsToday: number;
  activeOrders?: number;
  payout?: Payout;
};

export type OrderItem = {
  id: number;
  orderId: string;
  menuItemId: string | null;
  name: string;
  qty: number;
  price: number;
};

export type Order = {
  id: string;
  code: string;
  brandId: string;
  customerName: string;
  customerPhone: string;
  address: string;
  zoneId: string;
  status: Status;
  createdAt: string;
  inKitchenAt: string | null;
  packedAt: string | null;
  dispatchedAt: string | null;
  deliveredAt: string | null;
  courierId: string | null;
  subtotal: number;
  deliveryFee: number;
  total: number;
  notes: string | null;
  etaMinutes: number;
  batchId: string | null;
  items: OrderItem[];
  brand: Brand;
  zone: Zone;
  courier: Courier | null;
  minutesInStage: number;
  bottleneck: boolean;
};

export type Kpis = {
  activeOrders: number;
  inKitchen: number;
  pendingDispatch: number;
  outForDelivery: number;
  delivered: number;
  avgPrepMinutes: number;
  bottlenecks: number;
  revenueToday: number;
  couriersAvailable: number;
  byBrand: { id: string; name: string; color: string; orders: number; revenue: number }[];
};

export type Cluster = {
  id: string;
  zoneId: string;
  zoneName: string;
  sector: string;
  anchor: { lat: number; lng: number };
  radiusKm: number;
  orders: Order[];
  totalValue: number;
  maxSpreadKm: number;
  suggestedCourierId: string | null;
  suggestedCourierName: string | null;
  surgeMultiplier: number;
};

export type CourierPick = {
  courier: Courier;
  score: number;
  distanceKm: number;
  reason: string;
  breakdown: { label: string; points: number }[];
};

export type Payout = {
  courierId: string;
  courierName: string;
  orders: number;
  distanceKm: number;
  basePay: number;
  distancePay: number;
  surgePay: number;
  batchBonus: number;
  total: number;
  breakdown: { label: string; amount: number }[];
};

export type EventRow = {
  id: number;
  orderId: string | null;
  type: string;
  message: string;
  createdAt: string;
};

export type SmsRow = {
  id: number;
  orderId: string;
  phone: string;
  message: string;
  link: string;
  createdAt: string;
};

export type Bootstrap = {
  brands: Brand[];
  menu: MenuItem[];
  zones: Zone[];
  couriers: Courier[];
  orders: Order[];
  bottleneckMinutes: number;
};
