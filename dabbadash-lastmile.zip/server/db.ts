import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

export const DB_PATH = path.join(DATA_DIR, 'dabbadash.db');

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initSchema(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS brands (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      cuisine TEXT NOT NULL,
      color TEXT NOT NULL,
      accent TEXT NOT NULL,
      prepBaseMinutes INTEGER NOT NULL DEFAULT 12
    );

    CREATE TABLE IF NOT EXISTS menu_items (
      id TEXT PRIMARY KEY,
      brandId TEXT NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      price REAL NOT NULL,
      prepMinutes INTEGER NOT NULL DEFAULT 8
    );

    CREATE TABLE IF NOT EXISTS zones (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      sector TEXT NOT NULL,
      lat REAL NOT NULL,
      lng REAL NOT NULL,
      radiusKm REAL NOT NULL DEFAULT 2.5,
      surgeMultiplier REAL NOT NULL DEFAULT 1.0
    );

    CREATE TABLE IF NOT EXISTS couriers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      vehicle TEXT NOT NULL,
      capacity INTEGER NOT NULL DEFAULT 2,
      zoneId TEXT REFERENCES zones(id),
      status TEXT NOT NULL DEFAULT 'AVAILABLE',
      lat REAL,
      lng REAL,
      rating REAL NOT NULL DEFAULT 4.6,
      tripsToday INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE,
      brandId TEXT NOT NULL REFERENCES brands(id),
      customerName TEXT NOT NULL,
      customerPhone TEXT NOT NULL,
      address TEXT NOT NULL,
      zoneId TEXT NOT NULL REFERENCES zones(id),
      status TEXT NOT NULL DEFAULT 'RECEIVED',
      createdAt TEXT NOT NULL,
      inKitchenAt TEXT,
      packedAt TEXT,
      dispatchedAt TEXT,
      deliveredAt TEXT,
      courierId TEXT REFERENCES couriers(id),
      subtotal REAL NOT NULL DEFAULT 0,
      deliveryFee REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      notes TEXT,
      etaMinutes INTEGER NOT NULL DEFAULT 30,
      batchId TEXT
    );

    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orderId TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      menuItemId TEXT,
      name TEXT NOT NULL,
      qty INTEGER NOT NULL DEFAULT 1,
      price REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orderId TEXT,
      type TEXT NOT NULL,
      message TEXT NOT NULL,
      createdAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sms_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orderId TEXT NOT NULL,
      phone TEXT NOT NULL,
      message TEXT NOT NULL,
      link TEXT NOT NULL,
      createdAt TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
    CREATE INDEX IF NOT EXISTS idx_orders_zone ON orders(zoneId);
    CREATE INDEX IF NOT EXISTS idx_items_order ON order_items(orderId);
    CREATE INDEX IF NOT EXISTS idx_events_order ON events(orderId);
  `);
}

export function logEvent(orderId: string | null, type: string, message: string): void {
  db.prepare('INSERT INTO events (orderId, type, message, createdAt) VALUES (?, ?, ?, ?)').run(
    orderId,
    type,
    message,
    new Date().toISOString(),
  );
}
