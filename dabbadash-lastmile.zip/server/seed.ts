import { db, initSchema, logEvent } from './db.js';

const KITCHEN = { lat: 12.9716, lng: 77.6412, name: 'DabbaDash Commissary — Indiranagar' };

const minutesAgo = (m: number) => new Date(Date.now() - m * 60_000).toISOString();

const BRANDS = [
  { id: 'br-biryani', name: 'Biryani Box', slug: 'biryani-box', cuisine: 'Hyderabadi Dum Biryani', color: '#f59e0b', accent: '#fbbf24', prepBaseMinutes: 18 },
  { id: 'br-burger', name: 'Burger Den', slug: 'burger-den', cuisine: 'Smash Burgers & Fries', color: '#ef4444', accent: '#f87171', prepBaseMinutes: 11 },
  { id: 'br-chai', name: 'Chai Point', slug: 'chai-point', cuisine: 'Chai, Coffee & Snacks', color: '#10b981', accent: '#34d399', prepBaseMinutes: 6 },
];

const MENU = [
  // Biryani Box (7)
  { id: 'mi-bb-1', brandId: 'br-biryani', name: 'Hyderabadi Chicken Biryani', category: 'Biryani', price: 249, prepMinutes: 18 },
  { id: 'mi-bb-2', brandId: 'br-biryani', name: 'Mutton Dum Biryani', category: 'Biryani', price: 329, prepMinutes: 22 },
  { id: 'mi-bb-3', brandId: 'br-biryani', name: 'Veg Dum Biryani', category: 'Biryani', price: 199, prepMinutes: 16 },
  { id: 'mi-bb-4', brandId: 'br-biryani', name: 'Egg Biryani', category: 'Biryani', price: 219, prepMinutes: 15 },
  { id: 'mi-bb-5', brandId: 'br-biryani', name: 'Chicken 65', category: 'Starters', price: 189, prepMinutes: 12 },
  { id: 'mi-bb-6', brandId: 'br-biryani', name: 'Mirchi Ka Salan', category: 'Sides', price: 49, prepMinutes: 5 },
  { id: 'mi-bb-7', brandId: 'br-biryani', name: 'Double Ka Meetha', category: 'Dessert', price: 99, prepMinutes: 4 },
  // Burger Den (7)
  { id: 'mi-bd-1', brandId: 'br-burger', name: 'Classic Cheeseburger', category: 'Burgers', price: 179, prepMinutes: 9 },
  { id: 'mi-bd-2', brandId: 'br-burger', name: 'Crispy Chicken Burger', category: 'Burgers', price: 199, prepMinutes: 10 },
  { id: 'mi-bd-3', brandId: 'br-burger', name: 'Veg Aloo Tikki Burger', category: 'Burgers', price: 129, prepMinutes: 8 },
  { id: 'mi-bd-4', brandId: 'br-burger', name: 'Peri Peri Fries', category: 'Sides', price: 119, prepMinutes: 6 },
  { id: 'mi-bd-5', brandId: 'br-burger', name: 'Loaded Nachos', category: 'Sides', price: 169, prepMinutes: 7 },
  { id: 'mi-bd-6', brandId: 'br-burger', name: 'Chocolate Thick Shake', category: 'Beverages', price: 149, prepMinutes: 4 },
  { id: 'mi-bd-7', brandId: 'br-burger', name: 'Onion Rings', category: 'Sides', price: 99, prepMinutes: 5 },
  // Chai Point (6)
  { id: 'mi-cp-1', brandId: 'br-chai', name: 'Masala Chai', category: 'Chai', price: 39, prepMinutes: 3 },
  { id: 'mi-cp-2', brandId: 'br-chai', name: 'Filter Coffee', category: 'Coffee', price: 49, prepMinutes: 4 },
  { id: 'mi-cp-3', brandId: 'br-chai', name: 'Ginger Lemon Tea', category: 'Chai', price: 45, prepMinutes: 3 },
  { id: 'mi-cp-4', brandId: 'br-chai', name: 'Bun Maska', category: 'Snacks', price: 59, prepMinutes: 2 },
  { id: 'mi-cp-5', brandId: 'br-chai', name: 'Punjabi Samosa', category: 'Snacks', price: 35, prepMinutes: 2 },
  { id: 'mi-cp-6', brandId: 'br-chai', name: 'Vada Pav', category: 'Snacks', price: 45, prepMinutes: 3 },
];

const ZONES = [
  { id: 'zn-a', name: 'Indiranagar', sector: 'Sector A', lat: 12.9784, lng: 77.6408, radiusKm: 2.5, surgeMultiplier: 1.0 },
  { id: 'zn-b', name: 'Koramangala', sector: 'Sector B', lat: 12.9352, lng: 77.6245, radiusKm: 2.5, surgeMultiplier: 1.15 },
  { id: 'zn-c', name: 'HSR Layout', sector: 'Sector C', lat: 12.9121, lng: 77.6446, radiusKm: 2.5, surgeMultiplier: 1.25 },
  { id: 'zn-d', name: 'Jayanagar', sector: 'Sector D', lat: 12.925, lng: 77.5938, radiusKm: 2.5, surgeMultiplier: 1.1 },
];

const COURIERS = [
  { id: 'cr-1', name: 'Ramesh', phone: '+91 98450 11021', vehicle: 'Bike', capacity: 3, zoneId: 'zn-b', status: 'AVAILABLE', lat: 12.9341, lng: 77.6261, rating: 4.8, tripsToday: 2 },
  { id: 'cr-2', name: 'Suresh', phone: '+91 98450 11022', vehicle: 'Bike', capacity: 2, zoneId: 'zn-a', status: 'AVAILABLE', lat: 12.9771, lng: 77.6392, rating: 4.6, tripsToday: 4 },
  { id: 'cr-3', name: 'Imran', phone: '+91 98450 11023', vehicle: 'Scooter', capacity: 2, zoneId: 'zn-c', status: 'ON_TRIP', lat: 12.9138, lng: 77.6421, rating: 4.7, tripsToday: 8 },
  { id: 'cr-4', name: 'Priya', phone: '+91 98450 11024', vehicle: 'Scooter', capacity: 3, zoneId: 'zn-d', status: 'AVAILABLE', lat: 12.9262, lng: 77.5951, rating: 4.9, tripsToday: 5 },
  { id: 'cr-5', name: 'Vikram', phone: '+91 98450 11025', vehicle: 'Bike', capacity: 2, zoneId: 'zn-b', status: 'ON_TRIP', lat: 12.9368, lng: 77.6218, rating: 4.5, tripsToday: 7 },
  { id: 'cr-6', name: 'Anjali', phone: '+91 98450 11026', vehicle: 'EV Scooter', capacity: 2, zoneId: 'zn-a', status: 'OFFLINE', lat: 12.9799, lng: 77.6431, rating: 4.4, tripsToday: 0 },
];

type SeedOrder = {
  code: string;
  brandId: string;
  customerName: string;
  customerPhone: string;
  address: string;
  zoneId: string;
  status: string;
  createdMinAgo: number;
  courierId?: string;
  notes?: string;
  items: { menuItemId: string; qty: number }[];
};

const ORDERS: SeedOrder[] = [
  { code: '#101', brandId: 'br-biryani', customerName: 'Aditya Rao', customerPhone: '+91 90080 20101', address: '402, Palm Grove Apartments, 12th Main, Indiranagar', zoneId: 'zn-a', status: 'RECEIVED', createdMinAgo: 2, items: [{ menuItemId: 'mi-bb-1', qty: 1 }, { menuItemId: 'mi-bb-6', qty: 1 }] },
  { code: '#102', brandId: 'br-chai', customerName: 'Meera Iyer', customerPhone: '+91 90080 20102', address: 'Shop 3, 5th Block, Koramangala', zoneId: 'zn-b', status: 'RECEIVED', createdMinAgo: 4, items: [{ menuItemId: 'mi-cp-1', qty: 2 }, { menuItemId: 'mi-cp-5', qty: 2 }] },
  { code: '#103', brandId: 'br-burger', customerName: 'Karthik Shetty', customerPhone: '+91 90080 20103', address: 'B-704, Prestige Residency, HSR Sector 2', zoneId: 'zn-c', status: 'RECEIVED', createdMinAgo: 6, notes: 'No onions, extra ketchup', items: [{ menuItemId: 'mi-bd-2', qty: 1 }, { menuItemId: 'mi-bd-4', qty: 1 }] },
  { code: '#104', brandId: 'br-burger', customerName: 'Sneha Kulkarni', customerPhone: '+91 90080 20104', address: '12, 80 Feet Road, 4th Block, Koramangala', zoneId: 'zn-b', status: 'IN_KITCHEN', createdMinAgo: 9, notes: 'Ring the bell twice', items: [{ menuItemId: 'mi-bd-1', qty: 2 }, { menuItemId: 'mi-bd-4', qty: 1 }] },
  { code: '#105', brandId: 'br-biryani', customerName: 'Rahul Menon', customerPhone: '+91 90080 20105', address: 'Flat 9C, Sobha Diamond, Jayanagar 4th Block', zoneId: 'zn-d', status: 'IN_KITCHEN', createdMinAgo: 12, items: [{ menuItemId: 'mi-bb-2', qty: 1 }, { menuItemId: 'mi-bb-5', qty: 1 }] },
  { code: '#106', brandId: 'br-biryani', customerName: 'Divya Nair', customerPhone: '+91 90080 20106', address: '301, Lake View Enclave, HSR Sector 1', zoneId: 'zn-c', status: 'IN_KITCHEN', createdMinAgo: 27, notes: 'Birthday order — add cutlery', items: [{ menuItemId: 'mi-bb-1', qty: 2 }, { menuItemId: 'mi-bb-7', qty: 2 }] },
  { code: '#107', brandId: 'br-burger', customerName: 'Arjun Pillai', customerPhone: '+91 90080 20107', address: '44, 1st Cross, Indiranagar Stage 2', zoneId: 'zn-a', status: 'IN_KITCHEN', createdMinAgo: 23, items: [{ menuItemId: 'mi-bd-3', qty: 2 }, { menuItemId: 'mi-bd-7', qty: 1 }, { menuItemId: 'mi-bd-6', qty: 1 }] },
  { code: '#108', brandId: 'br-chai', customerName: 'Nisha Verma', customerPhone: '+91 90080 20108', address: 'Tower B, Embassy Golf Links, Koramangala', zoneId: 'zn-b', status: 'PACKED', createdMinAgo: 16, items: [{ menuItemId: 'mi-cp-2', qty: 3 }, { menuItemId: 'mi-cp-4', qty: 3 }] },
  { code: '#109', brandId: 'br-burger', customerName: 'Sameer Khan', customerPhone: '+91 90080 20109', address: '18, 27th Main, HSR Sector 2', zoneId: 'zn-c', status: 'PACKED', createdMinAgo: 19, items: [{ menuItemId: 'mi-bd-1', qty: 1 }, { menuItemId: 'mi-bd-5', qty: 1 }] },
  { code: '#110', brandId: 'br-biryani', customerName: 'Lakshmi Prasad', customerPhone: '+91 90080 20110', address: '7, 11th Main, Jayanagar 2nd Block', zoneId: 'zn-d', status: 'PACKED', createdMinAgo: 21, items: [{ menuItemId: 'mi-bb-3', qty: 1 }, { menuItemId: 'mi-bb-6', qty: 2 }] },
  { code: '#111', brandId: 'br-burger', customerName: 'Tanvi Desai', customerPhone: '+91 90080 20111', address: '502, Mantri Espana, Koramangala 3rd Block', zoneId: 'zn-b', status: 'OUT_FOR_DELIVERY', createdMinAgo: 24, courierId: 'cr-5', items: [{ menuItemId: 'mi-bd-2', qty: 2 }, { menuItemId: 'mi-bd-4', qty: 2 }] },
  { code: '#112', brandId: 'br-chai', customerName: 'Rohit Bansal', customerPhone: '+91 90080 20112', address: 'WeWork Galaxy, Residency Road', zoneId: 'zn-a', status: 'OUT_FOR_DELIVERY', createdMinAgo: 26, courierId: 'cr-2', items: [{ menuItemId: 'mi-cp-1', qty: 4 }, { menuItemId: 'mi-cp-6', qty: 2 }] },
  { code: '#113', brandId: 'br-biryani', customerName: 'Ananya Ghosh', customerPhone: '+91 90080 20113', address: '22, 17th Main, HSR Sector 3', zoneId: 'zn-c', status: 'OUT_FOR_DELIVERY', createdMinAgo: 29, courierId: 'cr-3', items: [{ menuItemId: 'mi-bb-4', qty: 1 }, { menuItemId: 'mi-bb-5', qty: 1 }] },
  { code: '#114', brandId: 'br-burger', customerName: 'Vivek Joshi', customerPhone: '+91 90080 20114', address: '9, 4th Block, Jayanagar', zoneId: 'zn-d', status: 'DELIVERED', createdMinAgo: 52, courierId: 'cr-4', items: [{ menuItemId: 'mi-bd-1', qty: 1 }, { menuItemId: 'mi-bd-6', qty: 1 }] },
  { code: '#115', brandId: 'br-chai', customerName: 'Pooja Reddy', customerPhone: '+91 90080 20115', address: '301, Brigade MM, Koramangala', zoneId: 'zn-b', status: 'DELIVERED', createdMinAgo: 61, courierId: 'cr-5', items: [{ menuItemId: 'mi-cp-3', qty: 2 }, { menuItemId: 'mi-cp-5', qty: 3 }] },
];

const DELIVERY_FEE = 29;

export function seedIfEmpty(force = false): boolean {
  initSchema();
  const count = (db.prepare('SELECT COUNT(*) AS c FROM orders').get() as { c: number }).c;
  if (count > 0 && !force) return false;

  const tx = db.transaction(() => {
    if (force) {
      db.exec('DELETE FROM sms_log; DELETE FROM events; DELETE FROM order_items; DELETE FROM orders; DELETE FROM couriers; DELETE FROM zones; DELETE FROM menu_items; DELETE FROM brands;');
    }

    const insBrand = db.prepare('INSERT INTO brands (id,name,slug,cuisine,color,accent,prepBaseMinutes) VALUES (@id,@name,@slug,@cuisine,@color,@accent,@prepBaseMinutes)');
    BRANDS.forEach((b) => insBrand.run(b));

    const insItem = db.prepare('INSERT INTO menu_items (id,brandId,name,category,price,prepMinutes) VALUES (@id,@brandId,@name,@category,@price,@prepMinutes)');
    MENU.forEach((m) => insItem.run(m));

    const insZone = db.prepare('INSERT INTO zones (id,name,sector,lat,lng,radiusKm,surgeMultiplier) VALUES (@id,@name,@sector,@lat,@lng,@radiusKm,@surgeMultiplier)');
    ZONES.forEach((z) => insZone.run(z));

    const insCourier = db.prepare('INSERT INTO couriers (id,name,phone,vehicle,capacity,zoneId,status,lat,lng,rating,tripsToday) VALUES (@id,@name,@phone,@vehicle,@capacity,@zoneId,@status,@lat,@lng,@rating,@tripsToday)');
    COURIERS.forEach((c) => insCourier.run(c));

    const insOrder = db.prepare(`INSERT INTO orders
      (id,code,brandId,customerName,customerPhone,address,zoneId,status,createdAt,inKitchenAt,packedAt,dispatchedAt,deliveredAt,courierId,subtotal,deliveryFee,total,notes,etaMinutes)
      VALUES (@id,@code,@brandId,@customerName,@customerPhone,@address,@zoneId,@status,@createdAt,@inKitchenAt,@packedAt,@dispatchedAt,@deliveredAt,@courierId,@subtotal,@deliveryFee,@total,@notes,@etaMinutes)`);
    const insOrderItem = db.prepare('INSERT INTO order_items (orderId,menuItemId,name,qty,price) VALUES (?,?,?,?,?)');

    for (const o of ORDERS) {
      const items = o.items.map((it) => {
        const mi = MENU.find((m) => m.id === it.menuItemId)!;
        return { ...it, name: mi.name, price: mi.price };
      });
      const subtotal = items.reduce((s, it) => s + it.price * it.qty, 0);
      const zone = ZONES.find((z) => z.id === o.zoneId)!;
      const eta = 18 + Math.round(zone.surgeMultiplier * 6);

      const createdAt = minutesAgo(o.createdMinAgo);
      const inKitchenAt = o.status === 'RECEIVED' ? null : minutesAgo(o.createdMinAgo - 1);
      const packedAt = ['PACKED', 'OUT_FOR_DELIVERY', 'DELIVERED'].includes(o.status) ? minutesAgo(o.createdMinAgo - 14) : null;
      const dispatchedAt = ['OUT_FOR_DELIVERY', 'DELIVERED'].includes(o.status) ? minutesAgo(o.createdMinAgo - 17) : null;
      const deliveredAt = o.status === 'DELIVERED' ? minutesAgo(o.createdMinAgo - 34) : null;

      insOrder.run({
        id: `ord-${o.code.replace('#', '')}`,
        code: o.code,
        brandId: o.brandId,
        customerName: o.customerName,
        customerPhone: o.customerPhone,
        address: o.address,
        zoneId: o.zoneId,
        status: o.status,
        createdAt,
        inKitchenAt,
        packedAt,
        dispatchedAt,
        deliveredAt,
        courierId: o.courierId ?? null,
        subtotal,
        deliveryFee: DELIVERY_FEE,
        total: subtotal + DELIVERY_FEE,
        notes: o.notes ?? null,
        etaMinutes: eta,
      });

      for (const it of items) {
        insOrderItem.run(`ord-${o.code.replace('#', '')}`, it.menuItemId, it.name, it.qty, it.price);
      }
    }

    logEvent(null, 'SEED', `Seeded ${BRANDS.length} brands, ${MENU.length} menu items, ${ZONES.length} zones, ${COURIERS.length} couriers, ${ORDERS.length} orders`);
  });

  tx();
  return true;
}

export { KITCHEN };

if (process.argv[1] && process.argv[1].endsWith('seed.ts')) {
  const force = process.argv.includes('--force');
  const seeded = seedIfEmpty(force);
  console.log(seeded ? '✅ Database seeded.' : 'ℹ️  Database already has data. Use --force to reset.');
}
