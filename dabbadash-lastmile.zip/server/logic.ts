import { db } from './db.js';

export type OrderRow = {
  id: string;
  code: string;
  brandId: string;
  customerName: string;
  customerPhone: string;
  address: string;
  zoneId: string;
  status: string;
  createdAt: string;
  inKitchenAt: string | null;
  packedAt: string | null;
  dispatchedAt: string | null;
  deliveredAt: string | null;
  courierId: string | null;
  subtotal: number;
  deliveryFee: number;
  total: number;
  notes: string | null;
  etaMinutes: number;
  batchId: string | null;
};

export type ZoneRow = {
  id: string;
  name: string;
  sector: string;
  lat: number;
  lng: number;
  radiusKm: number;
  surgeMultiplier: number;
};

export type CourierRow = {
  id: string;
  name: string;
  phone: string;
  vehicle: string;
  capacity: number;
  zoneId: string | null;
  status: string;
  lat: number | null;
  lng: number | null;
  rating: number;
  tripsToday: number;
};

export const KITCHEN_COORDS = { lat: 12.9716, lng: 77.6412 };

/** Great-circle distance in km between two lat/lng points. */
export function haversineKm(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): number {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/**
 * Hyperlocal Sector Clustering Heuristic.
 *
 * Groups orders that are bound for the same delivery sector AND whose
 * destination coordinates fall within `radiusKm` (default 2.5 km) of the
 * cluster's anchor point. Greedy single-pass clustering: the first order in a
 * group becomes the anchor, and every later order joins the first cluster whose
 * anchor is within the radius and which still has spare courier capacity.
 *
 * Returns clusters sorted by size (largest first) so the dispatcher sees the
 * highest-leverage batching opportunity at the top.
 */
export type Cluster = {
  id: string;
  zoneId: string;
  zoneName: string;
  sector: string;
  anchor: { lat: number; lng: number };
  radiusKm: number;
  orders: OrderRow[];
  totalValue: number;
  maxSpreadKm: number;
  suggestedCourierId: string | null;
  suggestedCourierName: string | null;
  surgeMultiplier: number;
};

export function clusterOrders(
  orders: OrderRow[],
  zones: ZoneRow[],
  couriers: CourierRow[],
  radiusKm = 2.5,
): Cluster[] {
  const zoneById = new Map(zones.map((z) => [z.id, z]));
  const clusters: Cluster[] = [];

  // Only orders that are packed and not yet dispatched are batchable.
  const batchable = orders.filter((o) => o.status === 'PACKED' && !o.batchId);

  for (const order of batchable) {
    const zone = zoneById.get(order.zoneId);
    if (!zone) continue;

    let placed = false;
    for (const c of clusters) {
      if (c.zoneId !== order.zoneId) continue;
      const dist = haversineKm(c.anchor, { lat: zone.lat, lng: zone.lng });
      if (dist <= radiusKm) {
        c.orders.push(order);
        c.totalValue += order.total;
        c.maxSpreadKm = Math.max(c.maxSpreadKm, dist);
        placed = true;
        break;
      }
    }

    if (!placed) {
      clusters.push({
        id: `batch-${order.zoneId}-${clusters.length + 1}`,
        zoneId: order.zoneId,
        zoneName: zone.name,
        sector: zone.sector,
        anchor: { lat: zone.lat, lng: zone.lng },
        radiusKm,
        orders: [order],
        totalValue: order.total,
        maxSpreadKm: 0,
        suggestedCourierId: null,
        suggestedCourierName: null,
        surgeMultiplier: zone.surgeMultiplier,
      });
    }
  }

  // Attach a courier suggestion to each cluster.
  for (const c of clusters) {
    const pick = recommendCourier(c, couriers, zones);
    c.suggestedCourierId = pick?.courier.id ?? null;
    c.suggestedCourierName = pick?.courier.name ?? null;
  }

  return clusters.sort((a, b) => b.orders.length - a.orders.length || b.totalValue - a.totalValue);
}

/**
 * Courier Dispatch Scoring.
 *
 * Scores every AVAILABLE courier for a given order/cluster and returns the
 * best match with a human-readable reason. The score blends:
 *   - sector match        (+40)  courier's home zone == order zone
 *   - proximity           (0..30) closer to the kitchen pickup = better
 *   - capacity headroom   (+15)  can carry the whole batch
 *   - rating              (0..10)
 *   - load balancing      (-3 per trip already done today)
 */
export type CourierPick = {
  courier: CourierRow;
  score: number;
  distanceKm: number;
  reason: string;
  breakdown: { label: string; points: number }[];
};

export function recommendCourier(
  target: { zoneId: string; orders: OrderRow[] },
  couriers: CourierRow[],
  zones: ZoneRow[],
): CourierPick | null {
  const zone = zones.find((z) => z.id === target.zoneId);
  const needed = target.orders.length;

  const candidates = couriers.filter((c) => c.status === 'AVAILABLE');
  if (candidates.length === 0) return null;

  const scored: CourierPick[] = candidates.map((c) => {
    const breakdown: { label: string; points: number }[] = [];

    const sectorMatch = c.zoneId === target.zoneId;
    breakdown.push({ label: sectorMatch ? 'Same sector' : 'Different sector', points: sectorMatch ? 40 : 0 });

    const dist = c.lat != null && c.lng != null ? haversineKm({ lat: c.lat, lng: c.lng }, KITCHEN_COORDS) : 6;
    const proximity = Math.max(0, 30 - dist * 4);
    breakdown.push({ label: `Proximity to kitchen (${dist.toFixed(1)} km)`, points: Math.round(proximity) });

    const fits = c.capacity >= needed;
    breakdown.push({ label: fits ? `Capacity fits ${needed} order(s)` : `Capacity ${c.capacity} < ${needed}`, points: fits ? 15 : -10 });

    breakdown.push({ label: `Rating ${c.rating.toFixed(1)}`, points: Math.round(c.rating * 2) });

    const loadPenalty = -3 * c.tripsToday;
    breakdown.push({ label: `Load balance (${c.tripsToday} trips today)`, points: loadPenalty });

    const score = breakdown.reduce((s, b) => s + b.points, 0);

    const reasonBits: string[] = [];
    if (sectorMatch && zone) reasonBits.push(`already based in ${zone.name} (${zone.sector})`);
    if (dist < 3) reasonBits.push(`${dist.toFixed(1)} km from the commissary`);
    if (fits) reasonBits.push(`can carry all ${needed} order(s)`);
    if (c.tripsToday <= 4) reasonBits.push('lightest load today');

    return {
      courier: c,
      score,
      distanceKm: Number(dist.toFixed(2)),
      reason: reasonBits.length ? reasonBits.join(', ') : 'best available match',
      breakdown,
    };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored[0] ?? null;
}

/**
 * Rider Payout & Trip Calculator.
 *
 * Base ₹25 per drop + ₹8 per km of the delivery leg + surge multiplier for the
 * zone + a ₹15 batch bonus when a rider carries 2+ orders in one trip.
 */
export type Payout = {
  courierId: string;
  courierName: string;
  orders: number;
  distanceKm: number;
  basePay: number;
  distancePay: number;
  surgePay: number;
  batchBonus: number;
  total: number;
  breakdown: { label: string; amount: number }[];
};

export function calculatePayout(
  courier: CourierRow,
  orders: OrderRow[],
  zones: ZoneRow[],
): Payout {
  const zoneById = new Map(zones.map((z) => [z.id, z]));
  const drops = orders.length;

  let distanceKm = 0;
  for (const o of orders) {
    const z = zoneById.get(o.zoneId);
    if (z) distanceKm += haversineKm(KITCHEN_COORDS, { lat: z.lat, lng: z.lng });
  }
  distanceKm = Number(distanceKm.toFixed(2));

  const basePay = drops * 25;
  const distancePay = Number((distanceKm * 8).toFixed(2));

  const avgSurge =
    orders.reduce((s, o) => s + (zoneById.get(o.zoneId)?.surgeMultiplier ?? 1), 0) / Math.max(1, drops);
  const surgePay = Number(((basePay + distancePay) * (avgSurge - 1)).toFixed(2));

  const batchBonus = drops >= 2 ? 15 : 0;
  const total = Number((basePay + distancePay + surgePay + batchBonus).toFixed(2));

  return {
    courierId: courier.id,
    courierName: courier.name,
    orders: drops,
    distanceKm,
    basePay,
    distancePay,
    surgePay,
    batchBonus,
    total,
    breakdown: [
      { label: `Base (₹25 × ${drops} drop${drops === 1 ? '' : 's'})`, amount: basePay },
      { label: `Distance (₹8 × ${distanceKm} km)`, amount: distancePay },
      { label: `Surge (×${avgSurge.toFixed(2)} avg)`, amount: surgePay },
      { label: `Batch bonus (${drops} orders)`, amount: batchBonus },
    ],
  };
}

/** Minutes an order has been sitting in its current stage. */
export function minutesInStage(order: OrderRow): number {
  const stamp =
    order.status === 'RECEIVED'
      ? order.createdAt
      : order.status === 'IN_KITCHEN'
        ? order.inKitchenAt ?? order.createdAt
        : order.status === 'PACKED'
          ? order.packedAt ?? order.createdAt
          : order.status === 'OUT_FOR_DELIVERY'
            ? order.dispatchedAt ?? order.createdAt
            : order.deliveredAt ?? order.createdAt;
  return Math.max(0, Math.round((Date.now() - new Date(stamp).getTime()) / 60_000));
}

/** Bottleneck: an order that has been in the kitchen longer than 20 minutes. */
export const BOTTLENECK_MINUTES = 20;

export function isBottleneck(order: OrderRow): boolean {
  return order.status === 'IN_KITCHEN' && minutesInStage(order) > BOTTLENECK_MINUTES;
}

/** Average prep time (created -> packed) across orders that have been packed. */
export function averagePrepMinutes(orders: OrderRow[]): number {
  const packed = orders.filter((o) => o.packedAt);
  if (packed.length === 0) return 0;
  const total = packed.reduce((s, o) => {
    const start = new Date(o.createdAt).getTime();
    const end = new Date(o.packedAt!).getTime();
    return s + Math.max(0, (end - start) / 60_000);
  }, 0);
  return Math.round(total / packed.length);
}

export function getZones(): ZoneRow[] {
  return db.prepare('SELECT * FROM zones').all() as ZoneRow[];
}

export function getCouriers(): CourierRow[] {
  return db.prepare('SELECT * FROM couriers').all() as CourierRow[];
}
