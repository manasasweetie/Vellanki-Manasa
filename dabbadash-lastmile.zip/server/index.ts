import express from 'express';
import cors from 'cors';
import path from 'node:path';
import fs from 'node:fs';
import { db, logEvent } from './db.js';
import { seedIfEmpty } from './seed.js';
import {
  type OrderRow,
  type CourierRow,
  type ZoneRow,
  clusterOrders,
  recommendCourier,
  calculatePayout,
  minutesInStage,
  isBottleneck,
  averagePrepMinutes,
  getZones,
  getCouriers,
  BOTTLENECK_MINUTES,
} from './logic.js';

const PORT = Number(process.env.PORT ?? 4000);
const app = express();
app.use(cors());
app.use(express.json());

seedIfEmpty();

/* ------------------------------------------------------------------ *
 * Real-time fan-out via Server-Sent Events.
 * Every mutation broadcasts a `change` event; clients refetch. This is
 * the "lightweight polling / WebSocket" requirement, implemented as SSE
 * so it works through plain HTTP with no extra dependency.
 * ------------------------------------------------------------------ */
type Client = { id: number; res: express.Response };
let clients: Client[] = [];
let nextClientId = 1;

function broadcast(type: string, payload: unknown = {}) {
  const frame = `event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`;
  clients = clients.filter((c) => {
    try {
      c.res.write(frame);
      return true;
    } catch {
      return false;
    }
  });
}

app.get('/api/stream', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.write(`event: hello\ndata: ${JSON.stringify({ ok: true })}\n\n`);

  const client: Client = { id: nextClientId++, res };
  clients.push(client);

  const heartbeat = setInterval(() => {
    try {
      res.write(': ping\n\n');
    } catch {
      /* ignore */
    }
  }, 20_000);

  req.on('close', () => {
    clearInterval(heartbeat);
    clients = clients.filter((c) => c.id !== client.id);
  });
});

/* ----------------------------- helpers ---------------------------- */

const STATUS_FLOW = ['RECEIVED', 'IN_KITCHEN', 'PACKED', 'OUT_FOR_DELIVERY', 'DELIVERED'] as const;
type Status = (typeof STATUS_FLOW)[number];

function getOrder(id: string): OrderRow | undefined {
  return db.prepare('SELECT * FROM orders WHERE id = ? OR code = ?').get(id, id) as OrderRow | undefined;
}

function getOrderItems(orderId: string) {
  return db.prepare('SELECT * FROM order_items WHERE orderId = ?').all(orderId);
}

function hydrate(order: OrderRow) {
  const brand = db.prepare('SELECT * FROM brands WHERE id = ?').get(order.brandId);
  const zone = db.prepare('SELECT * FROM zones WHERE id = ?').get(order.zoneId);
  const courier = order.courierId
    ? db.prepare('SELECT * FROM couriers WHERE id = ?').get(order.courierId)
    : null;
  return {
    ...order,
    items: getOrderItems(order.id),
    brand,
    zone,
    courier,
    minutesInStage: minutesInStage(order),
    bottleneck: isBottleneck(order),
  };
}

function allOrders(): OrderRow[] {
  return db.prepare('SELECT * FROM orders ORDER BY createdAt ASC').all() as OrderRow[];
}

/* ------------------------------ reads ----------------------------- */

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, uptime: process.uptime(), clients: clients.length });
});

app.get('/api/bootstrap', (_req, res) => {
  const brands = db.prepare('SELECT * FROM brands').all();
  const menu = db.prepare('SELECT * FROM menu_items').all();
  const zones = getZones();
  const couriers = getCouriers();
  const orders = allOrders().map(hydrate);
  res.json({ brands, menu, zones, couriers, orders, bottleneckMinutes: BOTTLENECK_MINUTES });
});

app.get('/api/orders', (req, res) => {
  const { status, brandId, zoneId } = req.query as Record<string, string | undefined>;
  let rows = allOrders();
  if (status) rows = rows.filter((o) => o.status === status);
  if (brandId) rows = rows.filter((o) => o.brandId === brandId);
  if (zoneId) rows = rows.filter((o) => o.zoneId === zoneId);
  res.json(rows.map(hydrate));
});

app.get('/api/orders/:id', (req, res) => {
  const order = getOrder(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(hydrate(order));
});

app.get('/api/kpis', (_req, res) => {
  const orders = allOrders();
  const active = orders.filter((o) => o.status !== 'DELIVERED');
  const inKitchen = orders.filter((o) => o.status === 'IN_KITCHEN');
  const pendingDispatch = orders.filter((o) => o.status === 'PACKED');
  const outForDelivery = orders.filter((o) => o.status === 'OUT_FOR_DELIVERY');
  const delivered = orders.filter((o) => o.status === 'DELIVERED');
  const bottlenecks = orders.filter(isBottleneck);

  const byBrand = db
    .prepare(
      `SELECT b.id, b.name, b.color, COUNT(o.id) AS orders, COALESCE(SUM(o.total),0) AS revenue
       FROM brands b LEFT JOIN orders o ON o.brandId = b.id AND o.status != 'DELIVERED'
       GROUP BY b.id ORDER BY orders DESC`,
    )
    .all();

  res.json({
    activeOrders: active.length,
    inKitchen: inKitchen.length,
    pendingDispatch: pendingDispatch.length,
    outForDelivery: outForDelivery.length,
    delivered: delivered.length,
    avgPrepMinutes: averagePrepMinutes(orders),
    bottlenecks: bottlenecks.length,
    revenueToday: Number(orders.reduce((s, o) => s + o.total, 0).toFixed(2)),
    couriersAvailable: getCouriers().filter((c) => c.status === 'AVAILABLE').length,
    byBrand,
  });
});

app.get('/api/batches', (_req, res) => {
  const clusters = clusterOrders(allOrders(), getZones(), getCouriers());
  // Clustering works on raw rows; the client needs fully hydrated orders
  // (items, brand, zone, timers) to render the cluster cards.
  res.json(clusters.map((c) => ({ ...c, orders: c.orders.map(hydrate) })));
});

app.get('/api/couriers', (_req, res) => {
  const couriers = getCouriers();
  const orders = allOrders();
  res.json(
    couriers.map((c) => {
      const assigned = orders.filter((o) => o.courierId === c.id && o.status !== 'DELIVERED');
      return {
        ...c,
        activeOrders: assigned.length,
        payout: calculatePayout(c, assigned, getZones()),
      };
    }),
  );
});

app.get('/api/couriers/:id/payout', (req, res) => {
  const courier = db.prepare('SELECT * FROM couriers WHERE id = ?').get(req.params.id) as CourierRow | undefined;
  if (!courier) return res.status(404).json({ error: 'Courier not found' });
  const orders = allOrders().filter((o) => o.courierId === courier.id && o.status !== 'DELIVERED');
  res.json(calculatePayout(courier, orders, getZones()));
});

app.get('/api/recommend/:orderId', (req, res) => {
  const order = getOrder(req.params.orderId);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  const pick = recommendCourier({ zoneId: order.zoneId, orders: [order] }, getCouriers(), getZones());
  res.json(pick);
});

app.get('/api/events', (req, res) => {
  const limit = Number(req.query.limit ?? 40);
  res.json(db.prepare('SELECT * FROM events ORDER BY id DESC LIMIT ?').all(limit));
});

app.get('/api/sms', (_req, res) => {
  res.json(db.prepare('SELECT * FROM sms_log ORDER BY id DESC LIMIT 30').all());
});

/* ----------------------------- writes ----------------------------- */

app.post('/api/orders/:id/advance', (req, res) => {
  const order = getOrder(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  const idx = STATUS_FLOW.indexOf(order.status as Status);
  if (idx === -1 || idx === STATUS_FLOW.length - 1) {
    return res.status(400).json({ error: 'Order is already delivered' });
  }
  const next = STATUS_FLOW[idx + 1];
  const now = new Date().toISOString();

  const stampCol =
    next === 'IN_KITCHEN' ? 'inKitchenAt' : next === 'PACKED' ? 'packedAt' : next === 'OUT_FOR_DELIVERY' ? 'dispatchedAt' : 'deliveredAt';

  db.prepare(`UPDATE orders SET status = ?, ${stampCol} = ? WHERE id = ?`).run(next, now, order.id);

  if (next === 'DELIVERED' && order.courierId) {
    db.prepare('UPDATE couriers SET status = ?, tripsToday = tripsToday + 1 WHERE id = ?').run('AVAILABLE', order.courierId);
  }

  logEvent(order.id, 'STATUS', `${order.code} moved ${order.status} → ${next}`);
  broadcast('change', { orderId: order.id, status: next });

  const updated = getOrder(order.id)!;
  const recommendation =
    next === 'PACKED'
      ? recommendCourier({ zoneId: updated.zoneId, orders: [updated] }, getCouriers(), getZones())
      : null;

  res.json({ order: hydrate(updated), recommendation });
});

app.post('/api/orders/:id/assign', (req, res) => {
  const order = getOrder(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  const { courierId } = req.body as { courierId?: string };
  if (!courierId) return res.status(400).json({ error: 'courierId is required' });

  const courier = db.prepare('SELECT * FROM couriers WHERE id = ?').get(courierId) as CourierRow | undefined;
  if (!courier) return res.status(404).json({ error: 'Courier not found' });

  const now = new Date().toISOString();
  db.prepare('UPDATE orders SET courierId = ?, status = ?, dispatchedAt = ? WHERE id = ?').run(
    courierId,
    'OUT_FOR_DELIVERY',
    now,
    order.id,
  );
  db.prepare('UPDATE couriers SET status = ? WHERE id = ?').run('ON_TRIP', courierId);

  logEvent(order.id, 'DISPATCH', `${order.code} assigned to ${courier.name} (${courier.vehicle})`);
  broadcast('change', { orderId: order.id, courierId });

  res.json({ order: hydrate(getOrder(order.id)!) });
});

app.post('/api/orders/:id/unassign', (req, res) => {
  const order = getOrder(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  if (order.courierId) {
    db.prepare('UPDATE couriers SET status = ? WHERE id = ?').run('AVAILABLE', order.courierId);
  }
  db.prepare('UPDATE orders SET courierId = NULL, status = ?, dispatchedAt = NULL WHERE id = ?').run('PACKED', order.id);
  logEvent(order.id, 'DISPATCH', `${order.code} returned to the packed queue`);
  broadcast('change', { orderId: order.id });
  res.json({ order: hydrate(getOrder(order.id)!) });
});

app.post('/api/batches/:zoneId/dispatch', (req, res) => {
  const { zoneId } = req.params;
  const { courierId, orderIds } = req.body as { courierId?: string; orderIds?: string[] };
  if (!courierId) return res.status(400).json({ error: 'courierId is required' });

  const courier = db.prepare('SELECT * FROM couriers WHERE id = ?').get(courierId) as CourierRow | undefined;
  if (!courier) return res.status(404).json({ error: 'Courier not found' });

  const ids = orderIds?.length
    ? orderIds
    : (db.prepare("SELECT id FROM orders WHERE zoneId = ? AND status = 'PACKED'").all(zoneId) as { id: string }[]).map((r) => r.id);

  if (ids.length === 0) return res.status(400).json({ error: 'No packed orders in this zone' });

  const batchId = `batch-${Date.now()}`;
  const now = new Date().toISOString();
  const tx = db.transaction(() => {
    for (const id of ids) {
      db.prepare('UPDATE orders SET courierId = ?, status = ?, dispatchedAt = ?, batchId = ? WHERE id = ?').run(
        courierId,
        'OUT_FOR_DELIVERY',
        now,
        batchId,
        id,
      );
    }
    db.prepare('UPDATE couriers SET status = ? WHERE id = ?').run('ON_TRIP', courierId);
  });
  tx();

  logEvent(null, 'BATCH', `Batch of ${ids.length} order(s) dispatched to ${courier.name}`);
  broadcast('change', { batchId, courierId });

  res.json({ batchId, dispatched: ids.length, courier: courier.name });
});

app.post('/api/orders/:id/sms', (req, res) => {
  const order = getOrder(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  const link = `${req.protocol}://${req.get('host')}/track/${order.code.replace('#', '')}`;
  const message = `DabbaDash: Your order ${order.code} is ${order.status.replace(/_/g, ' ').toLowerCase()}. Track live: ${link}`;

  db.prepare('INSERT INTO sms_log (orderId, phone, message, link, createdAt) VALUES (?,?,?,?,?)').run(
    order.id,
    order.customerPhone,
    message,
    link,
    new Date().toISOString(),
  );
  logEvent(order.id, 'SMS', `Tracking link sent to ${order.customerPhone}`);
  broadcast('change', { orderId: order.id, sms: true });

  res.json({ sent: true, to: order.customerPhone, message, link });
});

app.post('/api/couriers/:id/status', (req, res) => {
  const { status } = req.body as { status?: string };
  if (!status || !['AVAILABLE', 'ON_TRIP', 'OFFLINE'].includes(status)) {
    return res.status(400).json({ error: 'status must be AVAILABLE, ON_TRIP or OFFLINE' });
  }
  db.prepare('UPDATE couriers SET status = ? WHERE id = ?').run(status, req.params.id);
  broadcast('change', { courierId: req.params.id, status });
  res.json({ ok: true });
});

app.post('/api/reset', (_req, res) => {
  seedIfEmpty(true);
  broadcast('change', { reset: true });
  res.json({ ok: true, message: 'Demo data reset' });
});

/* --------------------------- static build -------------------------- */

const distDir = path.resolve(process.cwd(), 'dist');
if (fs.existsSync(distDir)) {
  app.use(express.static(distDir));
  app.get(/^(?!\/api).*/, (_req, res) => {
    res.sendFile(path.join(distDir, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`\n  🍱  DabbaDash API  →  http://localhost:${PORT}`);
  console.log(`      SSE stream     →  http://localhost:${PORT}/api/stream`);
  if (fs.existsSync(distDir)) console.log(`      Dashboard      →  http://localhost:${PORT}\n`);
  else console.log(`      Run \`npm run dev\` for the Vite dev server on :5173\n`);
});
