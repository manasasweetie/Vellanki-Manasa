export interface Point{ id:string; lat:number; lng:number; zoneId:string }
export function haversineKm(a:Point,b:Point){const R=6371;const rad=(n:number)=>n*Math.PI/180;const dLat=rad(b.lat-a.lat),dLng=rad(b.lng-a.lng);const x=Math.sin(dLat/2)**2+Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(dLng/2)**2;return 2*R*Math.asin(Math.sqrt(x));}
export function clusterOrders(points:Point[],radiusKm=2.5){const groups:Point[][]=[];for(const p of points){let group=groups.find(g=>g.some(q=>haversineKm(p,q)<=radiusKm));if(!group){group=[p];groups.push(group)}else group.push(p)}return groups;}
export function routeScore(orderZone:string,courierZone:string,activeOrders:number,capacity:number){return (orderZone===courierZone?0:100)+activeOrders*10+(capacity-activeOrders===1?5:0)}
