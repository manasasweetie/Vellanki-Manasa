import { useEffect, useMemo, useState } from "react";
import {
  Activity, Bike, Check, ChevronRight, Clock3, CookingPot, MapPin,
  PackageCheck, Radio, Send, ShoppingBag, Timer, Truck, Users, X
} from "lucide-react";

type Status = "RECEIVED" | "IN_KITCHEN" | "PACKED" | "OUT_FOR_DELIVERY" | "DELIVERED";
type Order = {
  id: string; customer: string; brand: string; brandIcon: string; items: string[];
  amount: number; zone: string; status: Status; prepMinutes: number;
  createdAt: number; courierId?: string; eta: number;
};
type Courier = {
  id: string; name: string; zone: string; vehicle: string;
  capacity: number; activeOrders: number; available: boolean;
};

const statuses: { key: Status; label: string; color: string }[] = [
  { key:"RECEIVED", label:"Received", color:"#66758f" },
  { key:"IN_KITCHEN", label:"In Kitchen", color:"#7a62d8" },
  { key:"PACKED", label:"Packed", color:"#d48716" },
  { key:"OUT_FOR_DELIVERY", label:"Out for Delivery", color:"#2d91c9" },
  { key:"DELIVERED", label:"Delivered", color:"#2b9b67" },
];

const seedOrders: Order[] = [
  {id:"104",customer:"Aarav",brand:"Burger Den",brandIcon:"🍔",items:["2 Burgers","Fries"],amount:320,zone:"Zone 2",status:"IN_KITCHEN",prepMinutes:23,createdAt:Date.now()-23*60000,eta:14},
  {id:"101",customer:"Diya",brand:"Biryani Box",brandIcon:"🍛",items:["Chicken Biryani","Raita"],amount:410,zone:"Zone 1",status:"RECEIVED",prepMinutes:4,createdAt:Date.now()-4*60000,eta:18},
  {id:"105",customer:"Rohan",brand:"Chai Point",brandIcon:"☕",items:["Masala Chai","Samosa"],amount:180,zone:"Zone 3",status:"RECEIVED",prepMinutes:8,createdAt:Date.now()-8*60000,eta:12},
  {id:"108",customer:"Meera",brand:"Biryani Box",brandIcon:"🍛",items:["Veg Biryani","Kebab"],amount:360,zone:"Zone 4",status:"IN_KITCHEN",prepMinutes:18,createdAt:Date.now()-18*60000,eta:16},
  {id:"109",customer:"Ishaan",brand:"Burger Den",brandIcon:"🍔",items:["Classic Burger","Nuggets"],amount:290,zone:"Zone 1",status:"IN_KITCHEN",prepMinutes:11,createdAt:Date.now()-11*60000,eta:15},
  {id:"111",customer:"Ananya",brand:"Chai Point",brandIcon:"☕",items:["2 Cold Coffees","Sandwich"],amount:260,zone:"Zone 2",status:"PACKED",prepMinutes:16,createdAt:Date.now()-16*60000,eta:13},
  {id:"112",customer:"Kabir",brand:"Burger Den",brandIcon:"🍔",items:["2 Wraps","Fries"],amount:340,zone:"Zone 2",status:"PACKED",prepMinutes:14,createdAt:Date.now()-14*60000,eta:11},
  {id:"102",customer:"Sara",brand:"Biryani Box",brandIcon:"🍛",items:["Paneer Biryani"],amount:300,zone:"Zone 3",status:"OUT_FOR_DELIVERY",prepMinutes:13,createdAt:Date.now()-25*60000,eta:9,courierId:"r1"},
  {id:"103",customer:"Vikram",brand:"Burger Den",brandIcon:"🍔",items:["Cheese Burger","Fries"],amount:275,zone:"Zone 4",status:"OUT_FOR_DELIVERY",prepMinutes:12,createdAt:Date.now()-27*60000,eta:7,courierId:"r3"},
  {id:"99",customer:"Nisha",brand:"Chai Point",brandIcon:"☕",items:["Tea","Cookies"],amount:150,zone:"Zone 1",status:"DELIVERED",prepMinutes:10,createdAt:Date.now()-50*60000,eta:0,courierId:"r2"},
  {id:"106",customer:"Aditya",brand:"Biryani Box",brandIcon:"🍛",items:["Chicken Biryani"],amount:390,zone:"Zone 4",status:"RECEIVED",prepMinutes:3,createdAt:Date.now()-3*60000,eta:19},
  {id:"107",customer:"Tara",brand:"Chai Point",brandIcon:"☕",items:["Iced Tea","Puff"],amount:190,zone:"Zone 2",status:"IN_KITCHEN",prepMinutes:21,createdAt:Date.now()-21*60000,eta:17},
  {id:"110",customer:"Neil",brand:"Burger Den",brandIcon:"🍔",items:["Double Burger"],amount:240,zone:"Zone 3",status:"PACKED",prepMinutes:15,createdAt:Date.now()-15*60000,eta:10},
  {id:"113",customer:"Maya",brand:"Biryani Box",brandIcon:"🍛",items:["Veg Biryani"],amount:250,zone:"Zone 1",status:"IN_KITCHEN",prepMinutes:22,createdAt:Date.now()-22*60000,eta:15},
  {id:"114",customer:"Arjun",brand:"Chai Point",brandIcon:"☕",items:["Cutting Chai","Samosa"],amount:160,zone:"Zone 4",status:"RECEIVED",prepMinutes:6,createdAt:Date.now()-6*60000,eta:18},
];

const seedCouriers: Courier[] = [
  {id:"r1",name:"Ramesh",zone:"Zone 2",vehicle:"Bike",capacity:3,activeOrders:0,available:true},
  {id:"r2",name:"Suresh",zone:"Zone 1",vehicle:"Scooter",capacity:2,activeOrders:1,available:true},
  {id:"r3",name:"Arjun",zone:"Zone 3",vehicle:"Bike",capacity:3,activeOrders:1,available:true},
  {id:"r4",name:"Priya",zone:"Zone 4",vehicle:"Scooter",capacity:2,activeOrders:0,available:true},
  {id:"r5",name:"Kiran",zone:"Zone 2",vehicle:"Bike",capacity:3,activeOrders:2,available:true},
  {id:"r6",name:"Rahul",zone:"Zone 1",vehicle:"Bike",capacity:3,activeOrders:0,available:true},
];

const iconFor = (s: Status) => s==="RECEIVED" ? <ShoppingBag size={14}/> : s==="IN_KITCHEN" ? <CookingPot size={14}/> : s==="PACKED" ? <PackageCheck size={14}/> : s==="OUT_FOR_DELIVERY" ? <Truck size={14}/> : <Check size={14}/>;

function App() {
  const [orders, setOrders] = useState(seedOrders);
  const [couriers, setCouriers] = useState(seedCouriers);
  const [view, setView] = useState<"dashboard"|"customer">("dashboard");
  const [selectedOrder, setSelectedOrder] = useState("104");
  const [assigning, setAssigning] = useState<Order|null>(null);
  const [customerEta, setCustomerEta] = useState(14);

  useEffect(() => {
    const t = setInterval(() => {
      setOrders(prev => prev.map(o => o.status==="OUT_FOR_DELIVERY" && o.eta>0 ? {...o,eta:o.eta-1} : o));
      setCustomerEta(v => v>0 ? v-1 : 0);
    }, 5000);
    return () => clearInterval(t);
  }, []);

  const activeOrders = orders.filter(o => o.status !== "DELIVERED").length;
  const avgPrep = Math.round(orders.reduce((a,o)=>a+o.prepMinutes,0)/orders.length);
  const pendingDispatch = orders.filter(o => o.status==="PACKED").length;
  const selected = orders.find(o => o.id===selectedOrder) ?? orders[0];

  const recommend = (order: Order) => [...couriers]
    .filter(c => c.available && c.activeOrders < c.capacity)
    .sort((a,b) => (a.zone===order.zone?0:1)-(b.zone===order.zone?0:1))[0];

  const advance = (id: string) => {
    setOrders(prev => prev.map(o => {
      if(o.id!==id) return o;
      const idx = statuses.findIndex(s=>s.key===o.status);
      return idx < statuses.length-1 ? {...o,status:statuses[idx+1].key} : o;
    }));
  };

  const assignCourier = (courierId: string) => {
    if (!assigning) return;
    setOrders(prev => prev.map(o => o.id===assigning.id ? {...o,status:"OUT_FOR_DELIVERY",courierId,eta:15} : o));
    setCouriers(prev => prev.map(c => c.id===courierId ? {...c,activeOrders:c.activeOrders+1} : c));
    setAssigning(null);
    setSelectedOrder(assigning.id);
  };

  const zones = ["Zone 1","Zone 2","Zone 3","Zone 4"].map(z => ({
    z, count: orders.filter(o=>o.zone===z && o.status!=="DELIVERED").length
  }));

  return (
    <div className="app">
      <header className="header">
        <div className="branding">
          <div className="logo">🍱</div>
          <div><div className="title">DabbaDash</div><div className="subtitle">LastMile Bite Battle</div></div>
        </div>
        <div className="header-actions">
          <div className="live"><span className="dot"/> LIVE SYNC</div>
          <div className="view-toggle">
            <button className={view==="dashboard"?"active":""} onClick={()=>setView("dashboard")}>Kitchen Dashboard</button>
            <button className={view==="customer"?"active":""} onClick={()=>setView("customer")}>Customer View</button>
          </div>
        </div>
      </header>

      <main className="page">
        {view==="dashboard" ? (
          <>
            <div className="hero">
              <div><h1>Dispatch Command Center</h1><p>One kitchen. Multiple brands. Smarter last-mile dispatch.</p></div>
              <div className="muted">Updated just now · polling every 5 sec</div>
            </div>

            <div className="kpis">
              <Kpi icon={<Activity/>} label="Active Orders" value={activeOrders} note="Across 3 virtual brands"/>
              <Kpi icon={<Timer/>} label="Avg Prep Time" value={`${avgPrep}m`} note="Live kitchen average"/>
              <Kpi icon={<Send/>} label="Pending Dispatch" value={pendingDispatch} note="Packed & waiting"/>
              <Kpi icon={<Bike/>} label="Active Couriers" value={couriers.filter(c=>c.available).length} note="6 riders on roster"/>
            </div>

            <div className="board">
              {statuses.map(s => {
                const col = orders.filter(o=>o.status===s.key);
                return <div className="column" key={s.key}>
                  <div className="column-head">
                    <div className="column-title" style={{color:s.color}}>{iconFor(s.key)} {s.label}</div>
                    <div className="count">{col.length}</div>
                  </div>
                  <div className="column-body">
                    {col.map(o => <OrderCard key={o.id} order={o} onAdvance={advance} onAssign={()=>setAssigning(o)} onTrack={()=>{setSelectedOrder(o.id);setView("customer")}}/> )}
                    {!col.length && <div className="muted" style={{padding:20,textAlign:"center"}}>No orders</div>}
                  </div>
                </div>
              })}
            </div>

            <div className="section">
              <section className="panel">
                <div className="panel-title"><h2>Hyperlocal Zone Batching</h2><span className="muted">Orders grouped by delivery sector</span></div>
                <div className="zone-list">
                  {zones.map(x=><div className="zone-row" key={x.z}><div className="zone-name">{x.z}</div><div className="bar"><div style={{width:`${Math.min(100,x.count*22+10)}%`}}/></div><div className="zone-num">{x.count} orders</div></div>)}
                </div>
              </section>
              <section className="panel">
                <div className="panel-title"><h2>Courier Dispatch</h2><span className="muted">Availability</span></div>
                <div className="rider-list">
                  {couriers.map(c=><div className="rider-row" key={c.id}>
                    <div className="rider-left"><div className="avatar">{c.vehicle==="Bike"?"🏍️":"🛵"}</div><div><div className="rider-name">{c.name}</div><div className="rider-zone">{c.zone} · {c.activeOrders}/{c.capacity} orders</div></div></div>
                    <span className="status">{c.available?"AVAILABLE":"BUSY"}</span>
                  </div>)}
                </div>
              </section>
            </div>
          </>
        ) : (
          <div className="tracker">
            <div className="hero"><div><h1>Customer Order Tracking</h1><p>Live status simulation for order #{selected.id}</p></div></div>
            <div className="tracker-card">
              <div className="track-head">
                <div><div className="track-brand">{selected.brandIcon} {selected.brand}</div><div className="track-order">Order #{selected.id}</div><div className="muted" style={{marginTop:5}}>{selected.items.join(" · ")} · ₹{selected.amount}</div></div>
                <div className="eta"><small>ESTIMATED ARRIVAL</small><strong>{selected.status==="DELIVERED"?"Delivered":`${selected.eta} min`}</strong></div>
              </div>
              <div className="stepper">
                {statuses.map((s,i)=>{
                  const current=statuses.findIndex(x=>x.key===selected.status);
                  return <div className={`step ${i<current?"done":i===current?"current":""}`} key={s.key}><div className="step-dot">{i<current?<Check size={14}/>:i+1}</div><div className="step-label">{s.label}</div></div>
                })}
              </div>
              <div className="delivery-box">
                <div className="muted">{selected.status==="OUT_FOR_DELIVERY" ? "Courier is on the way" : selected.status==="PACKED" ? "Waiting for courier pickup" : "Kitchen is preparing your order"}</div>
                <div className="route" style={{"--progress":`${Math.max(5,Math.min(100,(15-selected.eta)/15*100))}%`} as React.CSSProperties}>
                  <div className="route-line"><div className="route-progress"/></div>
                  <div className="scooter">{selected.status==="OUT_FOR_DELIVERY"?"🛵":"📦"}</div><div className="home">🏠</div>
                </div>
                <div className="driver">
                  <div className="driver-info"><div className="driver-icon">{selected.courierId?"🛵":"👨‍🍳"}</div><div><div className="driver-name">{selected.courierId ? `Courier ${couriers.find(c=>c.id===selected.courierId)?.name}` : selected.status==="PACKED" ? "Courier being assigned" : "DabbaDash Kitchen"}</div><div className="driver-sub">{selected.courierId ? "Picking up your food now" : "Real-time kitchen update"}</div></div></div>
                  {selected.status==="OUT_FOR_DELIVERY" && <span className="status"><Radio size={10}/> LIVE</span>}
                </div>
              </div>
              <div style={{marginTop:18,display:"flex",gap:8}}>
                <button className="btn secondary" onClick={()=>setView("dashboard")}>Back to Kitchen</button>
                {selected.status!=="DELIVERED" && <button className="btn" onClick={()=>advance(selected.id)}>Simulate Next Update <ChevronRight size={14} style={{verticalAlign:"middle"}}/></button>}
              </div>
            </div>
          </div>
        )}
      </main>

      {assigning && <div className="modal-wrap" onClick={()=>setAssigning(null)}>
        <div className="modal" onClick={e=>e.stopPropagation()}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}><h3>Assign Courier · #{assigning.id}</h3><button style={{border:0,background:"transparent"}} onClick={()=>setAssigning(null)}><X/></button></div>
          <p>Recommended rider is selected using delivery-zone proximity and remaining capacity.</p>
          <select className="select" id="riderSelect" defaultValue={recommend(assigning)?.id}>
            {couriers.filter(c=>c.available && c.activeOrders<c.capacity).map(c=><option key={c.id} value={c.id}>{c.name} — {c.zone} — {c.activeOrders}/{c.capacity} active</option>)}
          </select>
          <div className="modal-actions">
            <button className="btn secondary" onClick={()=>setAssigning(null)}>Cancel</button>
            <button className="btn" onClick={()=>assignCourier((document.getElementById("riderSelect") as HTMLSelectElement).value)}>Assign & Dispatch</button>
          </div>
        </div>
      </div>}
    </div>
  );
}

function Kpi({icon,label,value,note}:{icon:React.ReactNode;label:string;value:string|number;note:string}) {
  return <div className="kpi"><div className="kpi-top"><span>{label}</span><div className="kpi-icon">{icon}</div></div><div className="kpi-value">{value}</div><div className="kpi-note">{note}</div></div>;
}

function OrderCard({order,onAdvance,onAssign,onTrack}:{order:Order;onAdvance:(id:string)=>void;onAssign:()=>void;onTrack:()=>void}) {
  const canAdvance = order.status!=="DELIVERED";
  const nextLabel = order.status==="IN_KITCHEN" ? "Mark Packed" : order.status==="PACKED" ? "Assign Courier" : order.status==="RECEIVED" ? "Start Cooking" : order.status==="OUT_FOR_DELIVERY" ? "Mark Delivered" : "";
  const bottleneck = order.status==="IN_KITCHEN" && order.prepMinutes>20;
  return <div className="card">
    <div className="card-top"><div><div className="order-id">#{order.id} · {order.customer}</div><div className="time">{order.prepMinutes} min in flow</div></div><div style={{fontWeight:800,fontSize:11}}>₹{order.amount}</div></div>
    <div className="brand">{order.brandIcon} {order.brand}</div>
    <div className="items">{order.items.join(" + ")}</div>
    <div className="meta"><div className="meta-box"><span>Zone</span><b>{order.zone}</b></div><div className="meta-box"><span>ETA</span><b>{order.eta ? `${order.eta} min` : "Done"}</b></div></div>
    {bottleneck && <div className="alert">⚠ Kitchen bottleneck · over 20 min</div>}
    {order.courierId && <div className="rider">🛵 <b>{order.courierId==="r1"?"Ramesh":order.courierId==="r2"?"Suresh":order.courierId==="r3"?"Arjun":"Courier"}</b> · assigned</div>}
    {order.status==="PACKED" && <button className="btn" onClick={onAssign}>Assign Recommended Courier</button>}
    {canAdvance && order.status!=="PACKED" && <button className="btn" onClick={()=>onAdvance(order.id)}>{nextLabel}</button>}
    {order.status==="OUT_FOR_DELIVERY" && <button className="btn secondary" onClick={onTrack}>Open Customer Tracker</button>}
  </div>;
}

export default App;