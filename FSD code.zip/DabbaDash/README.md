# DabbaDash — LastMile Bite Battle

A hackathon-ready frontend prototype for hyperlocal cloud-kitchen delivery management.

## Features
- Multi-brand order aggregation
- 5-stage order lifecycle
- Rider assignment with zone + capacity recommendation
- Hyperlocal zone batching
- Customer live tracking mock-up
- ETA countdown simulation
- Kitchen bottleneck alerts over 20 minutes
- Courier availability console
- Responsive dashboard

## Run locally

Requirements:
- Node.js 18+ (Node 20+ recommended)

Install:
```bash
npm install
```

Start:
```bash
npm run dev
```

Then open the localhost URL shown by Vite.

## Demo flow

1. Open Kitchen Dashboard.
2. Find Order #104 (Burger Den).
3. Click **Mark Packed**.
4. Click **Assign Recommended Courier**.
5. Ramesh from Zone 2 is recommended.
6. Click **Assign & Dispatch**.
7. Open Customer Tracker.
8. The order is now shown as **Out for Delivery** with a simulated moving scooter and ETA.

## Backend upgrade path

This prototype keeps state in React for a fast hackathon demo. The same interfaces can be connected to:
- Node.js + Express REST API
- SQLite database
- WebSockets or 3-second polling
- Leaflet for a real city/sector map
