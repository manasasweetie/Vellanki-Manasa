# DabbaDash — LastMile Bite Battle

A polished frontend hackathon demo for a hyperlocal cloud-kitchen dispatch system.

## Features
- Multi-brand order aggregation for Biryani Box, Burger Den and Chai Point.
- 5-stage lifecycle: Received → In Kitchen → Packed → Out for Delivery → Delivered.
- Courier assignment with zone-aware rider list.
- Hyperlocal sector batching for Sectors A–D.
- Customer tracking simulator with animated scooter position and ETA.
- Live operational KPI cards.
- 20-minute kitchen bottleneck alerts.
- Rider fleet / performance dashboard.
- SMS tracking-link simulator.
- Responsive layout for desktop and mobile.

## Run
Requires Node.js 18+.

```bash
npm install
npm run dev
```

Open the local Vite URL shown in the terminal.

## Demo flow
1. Open Dispatch Board.
2. Find Order #104 in In Kitchen.
3. Click Mark Packed.
4. Open the Packed column and assign Ramesh.
5. Switch to Customer Tracking and select Order #104.
6. The status stepper and courier/ETA update from the same in-memory order state.

This is intentionally a frontend-only simulation using seeded data; no external API key is required.
