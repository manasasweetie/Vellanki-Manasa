import React,{useEffect,useMemo,useState} from 'react'
import {createRoot} from 'react-dom/client'
import {Activity,ArrowRight,BarChart3,CheckCircle2,Clock3,MapPin,Package,Phone,Plus,RefreshCw,Send,ShoppingBag,Truck,Users,Utensils,CircleAlert,ChevronRight,X} from 'lucide-react'
import './styles.css'

type Status='Received'|'In Kitchen'|'Packed'|'Out for Delivery'|'Delivered'
type Brand='Biryani Box'|'Burger Den'|'Chai Point'
type Zone='Sector A'|'Sector B'|'Sector C'|'Sector D'
type Order={id:number,brand:Brand,items:string[],customer:string,zone:Zone,total:number,status:Status,prep:number,eta:number,courier?:string,created:number}
type Courier={name:string,zone:Zone,vehicle:string,capacity:number,active:boolean}

const brands:Brand[]=['Biryani Box','Burger Den','Chai Point']
const initialOrders:Order[]=[
{id:104,brand:'Burger Den',items:['2 Classic Burgers','Fries'],customer:'Aarav Sharma',zone:'Sector B',total:318,status:'In Kitchen',prep:18,eta:14,courier:undefined,created:Date.now()-20*60000},
{id:105,brand:'Biryani Box',items:['Chicken Biryani','Raita'],customer:'Diya Rao',zone:'Sector A',total:289,status:'Received',prep:7,eta:18,created:Date.now()-8*60000},
{id:106,brand:'Chai Point',items:['Masala Chai x2','Samosa x3'],customer:'Rohan Kumar',zone:'Sector C',total:176,status:'Packed',prep:12,eta:10,created:Date.now()-15*60000,courier:'Ramesh'},
{id:107,brand:'Biryani Box',items:['Veg Biryani','Gulab Jamun'],customer:'Ananya Das',zone:'Sector A',total:249,status:'Out for Delivery',prep:16,eta:9,created:Date.now()-25*60000,courier:'Priya'},
{id:108,brand:'Burger Den',items:['Crispy Chicken Burger'],customer:'Kabir Singh',zone:'Sector D',total:199,status:'Received',prep:4,eta:22,created:Date.now()-5*60000},
{id:109,brand:'Chai Point',items:['Cold Coffee','Paneer Roll'],customer:'Meera Patel',zone:'Sector C',total:248,status:'In Kitchen',prep:22,eta:15,created:Date.now()-27*60000},
{id:110,brand:'Burger Den',items:['Veg Burger','Loaded Fries'],customer:'Ishaan Verma',zone:'Sector B',total:299,status:'Packed',prep:14,eta:12,created:Date.now()-18*60000},
{id:111,brand:'Biryani Box',items:['Mutton Biryani'],customer:'Neha Jain',zone:'Sector D',total:399,status:'Delivered',prep:17,eta:0,created:Date.now()-45*60000,courier:'Arjun'},
{id:112,brand:'Chai Point',items:['Tea x2','Vada Pav x2'],customer:'Vikram Shah',zone:'Sector A',total:158,status:'In Kitchen',prep:11,eta:19,created:Date.now()-12*60000},
{id:113,brand:'Burger Den',items:['Double Cheese Burger'],customer:'Sara Ali',zone:'Sector B',total:259,status:'Out for Delivery',prep:15,eta:6,created:Date.now()-30*60000,courier:'Ramesh'},
{id:114,brand:'Biryani Box',items:['Chicken 65','Biryani'],customer:'Aditya Rao',zone:'Sector C',total:349,status:'Received',prep:3,eta:24,created:Date.now()-3*60000},
{id:115,brand:'Chai Point',items:['Irani Chai','Bun Maska'],customer:'Nisha Gupta',zone:'Sector D',total:189,status:'Packed',prep:13,eta:11,created:Date.now()-17*60000,courier:'Arjun'},
{id:116,brand:'Burger Den',items:['Classic Burger x2'],customer:'Rahul Mehta',zone:'Sector A',total:278,status:'Delivered',prep:12,eta:0,created:Date.now()-50*60000,courier:'Priya'},
{id:117,brand:'Biryani Box',items:['Paneer Biryani'],customer:'Tanya Roy',zone:'Sector B',total:229,status:'In Kitchen',prep:21,eta:17,created:Date.now()-26*60000},
{id:118,brand:'Chai Point',items:['Masala Chai','Samosa'],customer:'Arjun Nair',zone:'Sector C',total:128,status:'Received',prep:5,eta:20,created:Date.now()-6*60000}
]
const couriers:Courier[]=[
{name:'Ramesh',zone:'Sector B',vehicle:'Scooter',capacity:2,active:true},
{name:'Priya',zone:'Sector A',vehicle:'Scooter',capacity:2,active:true},
{name:'Arjun',zone:'Sector D',vehicle:'Bike',capacity:3,active:true},
{name:'Sanjay',zone:'Sector C',vehicle:'Scooter',capacity:2,active:true},
{name:'Kiran',zone:'Sector B',vehicle:'Bike',capacity:1,active:true},
{name:'Meena',zone:'Sector A',vehicle:'Scooter',capacity:2,active:true}
]
const statuses:Status[]=['Received','In Kitchen','Packed','Out for Delivery','Delivered']
const brandClass=(b:Brand)=>b.toLowerCase().replaceAll(' ','-')
function App(){
 const [orders,setOrders]=useState(initialOrders)
 const [tab,setTab]=useState<'board'|'tracking'|'analytics'>('board')
 const [filter,setFilter]=useState<'All'|Brand>('All')
 const [selected,setSelected]=useState<Order|null>(null)
 const [query,setQuery]=useState('')
 const [toast,setToast]=useState('')
 useEffect(()=>{const t=setInterval(()=>setOrders(o=>o.map(x=>x.status==='Out for Delivery'?{...x,eta:Math.max(0,x.eta-1)}:x)),60000);return()=>clearInterval(t)},[])
 useEffect(()=>{if(toast){const t=setTimeout(()=>setToast(''),2600);return()=>clearTimeout(t)}},[toast])
 const filtered=orders.filter(o=>(filter==='All'||o.brand===filter)&&(`${o.id} ${o.customer} ${o.brand} ${o.zone}`.toLowerCase().includes(query.toLowerCase())))
 const avg=Math.round(orders.filter(o=>o.status!=='Received').reduce((a,o)=>a+o.prep,0)/Math.max(1,orders.filter(o=>o.status!=='Received').length))
 const active=orders.filter(o=>o.status!=='Delivered').length
 const dispatched=orders.filter(o=>o.status==='Out for Delivery').length
 const packed=orders.filter(o=>o.status==='Packed').length
 const alertCount=orders.filter(o=>o.status==='In Kitchen'&&o.prep>20).length
 function advance(id:number){
  setOrders(os=>os.map(o=>{if(o.id!==id)return o; const i=statuses.indexOf(o.status); const next=statuses[Math.min(i+1,statuses.length-1)]; return {...o,status:next,eta:next==='Out for Delivery'?12:next==='Delivered'?0:o.eta}}))
  setToast(`Order #${id} advanced to the next stage`)
 }
 function assign(id:number,name:string){
  setOrders(os=>os.map(o=>o.id===id?{...o,courier:name,status:'Out for Delivery'}:o))
  setToast(`${name} assigned to Order #${id}`)
 }
 const zones=useMemo(()=>['Sector A','Sector B','Sector C','Sector D'].map(z=>({zone:z,count:orders.filter(o=>o.zone===z&&o.status!=='Delivered').length})),[orders])
 return <div className="app">
  <header className="topbar">
   <div className="brandmark"><div className="logo">D</div><div><h1>DabbaDash</h1><span>LastMile Bite Battle</span></div></div>
   <div className="live"><span className="pulse"></span> LIVE DISPATCH</div>
   <div className="actions"><button className="iconbtn"><RefreshCw size={18}/></button><div className="avatar">SM</div></div>
  </header>
  <nav className="nav"><button className={tab==='board'?'active':''} onClick={()=>setTab('board')}><Package size={17}/> Dispatch Board</button><button className={tab==='tracking'?'active':''} onClick={()=>setTab('tracking')}><Truck size={17}/> Customer Tracking</button><button className={tab==='analytics'?'active':''} onClick={()=>setTab('analytics')}><BarChart3 size={17}/> Performance</button></nav>
  <main>
   <section className="hero"><div><p className="eyebrow">COMMISSARY CONTROL CENTER</p><h2>{tab==='board'?'Order dispatch command center':tab==='tracking'?'Live customer tracking':'Kitchen performance overview'}</h2><p className="sub">One kitchen. Multiple brands. Every order moving together.</p></div><div className="date">Friday, 20 Nov 2026<br/><b>Peak service window</b></div></section>
   <div className="kpis">
    <Kpi icon={<Activity/>} label="Active Orders" value={active} note="Across all brands"/>
    <Kpi icon={<Clock3/>} label="Avg Prep Time" value={`${avg}m`} note="Target ≤ 18m"/>
    <Kpi icon={<Send/>} label="Out for Delivery" value={dispatched} note={`${packed} packed & waiting`}/>
    <Kpi icon={<CircleAlert/>} label="Bottleneck Alerts" value={alertCount} note="Over 20 min in kitchen" danger={alertCount>0}/>
   </div>
   {tab==='board'&&<Board filtered={filtered} filter={filter} setFilter={setFilter} query={query} setQuery={setQuery} advance={advance} assign={assign} selected={selected} setSelected={setSelected}/>}
   {tab==='tracking'&&<Tracking orders={orders} selected={selected} setSelected={setSelected}/>}
   {tab==='analytics'&&<Analytics orders={orders} zones={zones}/>}
  </main>
  {toast&&<div className="toast"><CheckCircle2 size={18}/>{toast}</div>}
  {selected&&<OrderModal order={orders.find(o=>o.id===selected.id)||selected} close={()=>setSelected(null)} advance={advance} assign={assign}/>}
 </div>
}
function Kpi({icon,label,value,note,danger=false}:{icon:React.ReactNode,label:string,value:string|number,note:string,danger?:boolean}){return <div className="kpi"><div className="kpiicon">{icon}</div><div><div className="kpilabel">{label}</div><div className="kpivalue">{value}</div><div className={danger?'danger note':'note'}>{note}</div></div></div>}
function Board(p:any){
 return <section className="content"><div className="toolbar"><div className="filters"><button className={p.filter==='All'?'pill active':''} onClick={()=>p.setFilter('All')}>All Brands</button>{brands.map(b=><button key={b} className={p.filter===b?'pill active':''} onClick={()=>p.setFilter(b)}><span className={`dot ${brandClass(b)}`}></span>{b}</button>)}</div><div className="search"><span>⌕</span><input value={p.query} onChange={e=>p.setQuery(e.target.value)} placeholder="Search order, customer, zone..."/></div></div>
 <div className="board">{statuses.slice(0,4).map((s:Status)=><Column key={s} status={s} orders={p.filtered.filter((o:Order)=>o.status===s)} advance={p.advance} assign={p.assign} setSelected={p.setSelected}/>)}</div>
 <div className="batchbar"><div><b><MapPin size={16}/> Hyperlocal batching</b><span>Orders in the same zone are grouped for efficient multi-drop routes.</span></div><div className="zones">{['Sector A','Sector B','Sector C','Sector D'].map(z=><span key={z}>{z} <b>{p.filtered.filter((o:Order)=>o.zone===z&&o.status!=='Delivered').length}</b></span>)}</div></div>
 </section>
}
function Column({status,orders,advance,assign,setSelected}:{status:Status,orders:Order[],advance:(id:number)=>void,assign:(id:number,n:string)=>void,setSelected:(o:Order)=>void}){
 return <div className="column"><div className="colhead"><div><span className={`stage ${status.toLowerCase().replaceAll(' ','-')}`}></span><b>{status}</b></div><span className="count">{orders.length}</span></div><div className="cards">{orders.map(o=><OrderCard key={o.id} o={o} advance={advance} assign={assign} setSelected={setSelected}/>)}</div></div>
}
function OrderCard({o,advance,assign,setSelected}:{o:Order,advance:(id:number)=>void,assign:(id:number,n:string)=>void,setSelected:(o:Order)=>void}){
 const next=statuses[Math.min(statuses.indexOf(o.status)+1,statuses.length-1)]
 return <article className={`ordercard ${o.prep>20&&o.status==='In Kitchen'?'warning':''}`} onClick={()=>setSelected(o)}>
  <div className="cardtop"><span className={`brandtag ${brandClass(o.brand)}`}>{o.brand}</span><b>#{o.id}</b></div>
  <h3>{o.customer}</h3><p className="items">{o.items.join(' • ')}</p>
  <div className="meta"><span><MapPin size={13}/>{o.zone}</span><span>₹{o.total}</span></div>
  {o.prep>20&&o.status==='In Kitchen'?<div className="alert"><CircleAlert size={14}/> Kitchen delay • {o.prep} min</div>:null}
  {o.courier&&<div className="courier"><div className="miniavatar">{o.courier[0]}</div><span>Rider: <b>{o.courier}</b></span></div>}
  <div className="cardfooter"><small>{o.status==='Out for Delivery'?`ETA ${o.eta} min`:o.status==='Delivered'?'Delivered':`Prep ${o.prep} min`}</small>{o.status!=='Delivered'&&<button className="next" onClick={e=>{e.stopPropagation();advance(o.id)}}>{next==='Out for Delivery'?'Dispatch':`Mark ${next}`} <ChevronRight size={14}/></button>}</div>
  {o.status==='Packed'&&!o.courier&&<select className="assign" onClick={e=>e.stopPropagation()} onChange={e=>{if(e.target.value)assign(o.id,e.target.value)}} defaultValue=""><option value="">Assign rider…</option>{couriers.filter(c=>c.active).map(c=><option key={c.name}>{c.name} • {c.zone}</option>)}</select>}
 </article>
}
function Tracking({orders,selected,setSelected}:{orders:Order[],selected:Order|null,setSelected:(o:Order)=>void}){const live=orders.filter(o=>o.status!=='Delivered'); const o=selected||live[0]; return <section className="trackinggrid"><div className="customerlist panel"><div className="paneltitle"><div><p className="eyebrow">CUSTOMER VIEW SIMULATOR</p><h3>Live orders</h3></div><span>{live.length} active</span></div>{live.map(x=><button className={`trackrow ${o?.id===x.id?'selected':''}`} key={x.id} onClick={()=>setSelected(x)}><span className={`brandtag ${brandClass(x.brand)}`}>{x.brand}</span><div><b>#{x.id} · {x.customer}</b><small>{x.zone} · {x.eta} min ETA</small></div><ChevronRight size={16}/></button>)}</div><div className="trackcard panel"><div className="customerhead"><div><span className={`brandtag ${brandClass(o.brand)}`}>{o.brand}</span><h2>Order #{o.id}</h2><p>{o.items.join(' • ')}</p></div><div className="statusbig">{o.status}</div></div><div className="mapmock"><div className="road r1"></div><div className="road r2"></div><div className="road r3"></div><div className="pin kitchen">K</div><div className="pin home">⌂</div><div className="scooter" style={{left:`${Math.min(82,18+statuses.indexOf(o.status)*17)}%`}}>🛵</div><div className="route"></div><div className="maplabel">Sector {o.zone.split(' ')[1]}</div></div><div className="eta"><div><span>Estimated delivery</span><b>{o.status==='Delivered'?'Delivered':`${o.eta} min`}</b></div><div><span>Rider</span><b>{o.courier||'Assigning…'}</b></div></div><div className="stepper">{statuses.map((s,i)=><div className={`step ${i<=statuses.indexOf(o.status)?'done':''}`} key={s}><div className="circle">{i<statuses.indexOf(o.status)?'✓':i+1}</div><span>{s}</span></div>)}</div><div className="sms"><Phone size={17}/><div><b>SMS tracking simulator</b><p>“Your DabbaDash order #{o.id} is {o.status.toLowerCase()}. Track live: dabbadash.local/track/{o.id}”</p></div><button onClick={()=>navigator.clipboard?.writeText(`dabbadash.local/track/${o.id}`)}><CopyIcon/></button></div></div></section>}
function CopyIcon(){return <span style={{fontWeight:800}}>↗</span>}
function Analytics({orders,zones}:{orders:Order[],zones:{zone:string,count:number}[]}){const brandsData=brands.map(b=>({b,n:orders.filter(o=>o.brand===b).length,rev:orders.filter(o=>o.brand===b).reduce((a,o)=>a+o.total,0)}));return <section className="analytics"><div className="panel insight"><div className="paneltitle"><div><p className="eyebrow">OPERATIONS</p><h3>Performance snapshot</h3></div><span>Auto-updated</span></div><div className="bigstats">{brandsData.map(x=><div key={x.b}><span className={`brandtag ${brandClass(x.b)}`}>{x.b}</span><b>{x.n}</b><small>orders • ₹{x.rev}</small></div>)}</div></div><div className="charts"><div className="panel"><div className="paneltitle"><h3>Hyperlocal demand</h3><span>Active orders</span></div>{zones.map(z=><div className="barrow" key={z.zone}><span>{z.zone}</span><div className="bar"><i style={{width:`${Math.max(8,z.count/Math.max(...zones.map(x=>x.count),1)*100)}%`}}></i></div><b>{z.count}</b></div>)}</div><div className="panel"><div className="paneltitle"><h3>Rider fleet</h3><span>6 active</span></div>{couriers.map(c=><div className="riderrow" key={c.name}><div className="miniavatar">{c.name[0]}</div><div><b>{c.name}</b><small>{c.vehicle} • {c.zone}</small></div><span className="available">Available</span></div>)}</div></div></section>}
function OrderModal({order,close,advance,assign}:{order:Order,close:()=>void,advance:(id:number)=>void,assign:(id:number,n:string)=>void}){return <div className="overlay" onClick={close}><div className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={close}><X/></button><span className={`brandtag ${brandClass(order.brand)}`}>{order.brand}</span><h2>Order #{order.id}</h2><p className="muted">{order.customer} · {order.zone}</p><div className="detailgrid"><div><span>Items</span><b>{order.items.join(', ')}</b></div><div><span>Total</span><b>₹{order.total}</b></div><div><span>Prep time</span><b>{order.prep} min</b></div><div><span>Rider</span><b>{order.courier||'Unassigned'}</b></div></div><div className="modalstep">{statuses.map((s,i)=><div className={i<=statuses.indexOf(order.status)?'on':''} key={s}><i></i><span>{s}</span></div>)}</div>{order.status==='Packed'&&!order.courier&&<select className="assign wide" defaultValue="" onChange={e=>e.target.value&&assign(order.id,e.target.value)}><option value="">Assign recommended courier…</option>{couriers.map(c=><option key={c.name}>{c.name} • {c.zone}</option>)}</select>}{order.status!=='Delivered'&&<button className="primary" onClick={()=>{advance(order.id);close()}}>Move to {statuses[Math.min(statuses.indexOf(order.status)+1,statuses.length-1)]} <ArrowRight/></button>}</div></div>}
createRoot(document.getElementById('root')!).render(<App/>)
