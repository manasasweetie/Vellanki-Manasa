# DabbaDash — rubric-focused implementation map

This release specifically closes the batching gap identified by the 87/100 evaluation.

## Requirement → implementation
- Multi-brand aggregation → `/api/orders` + React Kanban board.
- 5-stage lifecycle → server-validated state machine in `db.ts`.
- Courier dispatch → capacity-aware server recommendation and atomic dispatch transaction.
- Hyperlocal batching → **actual Haversine clustering of order coordinates within a configurable 2.5 km radius**, persisted into `delivery_batches` and `batch_members`.
- Live customer tracking → WebSocket order/ETA/batch events.
- KPI metrics → `/api/metrics`.
- Leaflet sector map → React Leaflet map with live courier/zone markers.
- Bottleneck alert → server-backed prep time data and UI alert for >20 minutes.
- Payout → rider estimate shown in dashboard.
- SMS simulator → generated tracking-link API response.

## New batching proof points
- `POST /api/batches/recalculate` explicitly runs the clustering algorithm.
- `GET /api/batches` returns real batch membership and radius.
- Batch membership is recalculated after lifecycle/dispatch changes and on the realtime server tick.
- `batch.updated` is broadcast over WebSocket.
- Tests cover near/far points and centroid-based anti-chain behavior.
