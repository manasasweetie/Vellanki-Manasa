import { useEffect, useMemo, useState } from "react";
import {
  Activity, Bike, Check, ChevronRight, Clock3, CookingPot, MapPin,
  PackageCheck, Radio, Search, Send, ShoppingBag, Timer, Truck, Users, X,
  Zap, Navigation, IndianRupee, Layers3, Bell, Route, TrendingUp
} from "lucide-react";

type Status = "RECEIVED" | "IN_KITCHEN" | "PACKED" | "OUT_FOR_DELIVERY" | "DELIVERED";
type Order = {
  id: string; customer: string; brand: string; brandIcon: string; items: string[];
  amount: number; zone: string; status: Status; prepMinutes: number;
  createdAt: number; courierId?: string; eta: number;
};
type Courier = {
  id: string; name: string; zone: string; vehicle: string;
  capacity: number; activeOrders: number; available: boolean;
};

const statuses: { key: Status; label: string; color: string }[] = [
  { key:"RECEIVED", label:"Received", color:"#66758f" },
  { key:"IN_KITCHEN", label:"In Kitchen", color:"#7457d9" },
  { key:"PACKED", label:"Packed", color:"#d48819" },
  { key:"OUT_FOR_DELIVERY", label:"Out for Delivery", color:"#2189c8" },
  { key:"DELIVERED", label:"Delivered", color:"#249765" },
];

const seedOrders: Order[] = [
  {id:"104",customer:"Aarav",brand:"Burger Den",brandIcon:"🍔",items:["2 Burgers","Fries"],amount:320,zone:"Zone 2",status:"IN_KITCHEN",prepMinutes:23,createdAt:Date.now()-23*60000,eta:14},
  {id:"101",customer:"Diya",brand:"Biryani Box",brandIcon:"🍛",items:["Chicken Biryani","Raita"],amount:410,zone:"Zone 1",status:"RECEIVED",prepMinutes:4,createdAt:Date.now()-4*60000,eta:18},
  {id:"105",customer:"Rohan",brand:"Chai Point",brandIcon:"☕",items:["Masala Chai","Samosa"],amount:180,zone:"Zone 3",status:"RECEIVED",prepMinutes:8,createdAt:Date.now()-8*60000,eta:12},
  {id:"108",customer:"Meera",brand:"Biryani Box",brandIcon:"🍛",items:["Veg Biryani","Kebab"],amount:360,zone:"Zone 4",status:"IN_KITCHEN",prepMinutes:18,createdAt:Date.now()-18*60000,eta:16},
  {id:"109",customer:"Ishaan",brand:"Burger Den",brandIcon:"🍔",items:["Classic Burger","Nuggets"],amount:290,zone:"Zone 1",status:"IN_KITCHEN",prepMinutes:11,createdAt:Date.now()-11*60000,eta:15},
  {id:"111",customer:"Ananya",brand:"Chai Point",brandIcon:"☕",items:["2 Cold Coffees","Sandwich"],amount:260,zone:"Zone 2",status:"PACKED",prepMinutes:16,createdAt:Date.now()-16*60000,eta:13},
  {id:"112",customer:"Kabir",brand:"Burger Den",brandIcon:"🍔",items:["2 Wraps","Fries"],amount:340,zone:"Zone 2",status:"PACKED",prepMinutes:14,createdAt:Date.now()-14*60000,eta:11},
  {id:"102",customer:"Sara",brand:"Biryani Box",brandIcon:"🍛",items:["Paneer Biryani"],amount:300,zone:"Zone 3",status:"OUT_FOR_DELIVERY",prepMinutes:13,createdAt:Date.now()-25*60000,eta:9,courierId:"r1"},
  {id:"103",customer:"Vikram",brand:"Burger Den",brandIcon:"🍔",items:["Cheese Burger","Fries"],amount:275,zone:"Zone 4",status:"OUT_FOR_DELIVERY",prepMinutes:12,createdAt:Date.now()-27*60000,eta:7,courierId:"r3"},
  {id:"99",customer:"Nisha",brand:"Chai Point",brandIcon:"☕",items:["Tea","Cookies"],amount:150,zone:"Zone 1",status:"DELIVERED",prepMinutes:10,createdAt:Date.now()-50*60000,eta:0,courierId:"r2"},
  {id:"106",customer:"Aditya",brand:"Biryani Box",brandIcon:"🍛",items:["Chicken Biryani"],amount:390,zone:"Zone 4",status:"RECEIVED",prepMinutes:3,createdAt:Date.now()-3*60000,eta:19},
  {id:"107",customer:"Tara",brand:"Chai Point",brandIcon:"☕",items:["Iced Tea","Puff"],amount:190,zone:"Zone 2",status:"IN_KITCHEN",prepMinutes:21,createdAt:Date.now()-21*60000,eta:17},
  {id:"110",customer:"Neil",brand:"Burger Den",brandIcon:"🍔",items:["Double Burger"],amount:240,zone:"Zone 3",status:"PACKED",prepMinutes:15,createdAt:Date.now()-15*60000,eta:10},
  {id:"113",customer:"Maya",brand:"Biryani Box",brandIcon:"🍛",items:["Veg Biryani"],amount:250,zone:"Zone 1",status:"IN_KITCHEN",prepMinutes:22,createdAt:Date.now()-22*60000,eta:15},
  {id:"114",customer:"Arjun",brand:"Chai Point",brandIcon:"☕",items:["Cutting Chai","Samosa"],amount:160,zone:"Zone 4",status:"RECEIVED",prepMinutes:6,createdAt:Date.now()-6*60000,eta:18},
];

const seedCouriers: Courier[] = [
  {id:"r1",name:"Ramesh",zone:"Zone 2",vehicle:"Bike",capacity:3,activeOrders:0,available:true},
  {id:"r2",name:"Suresh",zone:"Zone 1",vehicle:"Scooter",capacity:2,activeOrders:1,available:true},
  {id:"r3",name:"Arjun",zone:"Zone 3",vehicle:"Bike",capacity:3,activeOrders:1,available:true},
  {id:"r4",name:"Priya",zone:"Zone 4",vehicle:"Scooter",capacity:2,activeOrders:0,available:true},
  {id:"r5",name:"Kiran",zone:"Zone 2",vehicle:"Bike",capacity:3,activeOrders:2,available:true},
  {id:"r6",name:"Rahul",zone:"Zone 1",vehicle:"Bike",capacity:3,activeOrders:0,available:true},
];

const iconFor = (s: Status) =>
  s==="RECEIVED" ? <ShoppingBag size={15}/> :
  s==="IN_KITCHEN" ? <CookingPot size={15}/> :
  s==="PACKED" ? <PackageCheck size={15}/> :
  s==="OUT_FOR_DELIVERY" ? <Truck size={15}/> : <Check size={15}/>;

function App() {
  const [orders, setOrders] = useState(seedOrders);
  const [couriers, setCouriers] = useState(seedCouriers);
  const [view, setView] = useState<"dashboard"|"customer">("dashboard");
  const [selectedOrder, setSelectedOrder] = useState("104");
  const [assigning, setAssigning] = useState<Order|null>(null);
  const [query, setQuery] = useState("");
  const [brandFilter, setBrandFilter] = useState("All Brands");
  const [zoneFilter, setZoneFilter] = useState("All Zones");
  const [toast, setToast] = useState("");
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const t = setInterval(() => {
      setNow(Date.now());
      setOrders(prev => prev.map(o => o.status==="OUT_FOR_DELIVERY" && o.eta>0
        ? {...o, eta:Math.max(0,o.eta-1)}
        : o));
    }, 5000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 2600);
    return () => clearTimeout(t);
  }, [toast]);

  const activeOrders = orders.filter(o => o.status !== "DELIVERED").length;
  const kitchenOrders = orders.filter(o => o.status === "IN_KITCHEN");
  const avgPrep = Math.round(orders.reduce((a,o)=>a+o.prepMinutes,0)/orders.length);
  const pendingDispatch = orders.filter(o => o.status==="PACKED").length;
  const delivered = orders.filter(o => o.status==="DELIVERED").length;
  const selected = orders.find(o => o.id===selectedOrder) ?? orders[0];

  const filteredOrders = useMemo(() => orders.filter(o =>
    (brandFilter==="All Brands" || o.brand===brandFilter) &&
    (zoneFilter==="All Zones" || o.zone===zoneFilter) &&
    (`${o.id} ${o.customer} ${o.brand} ${o.items.join(" ")}`.toLowerCase().includes(query.toLowerCase()))
  ), [orders, query, brandFilter, zoneFilter]);

  const recommend = (order: Order) => [...couriers]
    .filter(c => c.available && c.activeOrders < c.capacity)
    .sort((a,b) => {
      const score = (c: Courier) => (c.zone===order.zone ? 0 : 10) + c.activeOrders;
      return score(a)-score(b);
    })[0];

  const showToast = (message:string) => setToast(message);

  const advance = (id: string) => {
    const target = orders.find(o=>o.id===id);
    if (!target) return;
    if (target.status === "PACKED") {
      setAssigning(target);
      return;
    }
    const idx = statuses.findIndex(s=>s.key===target.status);
    if (idx >= statuses.length-1) return;
    const next = statuses[idx+1].key;
    setOrders(prev => prev.map(o => o.id===id ? {...o,status:next, ...(next==="OUT_FOR_DELIVERY"?{eta:15}:{}), ...(next==="DELIVERED"?{eta:0}: {})} : o));
    if (next === "OUT_FOR_DELIVERY") setSelectedOrder(id);
    showToast(`Order #${id} moved to ${statuses[idx+1].label}`);
  };

  const assignCourier = (courierId: string) => {
    if (!assigning) return;
    const rider = couriers.find(c=>c.id===courierId);
    setOrders(prev => prev.map(o => o.id===assigning.id
      ? {...o,status:"OUT_FOR_DELIVERY",courierId,eta:15}
      : o));
    setCouriers(prev => prev.map(c => c.id===courierId
      ? {...c,activeOrders:c.activeOrders+1}
      : c));
    setAssigning(null);
    setSelectedOrder(assigning.id);
    showToast(`Order #${assigning.id} dispatched to ${rider?.name ?? "courier"}`);
  };

  const zones = ["Zone 1","Zone 2","Zone 3","Zone 4"].map(z => ({
    z, count: orders.filter(o=>o.zone===z && o.status!=="DELIVERED").length,
    batch: orders.filter(o=>o.zone===z && ["PACKED","OUT_FOR_DELIVERY"].includes(o.status)).length
  }));

  const brands = ["All Brands","Biryani Box","Burger Den","Chai Point"];
  const filteredCount = filteredOrders.length;

  return (
    <div className="app">
      <header className="header">
        <div className="branding">
          <div className="logo">🍱</div>
          <div><div className="title">DabbaDash</div><div className="subtitle">LastMile Bite Battle</div></div>
        </div>
        <div className="header-actions">
          <div className="live"><span className="dot"/> LIVE SYNC · 5s</div>
          <div className="view-toggle">
            <button className={view==="dashboard"?"active":""} onClick={()=>setView("dashboard")}>Kitchen Dashboard</button>
            <button className={view==="customer"?"active":""} onClick={()=>setView("customer")}>Customer View</button>
          </div>
        </div>
      </header>

      <main className="page">
        {view==="dashboard" ? (
          <>
            <div className="hero">
              <div>
                <div className="eyebrow"><span className="live-dot"/> OPERATIONS · COMMISSARY LIVE</div>
                <h1>Dispatch Command Center</h1>
                <p>One kitchen. Multiple brands. Smarter last-mile dispatch.</p>
              </div>
              <div className="hero-right">
                <div className="sync-card"><Radio size={14}/> Updated {new Date(now).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</div>
                <button className="demo-btn" onClick={()=>{setSelectedOrder("104");setView("customer")}}><Navigation size={14}/> Demo Customer Tracking</button>
              </div>
            </div>

            <div className="kpis">
              <Kpi icon={<Activity/>} label="Active Orders" value={activeOrders} note={`${filteredCount} visible · 3 virtual brands`}/>
              <Kpi icon={<Timer/>} label="Avg Prep Time" value={`${avgPrep}m`} note={`${kitchenOrders.length} orders in kitchen`}/>
              <Kpi icon={<Send/>} label="Pending Dispatch" value={pendingDispatch} note="Packed & waiting for rider"/>
              <Kpi icon={<Bike/>} label="Riders Available" value={couriers.filter(c=>c.available && c.activeOrders<c.capacity).length} note={`${couriers.length} riders on roster`}/>
            </div>

            <div className="insight-strip">
              <div><Zap size={16}/><b>Peak-hour insight:</b> Zone 2 has the strongest batching opportunity.</div>
              <div><TrendingUp size={16}/><span>{delivered} orders delivered · {Math.max(0,orders.length-delivered)} active pipeline</span></div>
            </div>

            <div className="toolbar">
              <div className="search"><Search size={15}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search order, customer or item..."/></div>
              <select value={brandFilter} onChange={e=>setBrandFilter(e.target.value)}>{brands.map(b=><option key={b}>{b}</option>)}</select>
              <select value={zoneFilter} onChange={e=>setZoneFilter(e.target.value)}>{["All Zones","Zone 1","Zone 2","Zone 3","Zone 4"].map(z=><option key={z}>{z}</option>)}</select>
              <span className="result-count">{filteredCount} orders</span>
            </div>

            <div className="board">
              {statuses.map(s => {
                const col = filteredOrders.filter(o=>o.status===s.key);
                return <div className="column" key={s.key}>
                  <div className="column-head">
                    <div className="column-title" style={{color:s.color}}>{iconFor(s.key)} {s.label}</div>
                    <div className="count">{col.length}</div>
                  </div>
                  <div className="column-body">
                    {col.map(o => <OrderCard key={o.id} order={o} onAdvance={advance}
                      onAssign={()=>setAssigning(o)}
                      onTrack={()=>{setSelectedOrder(o.id);setView("customer")}}/> )}
                    {!col.length && <div className="empty"><Layers3 size={20}/><span>No matching orders</span></div>}
                  </div>
                </div>
              })}
            </div>

            <div className="section">
              <section className="panel map-panel">
                <div className="panel-title"><div><h2><MapPin size={16}/> Hyperlocal Sector Map</h2><span className="muted">2.5 km batching heuristic · {orders.filter(o=>o.status!=="DELIVERED").length} active destinations</span></div><span className="map-legend"><i/> Kitchen <i className="rider-legend"/> Rider</span></div>
                <div className="sector-map">
                  <div className="road r1"/><div className="road r2"/><div className="road r3"/>
                  <div className="kitchen-pin">🍱<span>Kitchen</span></div>
                  {zones.map((z,i)=><div className={`sector sector-${i+1}`} key={z.z}><b>{z.z}</b><span>{z.count} active</span><small>{z.batch} batched</small></div>)}
                  {couriers.slice(0,4).map((c,i)=><div className={`rider-pin p-${i+1}`} key={c.id} title={`${c.name} · ${c.zone}`}>🛵</div>)}
                </div>
              </section>

              <section className="panel">
                <div className="panel-title"><div><h2><Route size={16}/> Smart Batch Queue</h2><span className="muted">Same-zone multi-order opportunities</span></div></div>
                <div className="batch-list">
                  {zones.map(z=><div className="batch-card" key={z.z}>
                    <div className="batch-top"><div><b>{z.z}</b><span>{z.count} active orders</span></div><div className="batch-pill">{z.batch >= 2 ? "BATCH READY" : "MONITOR"}</div></div>
                    <div className="batch-bar"><span style={{width:`${Math.min(100,z.count*24+8)}%`}}/></div>
                    <div className="batch-bottom"><span>{z.batch} dispatch-ready</span><b>{z.count >= 2 ? "Save rider trips" : "Single route"}</b></div>
                  </div>)}
                </div>
              </section>
            </div>

            <div className="section lower">
              <section className="panel">
                <div className="panel-title"><div><h2><Bell size={16}/> Kitchen Bottleneck Monitor</h2><span className="muted">Flags tickets over 20 minutes</span></div></div>
                <div className="alert-list">
                  {orders.filter(o=>o.status==="IN_KITCHEN" && o.prepMinutes>20).map(o=><div className="alert-row" key={o.id}>
                    <div><strong>#{o.id} · {o.brand}</strong><span>{o.customer} · {o.items.join(" + ")}</span></div><b>{o.prepMinutes} min</b>
                  </div>)}
                  {!orders.some(o=>o.status==="IN_KITCHEN" && o.prepMinutes>20) && <div className="safe"><Check size={16}/> No current bottlenecks</div>}
                </div>
              </section>
              <section className="panel">
                <div className="panel-title"><div><h2><IndianRupee size={16}/> Rider Earnings</h2><span className="muted">Estimated dispatch payout</span></div></div>
                <div className="earnings">
                  {couriers.slice(0,4).map(c=><div className="earning-row" key={c.id}><span><b>{c.name}</b><small>{c.zone} · {c.vehicle}</small></span><strong>₹{180 + c.activeOrders*35}</strong></div>)}
                </div>
              </section>
            </div>
          </>
        ) : (
          <CustomerView selected={selected} couriers={couriers} onBack={()=>setView("dashboard")} onAdvance={advance}/>
        )}
      </main>

      {toast && <div className="toast"><Check size={16}/>{toast}</div>}

      {assigning && <div className="modal-wrap" onClick={()=>setAssigning(null)}>
        <div className="modal" onClick={e=>e.stopPropagation()}>
          <div className="modal-head"><div><div className="eyebrow">DISPATCH CONSOLE</div><h3>Assign Courier · #{assigning.id}</h3></div><button className="icon-btn" onClick={()=>setAssigning(null)}><X/></button></div>
          <p>Recommended using delivery-zone proximity first, then remaining rider capacity.</p>
          <div className="recommendation">
            <div className="rec-icon"><Zap size={16}/></div>
            <div><small>SMART RECOMMENDATION</small><b>{recommend(assigning)?.name ?? "No rider available"}</b><span>{recommend(assigning)?.zone ?? "—"} · nearest eligible rider</span></div>
          </div>
          <select className="select" id="riderSelect" defaultValue={recommend(assigning)?.id}>
            {couriers.filter(c=>c.available && c.activeOrders<c.capacity).map(c=><option key={c.id} value={c.id}>{c.name} — {c.zone} — {c.activeOrders}/{c.capacity} active</option>)}
          </select>
          <div className="modal-actions">
            <button className="btn secondary" onClick={()=>setAssigning(null)}>Cancel</button>
            <button className="btn" onClick={()=>assignCourier((document.getElementById("riderSelect") as HTMLSelectElement).value)}>Assign & Dispatch <ChevronRight size={14}/></button>
          </div>
        </div>
      </div>}
    </div>
  );
}

function Kpi({icon,label,value,note}:{icon:React.ReactNode;label:string;value:string|number;note:string}) {
  return <div className="kpi"><div className="kpi-top"><span>{label}</span><div className="kpi-icon">{icon}</div></div><div className="kpi-value">{value}</div><div className="kpi-note">{note}</div></div>;
}

function OrderCard({order,onAdvance,onAssign,onTrack}:{order:Order;onAdvance:(id:string)=>void;onAssign:()=>void;onTrack:()=>void}) {
  const canAdvance = order.status!=="DELIVERED";
  const nextLabel = order.status==="IN_KITCHEN" ? "Mark Packed" : order.status==="PACKED" ? "Assign Courier" : order.status==="RECEIVED" ? "Start Cooking" : order.status==="OUT_FOR_DELIVERY" ? "Mark Delivered" : "";
  const bottleneck = order.status==="IN_KITCHEN" && order.prepMinutes>20;
  const courierNames:Record<string,string>={r1:"Ramesh",r2:"Suresh",r3:"Arjun",r4:"Priya",r5:"Kiran",r6:"Rahul"};
  return <div className={`card ${bottleneck?"bottleneck":""}`}>
    <div className="card-top"><div><div className="order-id">#{order.id} · {order.customer}</div><div className="time">{order.prepMinutes} min in flow</div></div><div className="amount">₹{order.amount}</div></div>
    <div className="brand">{order.brandIcon} {order.brand}</div>
    <div className="items">{order.items.join(" + ")}</div>
    <div className="meta"><div className="meta-box"><span>Sector</span><b>{order.zone}</b></div><div className="meta-box"><span>ETA</span><b>{order.eta ? `${order.eta} min` : "Done"}</b></div></div>
    {bottleneck && <div className="alert">⚠ Kitchen bottleneck · over 20 min</div>}
    {order.courierId && <div className="rider">🛵 <b>{courierNames[order.courierId] ?? "Courier"}</b> · assigned</div>}
    {order.status==="PACKED" && <button className="btn" onClick={onAssign}>Assign Recommended Courier <ChevronRight size={14}/></button>}
    {canAdvance && order.status!=="PACKED" && <button className="btn" onClick={()=>onAdvance(order.id)}>{nextLabel} <ChevronRight size={14}/></button>}
    {order.status==="OUT_FOR_DELIVERY" && <button className="btn secondary" onClick={onTrack}>Open Customer Tracker</button>}
    {order.status==="DELIVERED" && <div className="delivered"><Check size={13}/> Delivered successfully</div>}
  </div>;
}

function CustomerView({selected,couriers,onBack,onAdvance}:{selected:Order;couriers:Courier[];onBack:()=>void;onAdvance:(id:string)=>void}) {
  const courier = couriers.find(c=>c.id===selected.courierId);
  const current = statuses.findIndex(s=>s.key===selected.status);
  const progress = selected.status==="DELIVERED" ? 100 : selected.status==="OUT_FOR_DELIVERY" ? Math.max(8,Math.min(92,100-((selected.eta/15)*85))) : selected.status==="PACKED" ? 5 : 0;
  const message =
    selected.status==="OUT_FOR_DELIVERY" ? `Courier ${courier?.name ?? "assigned"} is on the way to you.` :
    selected.status==="PACKED" ? "Your food is packed and waiting for courier pickup." :
    selected.status==="DELIVERED" ? "Delivered. Enjoy your meal! 🎉" :
    "Your kitchen is preparing your order.";

  return <div className="customer-wrap">
    <div className="customer-top"><button className="back-link" onClick={onBack}>← Kitchen Dashboard</button><div className="secure"><Radio size={13}/> Live tracking simulation</div></div>
    <div className="customer-card">
      <div className="customer-head">
        <div><div className="track-brand">{selected.brandIcon} {selected.brand}</div><div className="track-order">Order #{selected.id}</div><div className="customer-items">{selected.items.join(" · ")} · ₹{selected.amount}</div></div>
        <div className="eta"><small>ESTIMATED ARRIVAL</small><strong>{selected.status==="DELIVERED"?"Delivered":`${selected.eta} min`}</strong></div>
      </div>

      <div className="stepper">
        {statuses.map((s,i)=><div className={`step ${i<current?"done":i===current?"current":""}`} key={s.key}>
          <div className="step-dot">{i<current?<Check size={14}/>:i+1}</div><div className="step-label">{s.label}</div>
        </div>)}
      </div>

      <div className="live-route">
        <div className="route-copy"><span className="status-badge"><span/> {selected.status==="OUT_FOR_DELIVERY"?"LIVE":"STATUS UPDATE"}</span><h3>{message}</h3><p>{selected.status==="OUT_FOR_DELIVERY" ? `ETA updates automatically every 5 seconds · ${selected.zone}` : `Sector ${selected.zone.replace("Zone ","")} · real-time kitchen sync`}</p></div>
        <div className="route-visual">
          <div className="route-line"><div className="route-progress" style={{width:`${progress}%`}}/></div>
          <div className="moving-vehicle" style={{left:`calc(${progress}% - 16px)`}}>{selected.status==="OUT_FOR_DELIVERY"?"🛵":"📦"}</div>
          <div className="route-home">🏠</div>
        </div>
      </div>

      <div className="customer-grid">
        <div className="customer-info"><div className="info-icon">🛵</div><div><small>COURIER</small><b>{courier?.name ?? "Being assigned"}</b><span>{courier ? `${courier.vehicle} · ${courier.zone}` : "We'll notify you when assigned"}</span></div></div>
        <div className="customer-info"><div className="info-icon">📍</div><div><small>DELIVERY SECTOR</small><b>{selected.zone}</b><span>Hyperlocal 2.5 km batching</span></div></div>
      </div>

      <div className="customer-actions">
        <button className="btn secondary" onClick={onBack}>Back to Dashboard</button>
        {selected.status!=="DELIVERED" && <button className="btn" onClick={()=>onAdvance(selected.id)}>Simulate Next Update <ChevronRight size={14}/></button>}
      </div>
    </div>
    <div className="trust-row"><span>🔒 Secure order simulation</span><span>⚡ Live kitchen sync</span><span>📍 Hyperlocal routing</span></div>
  </div>;
}

export default App;
