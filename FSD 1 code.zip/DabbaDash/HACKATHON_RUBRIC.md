# DabbaDash judging checklist

| Brief requirement | Implemented |
|---|---|
| Multi-brand order aggregation | Yes |
| 5-stage preparation lifecycle | Yes |
| Courier dispatch console | Yes |
| Zone/capacity courier recommendation | Yes |
| Hyperlocal batching | Yes |
| Customer tracking mock-up | Yes |
| ETA countdown | Yes |
| Kitchen KPI metrics | Yes |
| Bottleneck >20 min alert | Yes |
| Sector map visualization | Yes |
| Rider payout estimate | Yes |
| Responsive UI | Yes |
| Demo Order #104 flow | Yes |

## Recommended live demo
Show Order #104 from In Kitchen → Packed → Assign Ramesh → Out for Delivery → Customer View.
