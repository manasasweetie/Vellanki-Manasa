# DabbaDash — LastMile Bite Battle

## Upgraded hackathon demo

This version focuses on the rubric items in the brief and adds a more convincing presentation layer.

### Included
- Multi-brand aggregated order feed
- Five-stage lifecycle: Received → In Kitchen → Packed → Out for Delivery → Delivered
- Search + brand + zone filtering
- Smart courier recommendation using zone proximity and capacity
- Hyperlocal 2.5 km batching view
- Sector map visualization with kitchen, riders and delivery zones
- 20-minute kitchen bottleneck alerts
- Customer live-tracking mock-up with animated route position
- ETA countdown simulation every 5 seconds
- Rider payout estimate
- KPI dashboard
- Toast confirmations for status changes and dispatch
- Responsive layout for desktop/tablet/mobile
- Demo-ready Order #104 flow

## Demo flow

1. Open the Kitchen Dashboard.
2. Search `104` if needed.
3. In Order #104 (Burger Den), click **Mark Packed**.
4. Click **Assign Recommended Courier**.
5. Ramesh from Zone 2 is recommended because the algorithm prioritizes same-zone riders and then available capacity.
6. Click **Assign & Dispatch**.
7. Switch to **Customer View**.
8. Order #104 shows the five-step lifecycle, courier assignment, route animation and ETA.
9. Use **Simulate Next Update** to demonstrate status synchronization.

## Run

Requires Node.js 18+ (Node 20+ recommended).

```bash
npm install
npm run dev
```

For a production build:

```bash
npm run build
```

## Notes

This is a frontend prototype. State is intentionally local React state for a fast hackathon demo. The UI is structured so the state layer can later be replaced by Express + SQLite + WebSockets/polling.
