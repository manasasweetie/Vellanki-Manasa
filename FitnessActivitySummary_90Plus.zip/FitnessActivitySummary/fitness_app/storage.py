import csv
import json
from pathlib import Path
from typing import Iterable
from .models import Activity

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
JSON_FILE = DATA_DIR / "activities.json"
CSV_FILE = DATA_DIR / "activities.csv"

FIELDS = ["id", "date", "category", "duration_minutes", "distance_km",
          "calories", "steps", "intensity", "notes"]

def ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)

def load_json() -> list[Activity]:
    ensure_data_dir()
    if not JSON_FILE.exists():
        return []
    try:
        raw = json.loads(JSON_FILE.read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            return []
        result = []
        for row in raw:
            try:
                result.append(Activity.from_dict(row))
            except (KeyError, TypeError, ValueError):
                continue
        return result
    except (json.JSONDecodeError, OSError):
        backup = JSON_FILE.with_suffix(".corrupt.json")
        try:
            JSON_FILE.replace(backup)
        except OSError:
            pass
        return []

def save_json(records: Iterable[Activity]):
    ensure_data_dir()
    payload = [r.to_dict() for r in records]
    tmp = JSON_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    tmp.replace(JSON_FILE)

def save_csv(records: Iterable[Activity]):
    ensure_data_dir()
    with CSV_FILE.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for r in records:
            writer.writerow(r.to_dict())

def load_csv(path: str | Path = CSV_FILE) -> list[Activity]:
    try:
        with Path(path).open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            missing = set(FIELDS) - set(reader.fieldnames or [])
            if missing:
                raise ValueError(f"Missing columns: {', '.join(sorted(missing))}")
            records = []
            for line, row in enumerate(reader, start=2):
                try:
                    records.append(Activity.from_dict(row))
                except (KeyError, TypeError, ValueError) as e:
                    raise ValueError(f"Invalid row {line}: {e}") from e
            return records
    except FileNotFoundError:
        return []

def save_all(records: list[Activity]):
    save_json(records)
    save_csv(records)
