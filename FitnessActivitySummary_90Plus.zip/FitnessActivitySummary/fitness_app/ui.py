import os
from datetime import datetime
from .models import Activity, VALID_CATEGORIES
from .validation import (validate_date, validate_choice, validate_positive_float,
                         validate_nonnegative_int, validate_notes)
from .storage import load_json, save_all
from .analytics import totals, averages, status, streak, search, category_counts
from .plots import create_weekly_chart, create_category_chart
from .reports import generate_markdown, generate_audit_log

RESET = "\033[0m"
BOLD = "\033[1m"
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def banner():
    print(f"{CYAN}{BOLD}")
    print("╔══════════════════════════════════════════════╗")
    print("║        FITNESS ACTIVITY SUMMARY              ║")
    print("║        DataSpark Challenge • Project #34     ║")
    print("╚══════════════════════════════════════════════╝")
    print(RESET)

def ask(prompt, validator):
    while True:
        value = input(prompt)
        try:
            return validator(value)
        except ValueError as e:
            print(f"{RED}✗ {e} Please try again.{RESET}")

def next_id(records):
    return max((r.id for r in records), default=0) + 1

def add_activity(records):
    print(f"\n{BOLD}➜ Record New Activity{RESET}")
    date = ask("Date (YYYY-MM-DD): ", validate_date)
    print("Categories:", ", ".join(VALID_CATEGORIES))
    category = ask("Category: ", lambda x: validate_choice(x, VALID_CATEGORIES))
    duration = ask("Duration in minutes (1-1440): ",
                   lambda x: validate_positive_float(x, "Duration", 1440))
    distance = ask("Distance in km (0.01-1000): ",
                   lambda x: validate_positive_float(x, "Distance", 1000))
    calories = ask("Calories burned (1-10000): ",
                   lambda x: validate_positive_float(x, "Calories", 10000))
    steps = ask("Steps (0-100000): ",
                lambda x: validate_nonnegative_int(x, "Steps", 100000))
    intensity = ask("Intensity (Low/Moderate/High): ",
                    lambda x: validate_choice(x, ["Low", "Moderate", "High"]))
    notes = validate_notes(input("Notes (optional): "))
    records.append(Activity(next_id(records), date, category, duration,
                            distance, calories, steps, intensity, notes))
    save_all(records)
    print(f"{GREEN}✓ Activity saved to JSON and CSV.{RESET}")

def show_records(records, rows=None):
    rows = records if rows is None else rows
    if not rows:
        print(f"{YELLOW}No matching records found.{RESET}")
        return
    print("\n" + "-" * 112)
    print(f"{'ID':<4}{'Date':<12}{'Category':<12}{'Min':>8}{'Km':>9}{'Cal':>9}{'Steps':>10}{'Intensity':<11} Notes")
    print("-" * 112)
    for r in rows:
        print(f"{r.id:<4}{r.date:<12}{r.category:<12}{r.duration_minutes:>8.1f}"
              f"{r.distance_km:>9.2f}{r.calories:>9.0f}{r.steps:>10}{r.intensity:<11} {r.notes[:28]}")
    print("-" * 112)

def dashboard(records):
    t, a = totals(records), averages(records)
    print(f"\n{BOLD}EXECUTIVE DASHBOARD{RESET}")
    print(f"Status: {GREEN}{status(records)}{RESET}    Best streak: {streak(records)} day(s)")
    print(f"Sessions: {t['sessions']}    Duration: {t['duration']:.1f} min    "
          f"Distance: {t['distance']:.2f} km")
    print(f"Calories: {t['calories']:.0f} kcal    Steps: {t['steps']}")
    if records:
        print(f"Average/session: {a['duration']:.1f} min | {a['distance']:.2f} km | "
              f"{a['calories']:.1f} kcal | {a['steps']:.0f} steps")
        print("\nTop categories:", ", ".join(f"{k} ({v})" for k, v in category_counts(records).most_common()))
    else:
        print("Start recording activities to unlock analytics.")

def analytics_menu(records):
    dashboard(records)
    print("\n1. Generate weekly trend chart")
    print("2. Generate category chart")
    print("3. Generate Markdown summary + audit log")
    print("4. Back")
    choice = input("Choose: ").strip()
    try:
        if choice == "1":
            print(f"Chart saved: {create_weekly_chart(records)}")
        elif choice == "2":
            print(f"Chart saved: {create_category_chart(records)}")
        elif choice == "3":
            print(f"Summary saved: {generate_markdown(records)}")
            print(f"Audit log saved: {generate_audit_log(records)}")
        elif choice != "4":
            print("Invalid option.")
    except ImportError:
        print(f"{RED}Matplotlib is not installed. Run: pip install matplotlib{RESET}")

def search_menu(records):
    print("\nSearch by keyword/date/notes and optional category.")
    keyword = input("Keyword (blank = all): ").strip()
    print("Categories:", "All, " + ", ".join(VALID_CATEGORIES))
    category = input("Category: ").strip() or "All"
    try:
        category = validate_choice(category, ("All",) + VALID_CATEGORIES)
    except ValueError as e:
        print(e); return
    show_records(records, search(records, keyword, category))

def import_csv(records):
    path = input("CSV file path: ").strip()
    from .storage import load_csv
    try:
        imported = load_csv(path)
        if not imported:
            print("No records imported."); return
        existing_ids = {r.id for r in records}
        next_num = max(existing_ids, default=0) + 1
        for r in imported:
            r.id = next_num
            next_num += 1
            records.append(r)
        save_all(records)
        print(f"{GREEN}✓ Imported {len(imported)} validated row(s).{RESET}")
    except (OSError, ValueError) as e:
        print(f"{RED}Import failed: {e}{RESET}")

def run_app():
    records = load_json()
    while True:
        clear()
        banner()
        print(f"Stored records: {len(records)}")
        print("""
1. Record new activity
2. View all activities
3. Search / filter records
4. Executive dashboard & analytics
5. Generate charts
6. Export Markdown summary / audit log
7. Import validated CSV dataset
8. Save & exit
""")
        choice = input("Select an option: ").strip()
        if choice == "1":
            add_activity(records)
        elif choice == "2":
            show_records(records)
        elif choice == "3":
            search_menu(records)
        elif choice == "4":
            dashboard(records)
        elif choice == "5":
            try:
                print(f"Weekly chart: {create_weekly_chart(records)}")
                print(f"Category chart: {create_category_chart(records)}")
            except ImportError:
                print(f"{RED}Install matplotlib: pip install matplotlib{RESET}")
        elif choice == "6":
            print(f"Summary: {generate_markdown(records)}")
            print(f"Audit log: {generate_audit_log(records)}")
        elif choice == "7":
            import_csv(records)
        elif choice == "8":
            save_all(records)
            print(f"{GREEN}✓ Data saved. Goodbye!{RESET}")
            break
        else:
            print(f"{RED}Invalid menu option.{RESET}")
        input("\nPress Enter to continue...")
