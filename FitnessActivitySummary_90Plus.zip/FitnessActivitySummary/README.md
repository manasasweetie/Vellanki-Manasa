# Fitness Activity Summary — DataSpark Challenge #34

A beginner-friendly but feature-rich Python 3.10+ application for recording exercise sessions, validating data, persisting records, searching/filtering, generating executive summaries, exporting reports, and plotting trends.

## Features
- Branded interactive terminal menu
- Defensive validation for dates, ranges, numeric values and categories
- JSON + CSV persistence
- Search and category filtering
- Executive metrics, averages, status and streak analysis
- Matplotlib weekly/category charts
- Markdown summary and audit log export
- Validated bulk CSV import
- Corrupted JSON recovery
- 30+ realistic demo records
- Automated tests

## Run

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python app.py
```

## Demo data

The included `data/activities.json` contains realistic sample records. Delete that file if you want a clean first-run experience.

## CSV import format

Required columns:
`id,date,category,duration_minutes,distance_km,calories,steps,intensity,notes`

Example:

```csv
id,date,category,duration_minutes,distance_km,calories,steps,intensity,notes
1,2026-11-01,Walking,35,2.8,160,4200,Moderate,Campus walk
```

## Suggested 90+ mark demo flow
1. Launch the app and show the branded menu.
2. Add an activity with an invalid duration such as `abc`; demonstrate that the app rejects it.
3. Add a valid activity and show JSON/CSV persistence.
4. Search by category/keyword.
5. Open the executive dashboard and explain total + average + status + streak.
6. Generate both charts.
7. Generate Markdown summary and audit log.
8. Close and relaunch to prove persistence.
9. Import a validated CSV file if the evaluator asks for bulk import.

## Project structure

```text
FitnessActivitySummary/
├── app.py
├── requirements.txt
├── README.md
├── fitness_app/
│   ├── models.py
│   ├── validation.py
│   ├── storage.py
│   ├── analytics.py
│   ├── plots.py
│   ├── reports.py
│   └── ui.py
├── data/
│   ├── activities.json
│   └── activities.csv
├── reports/
└── tests/
```
